	.file	"exact.cpp"
	.text
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation:
.LFB15203:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L2
	cmpl	$1, %edx
	je	.L3
	cmpl	$2, %edx
	je	.L6
	cmpl	$3, %edx
	jne	.L5
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L5
	movl	$48, %esi
	call	_ZdlPvm@PLT
	jmp	.L5
	.p2align 4,,10
	.p2align 3
.L3:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L5:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L6:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$48, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movdqu	32(%rbp), %xmm0
	movups	%xmm0, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L5
	.cfi_endproc
.LFE15203:
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation:
.LFB15186:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L15
	cmpl	$1, %edx
	je	.L16
	cmpl	$2, %edx
	je	.L19
	cmpl	$3, %edx
	jne	.L18
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L18
	movl	$48, %esi
	call	_ZdlPvm@PLT
	jmp	.L18
	.p2align 4,,10
	.p2align 3
.L16:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L18:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L15:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L19:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$48, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movdqu	32(%rbp), %xmm0
	movups	%xmm0, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L18
	.cfi_endproc
.LFE15186:
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation:
.LFB15169:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L27
	cmpl	$1, %edx
	je	.L28
	cmpl	$2, %edx
	je	.L31
	cmpl	$3, %edx
	jne	.L30
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L30
	movl	$48, %esi
	call	_ZdlPvm@PLT
	jmp	.L30
	.p2align 4,,10
	.p2align 3
.L28:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L30:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L27:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L31:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$48, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movdqu	32(%rbp), %xmm0
	movups	%xmm0, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L30
	.cfi_endproc
.LFE15169:
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation:
.LFB15130:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L39
	cmpl	$1, %edx
	je	.L40
	cmpl	$2, %edx
	je	.L43
	cmpl	$3, %edx
	jne	.L42
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L42
	movl	$40, %esi
	call	_ZdlPvm@PLT
	jmp	.L42
	.p2align 4,,10
	.p2align 3
.L40:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L42:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L39:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L43:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$40, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movq	32(%rbp), %rdx
	movq	%rdx, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L42
	.cfi_endproc
.LFE15130:
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation:
.LFB15076:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L51
	cmpl	$1, %edx
	je	.L52
	cmpl	$2, %edx
	je	.L55
	cmpl	$3, %edx
	jne	.L54
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L54
	movl	$40, %esi
	call	_ZdlPvm@PLT
	jmp	.L54
	.p2align 4,,10
	.p2align 3
.L52:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L54:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L51:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L55:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$40, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movq	32(%rbp), %rdx
	movq	%rdx, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L54
	.cfi_endproc
.LFE15076:
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation, @function
_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation:
.LFB14765:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	testl	%edx, %edx
	je	.L63
	cmpl	$1, %edx
	je	.L64
	cmpl	$2, %edx
	je	.L67
	cmpl	$3, %edx
	jne	.L66
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L66
	movl	$40, %esi
	call	_ZdlPvm@PLT
	jmp	.L66
	.p2align 4,,10
	.p2align 3
.L64:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
.L66:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L63:
	.cfi_restore_state
	leaq	_ZTIZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_(%rip), %rax
	movq	%rax, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L67:
	.cfi_restore_state
	movq	(%rsi), %rbp
	movl	$40, %edi
	call	_Znwm@PLT
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%rax)
	movq	32(%rbp), %rdx
	movq	%rdx, 32(%rax)
	movq	%rax, (%rbx)
	jmp	.L66
	.cfi_endproc
.LFE14765:
	.size	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation, .-_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC2:
	.string	"non-finite query component"
.LC3:
	.string	"vector::reserve"
.LC4:
	.string	"vector::_M_realloc_append"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB8:
	.text
.LHOTB8:
	.p2align 4
	.type	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, @function
_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE:
.LFB14318:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14318
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%r8, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movq	%rdx, 40(%rsp)
	movq	40(%rsp), %rdx
	movq	%rsi, 32(%rsp)
	movq	%rcx, 24(%rsp)
	leaq	(%rsi,%rdx,4), %rdx
	movq	%fs:40, %rbp
	movq	%rbp, 136(%rsp)
	movq	%r9, %rbp
	cmpq	%rsi, %rdx
	je	.L75
	movss	.LC1(%rip), %xmm1
	movq	%rsi, %rax
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L79:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L148
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L79
.L75:
	pxor	%xmm0, %xmm0
	cmpq	$0, 24(%rsp)
	movq	$0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	pxor	%xmm0, %xmm0
	jne	.L80
	movq	$0, 16(%rbx)
	movups	%xmm0, (%rbx)
.L74:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L191
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L80:
	.cfi_restore_state
	movl	$40, %edi
	movaps	%xmm0, 96(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
.LEHB0:
	call	_Znwm@PLT
.LEHE0:
	leaq	32(%rsp), %rdx
	movq	%rbp, (%rax)
	movq	.LC7(%rip), %xmm0
	movq	%rdx, 8(%rax)
	leaq	64(%rsp), %rdx
	cmpq	$0, 16(%r12)
	movq	%rdx, 16(%rax)
	leaq	24(%rsp), %rdx
	movq	%rdx, 24(%rax)
	leaq	63(%rsp), %rdx
	movq	%rdx, 32(%rax)
	movq	%rax, 96(%rsp)
	leaq	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_(%rip), %rax
	movq	%rax, %xmm3
	punpcklqdq	%xmm3, %xmm0
	movaps	%xmm0, 112(%rsp)
	je	.L192
	leaq	96(%rsp), %rbp
	movq	%r12, %rdi
	movq	%rbp, %rsi
.LEHB1:
	call	*24(%r12)
.LEHE1:
	movq	112(%rsp), %rax
	testq	%rax, %rax
	je	.L88
	movl	$3, %edx
	movq	%rbp, %rsi
	movq	%rbp, %rdi
	call	*%rax
.L88:
	movq	72(%rsp), %rdi
	movq	64(%rsp), %rdx
	movabsq	$9223372036854775792, %rax
	movq	%rdi, %rbp
	subq	%rdx, %rbp
	cmpq	%rbp, %rax
	jb	.L181
	testq	%rbp, %rbp
	jne	.L91
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
	cmpq	%rdx, %rdi
	je	.L93
.L92:
	movq	%r13, %r12
	jmp	.L123
	.p2align 4,,10
	.p2align 3
.L97:
	movq	%r10, 72(%rsp)
	movq	%r8, %xmm0
	cmpq	%r13, %rbp
	je	.L113
.L195:
	movq	64(%rsp), %rdx
	movq	%r10, %rdi
	movq	%r14, 0(%r13)
	addq	$16, %r13
	movq	%r8, -8(%r13)
	cmpq	%rdi, %rdx
	je	.L193
.L123:
	movq	%rdi, %rax
	movq	(%rdx), %r14
	movq	8(%rdx), %r8
	leaq	-16(%rdi), %r10
	subq	%rdx, %rax
	cmpq	$16, %rax
	jle	.L97
	movq	%r10, %rsi
	movdqu	(%rdx), %xmm0
	movq	-16(%rdi), %r15
	subq	%rdx, %rsi
	movsd	-8(%rdi), %xmm1
	movq	%rsi, %r11
	movups	%xmm0, -16(%rdi)
	sarq	$4, %r11
	leaq	-1(%r11), %rcx
	movq	%r11, %rax
	movq	%rcx, %r9
	andl	$1, %eax
	shrq	$63, %r9
	addq	%rcx, %r9
	sarq	%r9
	cmpq	$32, %rsi
	jle	.L98
	movq	%r14, 16(%rsp)
	xorl	%edi, %edi
	movq	%r11, %r14
	movq	%r8, %xmm4
	movq	%r10, %r11
	movq	%r12, 8(%rsp)
	movq	%rax, %r10
	movq	%r9, %rax
	jmp	.L101
	.p2align 4,,10
	.p2align 3
.L138:
	movq	%rcx, %rdi
.L101:
	leaq	1(%rdi), %r12
	leaq	(%r12,%r12), %r9
	salq	$5, %r12
	leaq	-1(%r9), %rcx
	addq	%rdx, %r12
	movq	%rcx, %rsi
	movsd	8(%r12), %xmm0
	salq	$4, %rsi
	addq	%rdx, %rsi
	movsd	8(%rsi), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L99
	ucomisd	%xmm0, %xmm2
	jp	.L137
	jne	.L137
	movq	(%r12), %r8
	cmpq	%r8, (%rsi)
	jg	.L99
.L137:
	movq	%r12, %rsi
	movq	%r9, %rcx
.L99:
	movdqu	(%rsi), %xmm0
	salq	$4, %rdi
	movups	%xmm0, (%rdx,%rdi)
	cmpq	%rax, %rcx
	jl	.L138
	movq	%r10, %rax
	movq	8(%rsp), %r12
	movq	%r11, %r10
	movq	%xmm4, %r8
	movq	%r14, %r11
	movq	16(%rsp), %r14
	testq	%rax, %rax
	jne	.L189
	subq	$2, %r11
	sarq	%r11
	cmpq	%r11, %rcx
	je	.L107
.L189:
	leaq	-1(%rcx), %rax
	movq	%rax, %rdi
	shrq	$63, %rdi
	addq	%rax, %rdi
	sarq	%rdi
	testq	%rcx, %rcx
	je	.L194
.L109:
	movq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movsd	8(%rax), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L110
	ucomisd	%xmm0, %xmm1
	jp	.L190
	jne	.L190
	cmpq	(%rax), %r15
	jg	.L110
.L190:
	salq	$4, %rcx
	addq	%rcx, %rdx
.L104:
	movq	%r15, (%rdx)
	movq	%r8, %xmm0
	movsd	%xmm1, 8(%rdx)
	movq	%r10, 72(%rsp)
	cmpq	%r13, %rbp
	jne	.L195
.L113:
	movabsq	$576460752303423487, %rax
	movq	%rbp, %rcx
	subq	%r12, %rcx
	movq	%rcx, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L182
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L118
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L119:
	movq	%r15, %rdi
	movq	%rcx, 16(%rsp)
	movsd	%xmm0, 8(%rsp)
.LEHB2:
	call	_Znwm@PLT
.LEHE2:
	movq	16(%rsp), %rcx
	movsd	8(%rsp), %xmm0
	movq	%rax, %r8
	leaq	(%rax,%rcx), %rax
	leaq	16(%r8,%rcx), %r13
	movq	%r14, (%rax)
	movsd	%xmm0, 8(%rax)
	testq	%rcx, %rcx
	jg	.L196
	testq	%r12, %r12
	jne	.L121
.L122:
	movq	72(%rsp), %rdi
	movq	64(%rsp), %rdx
	leaq	(%r8,%r15), %rbp
	movq	%r8, %r12
	cmpq	%rdi, %rdx
	jne	.L123
	.p2align 4
	.p2align 3
.L193:
	cmpq	%r13, %r12
	je	.L93
	leaq	-16(%r13), %rax
	cmpq	%rax, %r12
	jnb	.L93
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L126:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L126
.L93:
	movq	80(%rsp), %rsi
	movq	%r12, (%rbx)
	movq	%r13, 8(%rbx)
	movq	%rbp, 16(%rbx)
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L74
	call	_ZdlPvm@PLT
	jmp	.L74
	.p2align 4,,10
	.p2align 3
.L110:
	movdqu	(%rax), %xmm0
	leaq	-1(%rdi), %rsi
	salq	$4, %rcx
	movups	%xmm0, (%rdx,%rcx)
	movq	%rsi, %rcx
	shrq	$63, %rcx
	addq	%rsi, %rcx
	sarq	%rcx
	movq	%rcx, %rsi
	movq	%rdi, %rcx
	testq	%rdi, %rdi
	je	.L141
	movq	%rsi, %rdi
	jmp	.L109
	.p2align 4,,10
	.p2align 3
.L196:
	movq	%r8, %rdi
	movq	%rcx, %rdx
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %r8
.L121:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%r8, 8(%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
	jmp	.L122
	.p2align 4,,10
	.p2align 3
.L98:
	testq	%rax, %rax
	jne	.L104
	cmpq	$2, %rcx
	ja	.L104
	xorl	%ecx, %ecx
	movq	%rdx, %rsi
	.p2align 4
	.p2align 3
.L107:
	leaq	1(%rcx,%rcx), %rax
	movq	%rax, %rdi
	salq	$4, %rdi
	movdqu	(%rdx,%rdi), %xmm0
	movq	%rcx, %rdi
	movq	%rax, %rcx
	movups	%xmm0, (%rsi)
	jmp	.L109
	.p2align 4,,10
	.p2align 3
.L91:
	movq	%rbp, %rdi
.LEHB3:
	call	_Znwm@PLT
.LEHE3:
	movq	72(%rsp), %rdi
	movq	64(%rsp), %rdx
	movq	%rax, %r13
	addq	%rax, %rbp
	cmpq	%rdi, %rdx
	jne	.L92
	movq	%rax, %r12
	jmp	.L93
.L141:
	movq	%rax, %rdx
	jmp	.L104
.L194:
	movq	%rsi, %rdx
	jmp	.L104
.L191:
	call	__stack_chk_fail@PLT
.L118:
	movabsq	$9223372036854775792, %r15
	jmp	.L119
.L179:
	jmp	.L180
.L175:
	jmp	.L176
.L177:
	jmp	.L178
.L146:
	movq	%rax, %rbx
	jmp	.L84
.L192:
	jmp	.L82
	.section	.gcc_except_table,"a",@progbits
.LLSDA14318:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14318-.LLSDACSB14318
.LLSDACSB14318:
	.uleb128 .LEHB0-.LFB14318
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L146-.LFB14318
	.uleb128 0
	.uleb128 .LEHB1-.LFB14318
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L175-.LFB14318
	.uleb128 0
	.uleb128 .LEHB2-.LFB14318
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L177-.LFB14318
	.uleb128 0
	.uleb128 .LEHB3-.LFB14318
	.uleb128 .LEHE3-.LEHB3
	.uleb128 .L179-.LFB14318
	.uleb128 0
.LLSDACSE14318:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14318
	.type	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, @function
_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold:
.LFSB14318:
	nop
.L147:
	.cfi_def_cfa_offset 208
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
.L180:
	movq	%rax, %rbx
.L86:
	movq	64(%rsp), %rdi
	movq	80(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L132
	call	_ZdlPvm@PLT
.L132:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L197
	movq	%rbx, %rdi
.LEHB4:
	call	_Unwind_Resume@PLT
.LEHE4:
.L144:
.L176:
	movq	%rax, %rbx
	movq	112(%rsp), %rax
	testq	%rax, %rax
	je	.L86
	leaq	96(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L86
.L197:
	call	__stack_chk_fail@PLT
.L181:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L198
	leaq	.LC3(%rip), %rdi
.LEHB5:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE5:
.L198:
	call	__stack_chk_fail@PLT
.L145:
.L178:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L86
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L86
.L182:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L199
	leaq	.LC4(%rip), %rdi
.LEHB6:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE6:
.L199:
	call	__stack_chk_fail@PLT
.L148:
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB7:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE7:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L200
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB8:
	call	__cxa_throw@PLT
.LEHE8:
.L82:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L201
.LEHB9:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE9:
.L200:
	call	__stack_chk_fail@PLT
.L201:
	call	__stack_chk_fail@PLT
.L84:
	movq	112(%rsp), %rax
	testq	%rax, %rax
	je	.L86
	leaq	96(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L86
.L143:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L202
	movq	%rbp, %rdi
.LEHB10:
	call	_Unwind_Resume@PLT
.LEHE10:
.L202:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14318:
	.section	.gcc_except_table
.LLSDAC14318:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14318-.LLSDACSBC14318
.LLSDACSBC14318:
	.uleb128 .LEHB4-.LCOLDB8
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LCOLDB8
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L147-.LCOLDB8
	.uleb128 0
	.uleb128 .LEHB6-.LCOLDB8
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L145-.LCOLDB8
	.uleb128 0
	.uleb128 .LEHB7-.LCOLDB8
	.uleb128 .LEHE7-.LEHB7
	.uleb128 .L143-.LCOLDB8
	.uleb128 0
	.uleb128 .LEHB8-.LCOLDB8
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LCOLDB8
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L144-.LCOLDB8
	.uleb128 0
	.uleb128 .LEHB10-.LCOLDB8
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
.LLSDACSEC14318:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, .-_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	.section	.text.unlikely
	.size	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, .-_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold
.LCOLDE8:
	.text
.LHOTE8:
	.section	.text.unlikely
	.align 2
.LCOLDB10:
	.text
.LHOTB10:
	.align 2
	.p2align 4
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv:
.LFB14357:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14357
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	$16, %ecx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$280, %rsp
	.cfi_def_cfa_offset 336
	movq	%fs:40, %rax
	movq	%rax, 264(%rsp)
	xorl	%eax, %eax
	leaq	128(%rsp), %rdi
	movq	%rdi, 96(%rsp)
	rep stosq
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	jne	.L204
	movq	$0, 104(%rsp)
	movq	0(%r13), %r15
	xorl	%r12d, %r12d
	movq	(%r15), %r8
	cmpq	$1, %r8
	jbe	.L341
.L205:
	cmpq	$16, %r8
	jne	.L206
	movq	16(%r13), %rax
	movq	8(%rax), %r10
	testq	%r10, %r10
	je	.L215
.L218:
	movq	8(%r13), %rdx
	movq	(%rax), %rdi
	pxor	%xmm15, %xmm15
	leaq	(%r10,%r10,2), %r9
	movq	%r10, %r11
	leaq	(%r10,%r10,8), %r8
	salq	$2, %r9
	movaps	%xmm15, (%rsp)
	movq	(%rdx), %rax
	movq	%r10, %rdx
	salq	$5, %r11
	movaps	%xmm15, 16(%rsp)
	leaq	0(,%r10,4), %rbp
	salq	$4, %rdx
	salq	$2, %r8
	movaps	%xmm15, 32(%rsp)
	leaq	(%rax,%rbp), %rcx
	addq	%r10, %rbp
	movapd	%xmm15, %xmm13
	addq	%rax, %rdx
	leaq	0(,%rbp,4), %rbx
	leaq	0(,%rbp,8), %rsi
	movq	%rcx, %r14
	movaps	%xmm15, 48(%rsp)
	leaq	(%r10,%rbp,2), %rbp
	movapd	%xmm15, %xmm14
	movaps	%xmm15, 64(%rsp)
	salq	$2, %rbp
	.p2align 4
	.p2align 3
.L220:
	movss	(%rax,%r9), %xmm2
	movss	(%rcx,%r10,4), %xmm1
	pxor	%xmm0, %xmm0
	addq	$4, %rax
	movss	-4(%rax), %xmm3
	movss	-4(%rax,%rbx), %xmm4
	cvtss2sd	(%rdi), %xmm0
	unpcklpd	%xmm0, %xmm0
	unpcklps	%xmm2, %xmm1
	movss	(%rcx), %xmm2
	movapd	%xmm0, %xmm7
	movapd	%xmm0, %xmm6
	movss	-4(%rax,%rsi), %xmm5
	addq	$4, %rdi
	addq	$4, %rcx
	addq	$4, %rdx
	unpcklps	%xmm2, %xmm3
	movss	-4(%rdx,%r9), %xmm2
	movss	-4(%rdx,%r11), %xmm8
	movlhps	%xmm1, %xmm3
	movss	-4(%rcx,%rbx), %xmm1
	movhlps	%xmm3, %xmm9
	unpcklps	%xmm2, %xmm1
	movss	-4(%rdx), %xmm2
	unpcklps	%xmm4, %xmm2
	movss	-4(%rax,%r8), %xmm4
	movlhps	%xmm1, %xmm2
	movss	-4(%rcx,%rsi), %xmm1
	movhlps	%xmm2, %xmm10
	unpcklps	%xmm1, %xmm5
	movss	-4(%rax,%r11), %xmm1
	unpcklps	%xmm4, %xmm1
	movss	-4(%rdx,%rbp), %xmm4
	movlhps	%xmm5, %xmm1
	movss	-4(%rdx,%rsi), %xmm5
	movhlps	%xmm1, %xmm11
	unpcklps	%xmm4, %xmm5
	movss	-4(%rdx,%r8), %xmm4
	unpcklps	%xmm4, %xmm8
	cvtps2pd	%xmm3, %xmm4
	cvtps2pd	%xmm9, %xmm3
	subpd	%xmm4, %xmm7
	movlhps	%xmm5, %xmm8
	movapd	%xmm0, %xmm5
	subpd	%xmm3, %xmm6
	cvtps2pd	%xmm2, %xmm3
	movapd	%xmm0, %xmm4
	subpd	%xmm3, %xmm5
	movapd	%xmm0, %xmm3
	cvtps2pd	%xmm10, %xmm2
	subpd	%xmm2, %xmm4
	cvtps2pd	%xmm1, %xmm2
	movhlps	%xmm8, %xmm12
	subpd	%xmm2, %xmm3
	cvtps2pd	%xmm11, %xmm1
	mulpd	%xmm7, %xmm7
	movapd	%xmm0, %xmm2
	subpd	%xmm1, %xmm2
	cvtps2pd	%xmm8, %xmm1
	cvtps2pd	%xmm12, %xmm8
	movaps	%xmm1, 80(%rsp)
	mulpd	%xmm5, %xmm5
	movapd	%xmm0, %xmm1
	subpd	%xmm8, %xmm0
	subpd	80(%rsp), %xmm1
	mulpd	%xmm4, %xmm4
	addpd	64(%rsp), %xmm7
	mulpd	%xmm6, %xmm6
	mulpd	%xmm0, %xmm0
	addpd	48(%rsp), %xmm6
	mulpd	%xmm3, %xmm3
	movaps	%xmm7, 64(%rsp)
	mulpd	%xmm2, %xmm2
	addpd	32(%rsp), %xmm3
	addpd	%xmm5, %xmm14
	mulpd	%xmm1, %xmm1
	addpd	16(%rsp), %xmm2
	addpd	%xmm4, %xmm13
	movaps	%xmm6, 48(%rsp)
	addpd	(%rsp), %xmm1
	addpd	%xmm0, %xmm15
	movaps	%xmm3, 32(%rsp)
	movaps	%xmm2, 16(%rsp)
	movaps	%xmm1, (%rsp)
	cmpq	%rax, %r14
	jne	.L220
	movaps	%xmm7, 128(%rsp)
	movapd	32(%rsp), %xmm7
	movaps	%xmm6, 144(%rsp)
	movapd	16(%rsp), %xmm6
	movaps	%xmm7, 192(%rsp)
	movapd	(%rsp), %xmm7
	movaps	%xmm14, 160(%rsp)
	movaps	%xmm13, 176(%rsp)
	movaps	%xmm6, 208(%rsp)
	movaps	%xmm7, 224(%rsp)
	movaps	%xmm15, 240(%rsp)
.L215:
	testq	%r12, %r12
	je	.L207
.L209:
	call	__errno_location@PLT
	movl	(%rax), %ebp
	movq	%rax, %rbx
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	104(%rsp), %rdi
	movq	0(%r13), %r15
	subq	%rdi, %rax
	addq	%rax, 16(%r12)
	movl	%ebp, (%rbx)
.L207:
	movq	(%r15), %rdx
	testq	%rdx, %rdx
	je	.L223
	xorl	%r9d, %r9d
	pxor	%xmm3, %xmm3
	movq	%r9, %r12
	jmp	.L275
	.p2align 4,,10
	.p2align 3
.L343:
	ucomisd	%xmm0, %xmm1
	jp	.L340
	jne	.L340
	cmpq	%r14, (%rax)
	jl	.L272
.L340:
	salq	$4, %rdx
	leaq	(%rbx,%rdx), %rax
.L271:
	movq	%r14, (%rax)
	movq	(%r15), %rdx
	movsd	%xmm0, 8(%rax)
.L228:
	addq	$1, %r12
	cmpq	%rdx, %r12
	jnb	.L223
.L275:
	movq	24(%r13), %rax
	movq	(%rax,%r12,8), %r14
	movq	96(%rsp), %rax
	movsd	(%rax,%r12,8), %xmm0
	ucomisd	%xmm0, %xmm3
	ja	.L326
	movq	32(%r13), %rbp
	movq	40(%r13), %rax
	sqrtsd	%xmm0, %xmm0
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rsi
	subq	%rbx, %rsi
	movq	%rsi, %r8
	sarq	$4, %r8
	movq	%r8, %rdi
	cmpq	(%rax), %r8
	jb	.L226
	movsd	8(%rbx), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L244
	ucomisd	%xmm1, %xmm0
	jp	.L228
	jne	.L228
	cmpq	(%rbx), %r14
	jge	.L228
.L244:
	leaq	-16(%rcx), %r10
	cmpq	$16, %rsi
	jg	.L342
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	je	.L262
.L347:
	movq	%r14, -16(%rcx)
	movsd	%xmm0, -8(%rcx)
	movq	%rcx, 8(%rbp)
.L263:
	leaq	-1(%r8), %rdx
	subq	$2, %r8
	movq	%r8, %rcx
	movq	%rdx, %rax
	shrq	$63, %rcx
	salq	$4, %rax
	addq	%r8, %rcx
	addq	%rbx, %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L271
.L270:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbx, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	jbe	.L343
.L272:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rbx,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L271
	movq	%rsi, %rcx
	jmp	.L270
	.p2align 4,,10
	.p2align 3
.L204:
	movaps	%xmm12, 48(%rsp)
	movaps	%xmm11, 32(%rsp)
	movaps	%xmm10, 16(%rsp)
	movaps	%xmm9, (%rsp)
	call	__errno_location@PLT
	movl	(%rax), %ebp
	movq	%rax, %rbx
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	%rax, 120(%rsp)
	movq	%rax, 104(%rsp)
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movq	0(%r13), %r15
	movaps	(%rsp), %xmm9
	movaps	16(%rsp), %xmm10
	movl	%ebp, (%rbx)
	movq	(%r15), %r8
	movaps	32(%rsp), %xmm11
	movaps	48(%rsp), %xmm12
	cmpq	$1, %r8
	jbe	.L344
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	je	.L345
	movq	%fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff, %rdx
	movl	$1, %eax
	leaq	_ZN12minivectordb7profile6detail8countersE@tpoff, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L212:
	addq	$1, %rdx
	addq	$1, %rax
	movq	%rdx, %fs:168(%rcx)
	movq	(%r15), %r8
	cmpq	%r8, %rax
	jb	.L212
	cmpq	$16, %r8
	je	.L213
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
	testq	%r8, %r8
	je	.L214
.L206:
	movq	16(%r13), %rax
	movq	8(%rax), %rcx
	leaq	0(,%rcx,4), %r10
	testq	%rcx, %rcx
	je	.L215
	movq	8(%r13), %r11
	movq	(%rax), %rsi
	xorl	%r9d, %r9d
	xorl	%edi, %edi
	movq	96(%rsp), %rbx
	.p2align 4
	.p2align 3
.L216:
	movq	(%r11), %rdx
	movsd	(%rbx,%rdi,8), %xmm1
	xorl	%eax, %eax
	addq	%r9, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L222:
	pxor	%xmm0, %xmm0
	pxor	%xmm2, %xmm2
	cvtss2sd	(%rsi,%rax,4), %xmm0
	cvtss2sd	(%rdx,%rax,4), %xmm2
	subsd	%xmm2, %xmm0
	addq	$1, %rax
	mulsd	%xmm0, %xmm0
	addsd	%xmm0, %xmm1
	cmpq	%rcx, %rax
	jne	.L222
	movsd	%xmm1, (%rbx,%rdi,8)
	addq	$1, %rdi
	addq	%r10, %r9
	cmpq	%r8, %rdi
	jne	.L216
	jmp	.L215
	.p2align 4,,10
	.p2align 3
.L226:
	cmpq	16(%rbp), %rcx
	je	.L229
	movq	%r14, (%rcx)
	leaq	16(%rcx), %r14
	movsd	%xmm0, 8(%rcx)
	movq	%r14, 8(%rbp)
.L230:
	movq	0(%rbp), %rdi
	movq	%r14, %rcx
	movq	-16(%r14), %r8
	subq	%rdi, %rcx
	movq	%rcx, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	subq	$2, %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	leaq	-16(%rdi,%rcx), %rax
	sarq	%rsi
	testq	%rdx, %rdx
	jle	.L240
.L239:
	movq	%rsi, %rax
	salq	$4, %rax
	addq	%rdi, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L241
	ucomisd	%xmm0, %xmm1
	jp	.L337
	jne	.L337
	cmpq	(%rax), %r8
	jg	.L241
.L337:
	salq	$4, %rdx
	leaq	(%rdi,%rdx), %rax
.L240:
	movq	%r8, (%rax)
	movq	(%r15), %rdx
	addq	$1, %r12
	movsd	%xmm0, 8(%rax)
	cmpq	%rdx, %r12
	jb	.L275
.L223:
	movq	$0, (%r15)
	movq	264(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L346
	addq	$280, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L241:
	.cfi_restore_state
	movdqu	(%rax), %xmm1
	leaq	-1(%rsi), %rcx
	salq	$4, %rdx
	movups	%xmm1, (%rdi,%rdx)
	movq	%rcx, %rdx
	shrq	$63, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	sarq	%rcx
	testq	%rsi, %rsi
	je	.L240
	movq	%rcx, %rsi
	jmp	.L239
	.p2align 4,,10
	.p2align 3
.L342:
	movq	%r10, %rsi
	movdqu	(%rbx), %xmm1
	movq	-16(%rcx), %r9
	subq	%rbx, %rsi
	movsd	-8(%rcx), %xmm2
	movq	%rsi, %rax
	movups	%xmm1, -16(%rcx)
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	movq	%rax, %rdi
	movq	%rdx, %r11
	andl	$1, %edi
	shrq	$63, %r11
	movq	%rdi, (%rsp)
	addq	%rdx, %r11
	sarq	%r11
	cmpq	$32, %rsi
	jle	.L247
	movq	%r14, 16(%rsp)
	xorl	%edi, %edi
	movq	%rbp, 32(%rsp)
	movq	%rax, 48(%rsp)
	jmp	.L250
	.p2align 4,,10
	.p2align 3
.L285:
	movq	%rsi, %rdi
.L250:
	leaq	1(%rdi), %rbp
	leaq	(%rbp,%rbp), %r14
	salq	$5, %rbp
	leaq	-1(%r14), %rsi
	addq	%rbx, %rbp
	movq	%rsi, %rdx
	movsd	8(%rbp), %xmm1
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm4
	comisd	%xmm1, %xmm4
	ja	.L248
	ucomisd	%xmm1, %xmm4
	jp	.L284
	jne	.L284
	movq	0(%rbp), %rax
	cmpq	%rax, (%rdx)
	jg	.L248
.L284:
	movq	%rbp, %rdx
	movq	%r14, %rsi
.L248:
	movdqu	(%rdx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, (%rbx,%rdi)
	cmpq	%rsi, %r11
	jg	.L285
	cmpq	$0, (%rsp)
	movq	16(%rsp), %r14
	movq	32(%rsp), %rbp
	movq	48(%rsp), %rax
	jne	.L338
	subq	$2, %rax
	sarq	%rax
	cmpq	%rsi, %rax
	je	.L256
.L338:
	leaq	-1(%rsi), %rdi
	movq	%rdi, %rax
	shrq	$63, %rax
	addq	%rdi, %rax
	sarq	%rax
	testq	%rsi, %rsi
	je	.L253
.L258:
	movq	%rax, %rdx
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L259
	ucomisd	%xmm1, %xmm2
	jp	.L339
	jne	.L339
	cmpq	%r9, (%rdx)
	jl	.L259
.L339:
	salq	$4, %rsi
	leaq	(%rbx,%rsi), %rdx
.L253:
	movq	%r9, (%rdx)
	movsd	%xmm2, 8(%rdx)
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	jne	.L347
.L262:
	movabsq	$576460752303423487, %rdx
	subq	%rbx, %r10
	movq	%r10, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L264
	testq	%rax, %rax
	movl	$1, %edx
	cmovne	%rax, %rdx
	addq	%rdx, %rax
	jc	.L266
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r15
	salq	$4, %r15
.L267:
	movq	%r15, %rdi
	movq	%r10, 16(%rsp)
	movsd	%xmm0, (%rsp)
.LEHB11:
	call	_Znwm@PLT
	movq	16(%rsp), %r10
	movsd	(%rsp), %xmm0
	movq	%rax, %rcx
	leaq	(%rax,%r10), %rax
	movq	%r14, (%rax)
	leaq	16(%r10), %r14
	movsd	%xmm0, 8(%rax)
	leaq	(%rcx,%r14), %r11
	testq	%r10, %r10
	jg	.L348
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
.L269:
	movq	%rbx, %rdi
	movq	%r11, 16(%rsp)
	sarq	$4, %r14
	movq	%rcx, (%rsp)
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	movq	%r14, %r8
	pxor	%xmm3, %xmm3
	movq	16(%rsp), %r11
	addq	%rcx, %r15
	movq	%rcx, 0(%rbp)
	movq	%rcx, %rbx
	movq	-16(%r11), %r14
	movsd	-8(%r11), %xmm0
	movq	%r15, 16(%rbp)
	movq	%r11, 8(%rbp)
	movq	0(%r13), %r15
	jmp	.L263
	.p2align 4,,10
	.p2align 3
.L259:
	movdqu	(%rdx), %xmm1
	leaq	-1(%rax), %rdi
	salq	$4, %rsi
	movups	%xmm1, (%rbx,%rsi)
	movq	%rdi, %rsi
	shrq	$63, %rsi
	addq	%rdi, %rsi
	movq	%rsi, %rdi
	movq	%rax, %rsi
	sarq	%rdi
	testq	%rax, %rax
	je	.L253
	movq	%rdi, %rax
	jmp	.L258
.L229:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	je	.L264
	testq	%rdi, %rdi
	movl	$1, %eax
	cmovne	%rdi, %rax
	addq	%rax, %rdi
	jc	.L234
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	cmovbe	%rdi, %rax
	movq	%rax, %r15
	salq	$4, %r15
.L235:
	movq	%r15, %rdi
	movq	%rsi, 16(%rsp)
	movsd	%xmm0, (%rsp)
	call	_Znwm@PLT
.LEHE11:
	movq	16(%rsp), %rsi
	movsd	(%rsp), %xmm0
	pxor	%xmm3, %xmm3
	movq	%rax, %rcx
	testq	%rsi, %rsi
	leaq	(%rax,%rsi), %rax
	movq	%r14, (%rax)
	leaq	16(%rcx,%rsi), %r14
	movsd	%xmm0, 8(%rax)
	jg	.L349
	testq	%rbx, %rbx
	jne	.L350
.L238:
	movq	%rcx, 0(%rbp)
	addq	%r15, %rcx
	movsd	-8(%r14), %xmm0
	movq	%r14, 8(%rbp)
	movq	0(%r13), %r15
	movq	%rcx, 16(%rbp)
	jmp	.L230
.L348:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r10, %rdx
	movq	%r11, (%rsp)
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	(%rsp), %r11
	movq	%rax, %rcx
	subq	%rbx, %rsi
	jmp	.L269
.L344:
	testq	%r8, %r8
	je	.L214
	movq	%fs:0, %rax
	movl	$1, %r8d
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
	jmp	.L206
.L341:
	testq	%r8, %r8
	je	.L207
	movl	$1, %r8d
	jmp	.L206
.L213:
	movq	%fs:0, %rbx
	movq	16(%r13), %rax
	movq	8(%rax), %r10
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rbx), %r12
	testq	%r10, %r10
	jne	.L218
.L214:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
	jmp	.L209
.L349:
	movq	%rsi, %rdx
	movq	%rcx, %rdi
	movq	%rbx, %rsi
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	%rax, %rcx
	subq	%rbx, %rsi
.L237:
	movq	%rbx, %rdi
	movq	%rcx, (%rsp)
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	pxor	%xmm3, %xmm3
	jmp	.L238
.L252:
	cmpq	$2, %rdx
	movq	%rbx, %rdx
	ja	.L253
	xorl	%esi, %esi
.L256:
	leaq	1(%rsi,%rsi), %rdi
	movq	%rdi, %rax
	salq	$4, %rax
	movdqu	(%rbx,%rax), %xmm1
	movq	%rsi, %rax
	movq	%rdi, %rsi
	movups	%xmm1, (%rdx)
	jmp	.L258
.L247:
	cmpq	$0, (%rsp)
	je	.L252
	movq	%rbx, %rdx
	jmp	.L253
.L350:
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
	jmp	.L237
.L326:
	call	sqrt@PLT
	movq	32(%r13), %rbp
	movq	40(%r13), %rax
	pxor	%xmm3, %xmm3
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rsi
	subq	%rbx, %rsi
	movq	%rsi, %rdi
	sarq	$4, %rdi
	cmpq	(%rax), %rdi
	jb	.L226
	movq	0(%r13), %r15
	movq	(%r15), %rdx
	jmp	.L228
.L346:
	call	__stack_chk_fail@PLT
.L266:
	movabsq	$9223372036854775792, %r15
	jmp	.L267
.L234:
	movabsq	$9223372036854775792, %r15
	jmp	.L235
.L345:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
	jmp	.L205
	.section	.gcc_except_table
.LLSDA14357:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14357-.LLSDACSB14357
.LLSDACSB14357:
	.uleb128 .LEHB11-.LFB14357
	.uleb128 .LEHE11-.LEHB11
	.uleb128 0
	.uleb128 0
.LLSDACSE14357:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14357
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold:
.LFSB14357:
.L264:
	.cfi_def_cfa_offset 336
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	264(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L351
	leaq	.LC4(%rip), %rdi
.LEHB12:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE12:
.L351:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14357:
	.section	.gcc_except_table
.LLSDAC14357:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14357-.LLSDACSBC14357
.LLSDACSBC14357:
	.uleb128 .LEHB12-.LCOLDB10
	.uleb128 .LEHE12-.LEHB12
	.uleb128 0
	.uleb128 0
.LLSDACSEC14357:
	.section	.text.unlikely
	.text
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, .-_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
	.section	.text.unlikely
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, .-_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold
.LCOLDE10:
	.text
.LHOTE10:
	.section	.rodata.str1.1
.LC11:
	.string	"VECTOR dimension mismatch"
	.section	.text.unlikely
.LCOLDB12:
	.text
.LHOTB12:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_:
.LFB15166:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA15166
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	(%rsi), %r12
	movq	(%rdx), %r13
	movq	%fs:40, %rbx
	movq	%rbx, 8(%rsp)
	movq	(%rdi), %rbx
	movq	8(%rdx), %rbp
	movq	(%rbx), %rax
	cmpq	$0, 16(%rax)
	je	.L356
	movq	%r12, (%rsp)
	movq	%rsp, %rsi
	movq	%rax, %rdi
.LEHB13:
	call	*24(%rax)
	testb	%al, %al
	je	.L352
.L356:
	movq	8(%rbx), %rdx
	cmpq	%rbp, 8(%rdx)
	jne	.L373
	movq	24(%rbx), %rcx
	movq	16(%rbx), %rax
	movq	32(%rbx), %rdi
	movq	(%rcx), %rsi
	movq	%r12, (%rax,%rsi,8)
	movq	8(%rdx), %rsi
	movq	(%rcx), %rax
	movq	(%rdi), %rdx
	imulq	%rax, %rsi
	leaq	(%rdx,%rsi,4), %rdi
	leaq	0(,%rbp,4), %rdx
	cmpq	$4, %rdx
	jle	.L359
	movq	%r13, %rsi
	call	memmove@PLT
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
.L360:
	addq	$1, %rax
	movq	%rax, (%rcx)
	cmpq	$16, %rax
	je	.L374
.L352:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L372
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L374:
	.cfi_restore_state
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L372
	movq	40(%rbx), %rdi
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	jmp	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE13:
	.p2align 4,,10
	.p2align 3
.L359:
	.cfi_restore_state
	jne	.L360
	movss	0(%r13), %xmm0
	movss	%xmm0, (%rdi)
	jmp	.L360
.L372:
	call	__stack_chk_fail@PLT
.L373:
	jmp	.L354
	.section	.gcc_except_table
.LLSDA15166:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE15166-.LLSDACSB15166
.LLSDACSB15166:
	.uleb128 .LEHB13-.LFB15166
	.uleb128 .LEHE13-.LEHB13
	.uleb128 0
	.uleb128 0
.LLSDACSE15166:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC15166
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold:
.LFSB15166:
.L354:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 13, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC11(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB14:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE14:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L371
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB15:
	call	__cxa_throw@PLT
.L368:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L371
	movq	%rbp, %rdi
	call	_Unwind_Resume@PLT
.LEHE15:
.L371:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE15166:
	.section	.gcc_except_table
.LLSDAC15166:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC15166-.LLSDACSBC15166
.LLSDACSBC15166:
	.uleb128 .LEHB14-.LCOLDB12
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L368-.LCOLDB12
	.uleb128 0
	.uleb128 .LEHB15-.LCOLDB12
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
.LLSDACSEC15166:
	.section	.text.unlikely
	.text
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold
.LCOLDE12:
	.text
.LHOTE12:
	.section	.text.unlikely
.LCOLDB15:
	.text
.LHOTB15:
	.p2align 4
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, @function
_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE:
.LFB14328:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14328
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %rax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%r8, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$360, %rsp
	.cfi_def_cfa_offset 416
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
	movq	24(%rsp), %rsi
	movq	%rcx, 8(%rsp)
	leaq	(%rax,%rsi,4), %rdx
	movq	%fs:40, %r12
	movq	%r12, 344(%rsp)
	movq	%r9, %r12
	cmpq	%rdx, %rax
	je	.L376
	movss	.LC1(%rip), %xmm1
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L380:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L454
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L380
.L376:
	movq	8(%rsp), %rcx
	testq	%rcx, %rcx
	jne	.L381
	movq	$0, 16(%rbx)
	pxor	%xmm0, %xmm0
	movups	%xmm0, (%rbx)
.L375:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L510
	addq	$360, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L381:
	.cfi_restore_state
	leaq	-16(%rsi), %rax
	cmpq	$1008, %rax
	jbe	.L383
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	%rbx, %rdi
.LEHB16:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE16:
	jmp	.L375
	.p2align 4,,10
	.p2align 3
.L383:
	pxor	%xmm0, %xmm0
	salq	$6, %rsi
	movl	$16, %ecx
	xorl	%eax, %eax
	leaq	208(%rsp), %rdi
	movaps	%xmm0, 80(%rsp)
	pxor	%xmm0, %xmm0
	movq	%rsi, %r13
	movq	%rdi, (%rsp)
	rep stosq
	movq	%rsi, %rdi
	movaps	%xmm0, 48(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 64(%rsp)
.LEHB17:
	call	_Znwm@PLT
.LEHE17:
	movl	$0x00000000, (%rax)
	movq	%rax, %r15
	leaq	-4(%r13), %rdx
	xorl	%esi, %esi
	leaq	4(%rax), %rdi
	leaq	(%rax,%r13), %r14
	leaq	48(%rsp), %r13
	call	memset@PLT
	movq	%r15, 48(%rsp)
	leaq	40(%rsp), %r15
	movq	%r13, %xmm3
	movq	%r15, %xmm0
	movq	%r14, 56(%rsp)
	leaq	80(%rsp), %rax
	movl	$48, %edi
	punpcklqdq	%xmm3, %xmm0
	movq	%r14, 64(%rsp)
	leaq	16(%rsp), %r14
	movaps	%xmm0, 112(%rsp)
	movq	%r14, %xmm0
	movq	$0, 40(%rsp)
	movhps	(%rsp), %xmm0
	movaps	%xmm0, 128(%rsp)
	movq	%rax, %xmm0
	leaq	8(%rsp), %rax
	movq	%rax, %xmm4
	leaq	39(%rsp), %rax
	movq	$0, 192(%rsp)
	punpcklqdq	%xmm4, %xmm0
	movq	%rax, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	pxor	%xmm0, %xmm0
	movq	$0, 200(%rsp)
	movaps	%xmm0, 176(%rsp)
.LEHB18:
	call	_Znwm@PLT
.LEHE18:
	movq	(%rsp), %rdi
	movq	%r13, 32(%rax)
	leaq	112(%rsp), %r13
	movq	%r12, (%rax)
	cmpq	$0, 16(%rbp)
	movq	%r14, 8(%rax)
	movq	.LC14(%rip), %xmm0
	movq	%rdi, 16(%rax)
	movq	%r15, 24(%rax)
	movq	%r13, 40(%rax)
	movq	%rax, 176(%rsp)
	leaq	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_(%rip), %rax
	movq	%rax, %xmm5
	punpcklqdq	%xmm5, %xmm0
	movaps	%xmm0, 192(%rsp)
	je	.L511
	leaq	176(%rsp), %r12
	movq	%rbp, %rdi
	movq	%r12, %rsi
.LEHB19:
	call	*24(%rbp)
.LEHE19:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L390
	movl	$3, %edx
	movq	%r12, %rsi
	movq	%r12, %rdi
	call	*%rax
.L390:
	cmpq	$0, 40(%rsp)
	je	.L391
	movq	%r13, %rdi
.LEHB20:
	call	_ZZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE20:
.L391:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movabsq	$9223372036854775792, %rdx
	movq	%rax, %rbp
	subq	%r13, %rbp
	cmpq	%rbp, %rdx
	jb	.L499
	testq	%rbp, %rbp
	jne	.L394
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	cmpq	%r13, %rax
	je	.L396
.L395:
	movq	%r14, %r12
	jmp	.L423
	.p2align 4,,10
	.p2align 3
.L407:
	movq	%r9, 88(%rsp)
	cmpq	%r9, %r13
	je	.L512
.L423:
	cmpq	%r14, %rbp
	je	.L397
	movdqu	0(%r13), %xmm0
	addq	$16, %r14
	movups	%xmm0, -16(%r14)
.L398:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movq	%rax, %rdx
	leaq	-16(%rax), %r9
	subq	%r13, %rdx
	cmpq	$16, %rdx
	jle	.L407
	movq	%r9, %rdx
	movdqu	0(%r13), %xmm0
	movq	-16(%rax), %r11
	subq	%r13, %rdx
	movsd	-8(%rax), %xmm1
	movq	%rdx, %r10
	movups	%xmm0, -16(%rax)
	sarq	$4, %r10
	leaq	-1(%r10), %rax
	movq	%r10, %r15
	movq	%rax, %r8
	andl	$1, %r15d
	shrq	$63, %r8
	addq	%rax, %r8
	sarq	%r8
	cmpq	$32, %rdx
	jle	.L408
	movq	%r9, (%rsp)
	xorl	%esi, %esi
	jmp	.L411
	.p2align 4,,10
	.p2align 3
.L445:
	movq	%rcx, %rsi
.L411:
	leaq	1(%rsi), %rax
	leaq	(%rax,%rax), %rdi
	salq	$5, %rax
	leaq	-1(%rdi), %rcx
	addq	%r13, %rax
	movq	%rcx, %rdx
	movsd	8(%rax), %xmm0
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L409
	ucomisd	%xmm0, %xmm2
	jp	.L444
	jne	.L444
	movq	(%rax), %r9
	cmpq	%r9, (%rdx)
	jg	.L409
.L444:
	movq	%rax, %rdx
	movq	%rdi, %rcx
.L409:
	movdqu	(%rdx), %xmm0
	salq	$4, %rsi
	movups	%xmm0, 0(%r13,%rsi)
	cmpq	%r8, %rcx
	jl	.L445
	movq	(%rsp), %r9
	testq	%r15, %r15
	jne	.L508
	subq	$2, %r10
	sarq	%r10
	cmpq	%rcx, %r10
	je	.L417
.L508:
	leaq	-1(%rcx), %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L414
.L419:
	movq	%rsi, %rdx
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L420
	ucomisd	%xmm0, %xmm1
	jp	.L509
	jne	.L509
	cmpq	(%rdx), %r11
	jg	.L420
.L509:
	salq	$4, %rcx
	leaq	0(%r13,%rcx), %rdx
.L414:
	movq	%r11, (%rdx)
	movsd	%xmm1, 8(%rdx)
	jmp	.L407
	.p2align 4,,10
	.p2align 3
.L420:
	movdqu	(%rdx), %xmm0
	salq	$4, %rcx
	movups	%xmm0, 0(%r13,%rcx)
	leaq	-1(%rsi), %rcx
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rcx, %rax
	movq	%rsi, %rcx
	sarq	%rax
	testq	%rsi, %rsi
	je	.L414
	movq	%rax, %rsi
	jmp	.L419
	.p2align 4,,10
	.p2align 3
.L397:
	movabsq	$576460752303423487, %rax
	movq	%rbp, %rsi
	subq	%r12, %rsi
	movq	%rsi, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L500
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L402
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L403:
	movq	%r15, %rdi
	movq	%rsi, (%rsp)
.LEHB21:
	call	_Znwm@PLT
.LEHE21:
	movq	(%rsp), %rsi
	movdqu	0(%r13), %xmm0
	movq	%rax, %rcx
	movups	%xmm0, (%rax,%rsi)
	leaq	16(%rax,%rsi), %r14
	testq	%rsi, %rsi
	jg	.L513
	testq	%r12, %r12
	jne	.L405
.L406:
	leaq	(%rcx,%r15), %rbp
	movq	%rcx, %r12
	jmp	.L398
	.p2align 4,,10
	.p2align 3
.L512:
	cmpq	%r14, %r12
	je	.L396
	leaq	-16(%r14), %rax
	cmpq	%rax, %r12
	jnb	.L396
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L425:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L425
.L396:
	movq	%r12, (%rbx)
	movq	%r14, 8(%rbx)
	movq	%rbp, 16(%rbx)
.L431:
	movq	48(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L426
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L426:
	movq	80(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L375
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	jmp	.L375
.L513:
	movq	%rsi, %rdx
	movq	%rax, %rdi
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %rcx
.L405:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%rcx, (%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L406
.L408:
	movq	%r13, %rdx
	testq	%r15, %r15
	jne	.L414
	cmpq	$2, %rax
	ja	.L414
	xorl	%ecx, %ecx
.L417:
	leaq	1(%rcx,%rcx), %rax
	movq	%rax, %rsi
	salq	$4, %rsi
	movdqu	0(%r13,%rsi), %xmm0
	movq	%rcx, %rsi
	movq	%rax, %rcx
	movups	%xmm0, (%rdx)
	jmp	.L419
.L394:
	movq	%rbp, %rdi
.LEHB22:
	call	_Znwm@PLT
.LEHE22:
	movq	80(%rsp), %r13
	movq	%rax, %r14
	addq	%rax, %rbp
	cmpq	88(%rsp), %r13
	jne	.L395
	movq	%rax, %r12
	jmp	.L396
.L402:
	movabsq	$9223372036854775792, %r15
	jmp	.L403
.L510:
	call	__stack_chk_fail@PLT
.L453:
	movq	%rax, %rbx
	jmp	.L386
.L448:
	movq	%rax, %rdi
	movq	%rdx, %rax
	jmp	.L429
.L497:
	jmp	.L498
.L495:
	jmp	.L496
.L511:
	jmp	.L384
.L493:
	jmp	.L494
	.section	.gcc_except_table
	.align 4
.LLSDA14328:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT14328-.LLSDATTD14328
.LLSDATTD14328:
	.byte	0x1
	.uleb128 .LLSDACSE14328-.LLSDACSB14328
.LLSDACSB14328:
	.uleb128 .LEHB16-.LFB14328
	.uleb128 .LEHE16-.LEHB16
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB17-.LFB14328
	.uleb128 .LEHE17-.LEHB17
	.uleb128 .L448-.LFB14328
	.uleb128 0x3
	.uleb128 .LEHB18-.LFB14328
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L453-.LFB14328
	.uleb128 0
	.uleb128 .LEHB19-.LFB14328
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L495-.LFB14328
	.uleb128 0
	.uleb128 .LEHB20-.LFB14328
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L493-.LFB14328
	.uleb128 0
	.uleb128 .LEHB21-.LFB14328
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L497-.LFB14328
	.uleb128 0
	.uleb128 .LEHB22-.LFB14328
	.uleb128 .LEHE22-.LEHB22
	.uleb128 .L493-.LFB14328
	.uleb128 0
.LLSDACSE14328:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATT14328:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14328
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, @function
_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold:
.LFSB14328:
.L454:
	.cfi_def_cfa_offset 416
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB23:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE23:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L514
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB24:
	call	__cxa_throw@PLT
.LEHE24:
.L500:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L515
	leaq	.LC4(%rip), %rdi
.LEHB25:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE25:
.L386:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L388
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
.L388:
	movq	48(%rsp), %rdi
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L437
	call	_ZdlPvm@PLT
.L437:
	movq	80(%rsp), %rdi
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L438
	call	_ZdlPvm@PLT
.L438:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L516
	movq	%rbx, %rdi
.LEHB26:
	call	_Unwind_Resume@PLT
.LEHE26:
.L429:
	subq	$1, %rax
	jne	.L517
	call	__cxa_begin_catch@PLT
	movq	8(%rsp), %rcx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%rbx, %rdi
.LEHB27:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE27:
	call	__cxa_end_catch@PLT
	jmp	.L431
.L516:
	call	__stack_chk_fail@PLT
.L515:
	call	__stack_chk_fail@PLT
.L517:
	movq	%rdi, %rbx
	jmp	.L388
.L452:
.L498:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L388
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L388
.L450:
	movq	%rax, %rbx
	call	__cxa_end_catch@PLT
	jmp	.L388
.L499:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L518
	leaq	.LC3(%rip), %rdi
.LEHB28:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE28:
.L514:
	call	__stack_chk_fail@PLT
.L451:
.L496:
	movq	%rax, %rbx
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L388
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L388
.L384:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L519
.LEHB29:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE29:
.L519:
	call	__stack_chk_fail@PLT
.L449:
.L494:
	movq	%rax, %rbx
	jmp	.L388
.L447:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L520
	movq	%rbp, %rdi
.LEHB30:
	call	_Unwind_Resume@PLT
.LEHE30:
.L518:
	call	__stack_chk_fail@PLT
.L520:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14328:
	.section	.gcc_except_table
	.align 4
.LLSDAC14328:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATTC14328-.LLSDATTDC14328
.LLSDATTDC14328:
	.byte	0x1
	.uleb128 .LLSDACSEC14328-.LLSDACSBC14328
.LLSDACSBC14328:
	.uleb128 .LEHB23-.LCOLDB15
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L447-.LCOLDB15
	.uleb128 0
	.uleb128 .LEHB24-.LCOLDB15
	.uleb128 .LEHE24-.LEHB24
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB25-.LCOLDB15
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L452-.LCOLDB15
	.uleb128 0
	.uleb128 .LEHB26-.LCOLDB15
	.uleb128 .LEHE26-.LEHB26
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB27-.LCOLDB15
	.uleb128 .LEHE27-.LEHB27
	.uleb128 .L450-.LCOLDB15
	.uleb128 0
	.uleb128 .LEHB28-.LCOLDB15
	.uleb128 .LEHE28-.LEHB28
	.uleb128 .L449-.LCOLDB15
	.uleb128 0
	.uleb128 .LEHB29-.LCOLDB15
	.uleb128 .LEHE29-.LEHB29
	.uleb128 .L451-.LCOLDB15
	.uleb128 0
	.uleb128 .LEHB30-.LCOLDB15
	.uleb128 .LEHE30-.LEHB30
	.uleb128 0
	.uleb128 0
.LLSDACSEC14328:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATTC14328:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, .-_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	.section	.text.unlikely
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, .-_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold
.LCOLDE15:
	.text
.LHOTE15:
	.section	.text._ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd,"axG",@progbits,_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd,comdat
	.p2align 4
	.weak	_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd
	.type	_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd, @function
_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd:
.LFB8868:
	.cfi_startproc
	testq	%rdx, %rdx
	je	.L524
	salq	$6, %rdx
	vxorpd	%xmm2, %xmm2, %xmm2
	vxorps	%xmm5, %xmm5, %xmm5
	leaq	(%rdi,%rdx), %rax
	vmovapd	%zmm2, %zmm3
	.p2align 6
	.p2align 4
	.p2align 3
.L523:
	vcvtss2sd	(%rsi), %xmm5, %xmm0
	vbroadcastsd	%xmm0, %zmm0
	addq	$64, %rdi
	addq	$4, %rsi
	vcvtps2pd	-64(%rdi), %zmm1
	vcvtps2pd	-32(%rdi), %zmm4
	vsubpd	%zmm1, %zmm0, %zmm1
	vsubpd	%zmm4, %zmm0, %zmm0
	vfmadd231pd	%zmm1, %zmm1, %zmm3
	vfmadd231pd	%zmm0, %zmm0, %zmm2
	cmpq	%rdi, %rax
	jne	.L523
.L522:
	vmovupd	%zmm3, (%rcx)
	vmovupd	%zmm2, 64(%rcx)
	vzeroupper
	ret
	.p2align 4,,10
	.p2align 3
.L524:
	vxorpd	%xmm2, %xmm2, %xmm2
	vmovapd	%zmm2, %zmm3
	jmp	.L522
	.cfi_endproc
.LFE8868:
	.size	_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd, .-_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd
	.section	.text.unlikely
	.align 2
.LCOLDB16:
	.text
.LHOTB16:
	.align 2
	.p2align 4
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv:
.LFB14387:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14387
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r9
	movl	$16, %ecx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$216, %rsp
	.cfi_def_cfa_offset 272
	movq	%fs:40, %rax
	movq	%rax, 200(%rsp)
	xorl	%eax, %eax
	leaq	64(%rsp), %r11
	movq	%r11, %rdi
	rep stosq
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	jne	.L665
	movq	(%r9), %r15
	xorl	%ebx, %ebx
	xorl	%ebp, %ebp
	movq	(%r15), %rdi
	cmpq	$1, %rdi
	jbe	.L666
.L532:
	cmpq	$16, %rdi
	jne	.L530
.L535:
	movq	16(%r9), %rax
	movq	%r11, %rcx
	movq	%r9, 16(%rsp)
	movq	%r11, 8(%rsp)
	movq	8(%rax), %rdx
	movq	(%rax), %rsi
	movq	8(%r9), %rax
	movq	(%rax), %rdi
	call	_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd
	movq	8(%rsp), %r11
	movq	16(%rsp), %r9
.L539:
	testq	%rbp, %rbp
	je	.L533
.L531:
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r13d
	movq	%rax, %r12
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	8(%rsp), %r9
	movq	16(%rsp), %r11
	subq	%rbx, %rax
	addq	%rax, 16(%rbp)
	movl	%r13d, (%r12)
	movq	(%r9), %r15
.L533:
	movq	(%r15), %rax
	testq	%rax, %rax
	je	.L544
	movq	%r9, %r12
	xorl	%r13d, %r13d
	pxor	%xmm3, %xmm3
	movq	%r11, %r9
	jmp	.L596
	.p2align 4,,10
	.p2align 3
.L668:
	ucomisd	%xmm0, %xmm1
	jp	.L664
	jne	.L664
	cmpq	%r14, (%rax)
	jl	.L593
.L664:
	salq	$4, %rdx
	leaq	(%rbx,%rdx), %rax
.L592:
	movq	%r14, (%rax)
	movsd	%xmm0, 8(%rax)
	movq	(%r15), %rax
.L549:
	addq	$1, %r13
	cmpq	%rax, %r13
	jnb	.L544
.L596:
	movsd	(%r9,%r13,8), %xmm0
	movq	24(%r12), %rdx
	ucomisd	%xmm0, %xmm3
	movq	(%rdx,%r13,8), %r14
	ja	.L648
	movq	32(%r12), %rbp
	movq	40(%r12), %rsi
	sqrtsd	%xmm0, %xmm0
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rdx
	subq	%rbx, %rdx
	movq	%rdx, %r8
	sarq	$4, %r8
	movq	%r8, %rdi
	cmpq	(%rsi), %r8
	jb	.L547
	movsd	8(%rbx), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L565
	ucomisd	%xmm1, %xmm0
	jp	.L549
	jne	.L549
	cmpq	(%rbx), %r14
	jge	.L549
.L565:
	leaq	-16(%rcx), %r10
	cmpq	$16, %rdx
	jg	.L667
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	je	.L583
.L673:
	movq	%r14, -16(%rcx)
	movsd	%xmm0, -8(%rcx)
	movq	%rcx, 8(%rbp)
.L584:
	leaq	-1(%r8), %rdx
	subq	$2, %r8
	movq	%r8, %rcx
	movq	%rdx, %rax
	shrq	$63, %rcx
	salq	$4, %rax
	addq	%r8, %rcx
	addq	%rbx, %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L592
.L591:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbx, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	jbe	.L668
.L593:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rbx,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L592
	movq	%rsi, %rcx
	jmp	.L591
.L665:
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r12d
	movq	%rax, %rbp
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	%rax, 56(%rsp)
	movq	%rax, %rbx
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movq	8(%rsp), %r9
	movl	%r12d, 0(%rbp)
	movq	16(%rsp), %r11
	movq	(%r9), %r15
	movq	(%r15), %rdi
	cmpq	$1, %rdi
	jbe	.L669
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	je	.L670
	movq	%fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff, %rdx
	movl	$1, %eax
	leaq	_ZN12minivectordb7profile6detail8countersE@tpoff, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L536:
	addq	$1, %rdx
	addq	$1, %rax
	movq	%rdx, %fs:168(%rcx)
	movq	(%r15), %rdi
	cmpq	%rdi, %rax
	jb	.L536
	cmpq	$16, %rdi
	je	.L601
	testq	%rdi, %rdi
	je	.L537
.L660:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
.L530:
	movq	16(%r9), %rdx
	xorl	%esi, %esi
	movq	8(%rdx), %rax
	leaq	0(,%rax,4), %rcx
	testq	%rax, %rax
	jne	.L671
.L647:
	addq	$1, %rsi
	cmpq	%rdi, %rsi
	jne	.L647
	jmp	.L539
	.p2align 4,,10
	.p2align 3
.L547:
	cmpq	%rcx, 16(%rbp)
	je	.L550
	movq	%r14, (%rcx)
	leaq	16(%rcx), %r14
	movsd	%xmm0, 8(%rcx)
	movq	%r14, 8(%rbp)
.L551:
	movq	0(%rbp), %rdi
	movq	%r14, %rcx
	movq	-16(%r14), %r8
	subq	%rdi, %rcx
	movq	%rcx, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	subq	$2, %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	leaq	-16(%rdi,%rcx), %rax
	sarq	%rsi
	testq	%rdx, %rdx
	jle	.L561
.L560:
	movq	%rsi, %rax
	salq	$4, %rax
	addq	%rdi, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L562
	ucomisd	%xmm0, %xmm1
	jp	.L661
	jne	.L661
	cmpq	(%rax), %r8
	jg	.L562
.L661:
	salq	$4, %rdx
	leaq	(%rdi,%rdx), %rax
.L561:
	movq	%r8, (%rax)
	addq	$1, %r13
	movsd	%xmm0, 8(%rax)
	movq	(%r15), %rax
	cmpq	%rax, %r13
	jb	.L596
.L544:
	movq	$0, (%r15)
	movq	200(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L672
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L562:
	.cfi_restore_state
	movdqu	(%rax), %xmm1
	leaq	-1(%rsi), %rcx
	salq	$4, %rdx
	movups	%xmm1, (%rdi,%rdx)
	movq	%rcx, %rdx
	shrq	$63, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	sarq	%rcx
	testq	%rsi, %rsi
	je	.L561
	movq	%rcx, %rsi
	jmp	.L560
	.p2align 4,,10
	.p2align 3
.L667:
	movq	-16(%rcx), %rax
	movq	%r10, %rsi
	movdqu	(%rbx), %xmm1
	subq	%rbx, %rsi
	movsd	-8(%rcx), %xmm2
	movq	%rax, 8(%rsp)
	movq	%rsi, %rax
	sarq	$4, %rax
	movups	%xmm1, -16(%rcx)
	leaq	-1(%rax), %rdx
	movq	%rax, %rdi
	movq	%rdx, %r11
	andl	$1, %edi
	shrq	$63, %r11
	movq	%rdi, 16(%rsp)
	addq	%rdx, %r11
	sarq	%r11
	cmpq	$32, %rsi
	jle	.L568
	movq	%r14, 24(%rsp)
	xorl	%edi, %edi
	movq	%rbp, 32(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.L571
	.p2align 4,,10
	.p2align 3
.L604:
	movq	%rsi, %rdi
.L571:
	leaq	1(%rdi), %rbp
	leaq	(%rbp,%rbp), %r14
	salq	$5, %rbp
	leaq	-1(%r14), %rsi
	addq	%rbx, %rbp
	movq	%rsi, %rdx
	movsd	8(%rbp), %xmm1
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm4
	comisd	%xmm1, %xmm4
	ja	.L569
	ucomisd	%xmm1, %xmm4
	jp	.L603
	jne	.L603
	movq	0(%rbp), %rax
	cmpq	%rax, (%rdx)
	jg	.L569
.L603:
	movq	%rbp, %rdx
	movq	%r14, %rsi
.L569:
	movdqu	(%rdx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, (%rbx,%rdi)
	cmpq	%rsi, %r11
	jg	.L604
	cmpq	$0, 16(%rsp)
	movq	24(%rsp), %r14
	movq	32(%rsp), %rbp
	movq	40(%rsp), %rax
	jne	.L662
	subq	$2, %rax
	sarq	%rax
	cmpq	%rsi, %rax
	je	.L577
.L662:
	leaq	-1(%rsi), %rdi
	movq	%rdi, %rax
	shrq	$63, %rax
	addq	%rdi, %rax
	sarq	%rax
	testq	%rsi, %rsi
	je	.L574
.L579:
	movq	%rax, %rdx
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L580
	ucomisd	%xmm1, %xmm2
	jp	.L663
	jne	.L663
	movq	8(%rsp), %rdi
	cmpq	%rdi, (%rdx)
	jl	.L580
.L663:
	salq	$4, %rsi
	leaq	(%rbx,%rsi), %rdx
.L574:
	movq	8(%rsp), %rax
	movsd	%xmm2, 8(%rdx)
	movq	%rax, (%rdx)
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	jne	.L673
.L583:
	movabsq	$576460752303423487, %rdx
	subq	%rbx, %r10
	movq	%r10, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L585
	testq	%rax, %rax
	movl	$1, %edx
	cmovne	%rax, %rdx
	addq	%rdx, %rax
	jc	.L587
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r15
	salq	$4, %r15
.L588:
	movq	%r15, %rdi
	movq	%r9, 24(%rsp)
	movq	%r10, 16(%rsp)
	movsd	%xmm0, 8(%rsp)
.LEHB31:
	call	_Znwm@PLT
	movq	16(%rsp), %r10
	movsd	8(%rsp), %xmm0
	movq	%rax, %rcx
	movq	24(%rsp), %r9
	leaq	(%rax,%r10), %rax
	leaq	16(%r10), %r8
	testq	%r10, %r10
	movq	%r14, (%rax)
	leaq	(%rcx,%r8), %r14
	movsd	%xmm0, 8(%rax)
	jg	.L674
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
.L590:
	movq	%rbx, %rdi
	movq	%r9, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rcx, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %rcx
	movq	16(%rsp), %r8
	movq	%r14, 8(%rbp)
	movsd	-8(%r14), %xmm0
	movq	24(%rsp), %r9
	pxor	%xmm3, %xmm3
	addq	%rcx, %r15
	movq	%rcx, 0(%rbp)
	movq	-16(%r14), %r14
	sarq	$4, %r8
	movq	%r15, 16(%rbp)
	movq	%rcx, %rbx
	movq	(%r12), %r15
	jmp	.L584
	.p2align 4,,10
	.p2align 3
.L580:
	movdqu	(%rdx), %xmm1
	leaq	-1(%rax), %rdi
	salq	$4, %rsi
	movups	%xmm1, (%rbx,%rsi)
	movq	%rdi, %rsi
	shrq	$63, %rsi
	addq	%rdi, %rsi
	movq	%rsi, %rdi
	movq	%rax, %rsi
	sarq	%rdi
	testq	%rax, %rax
	je	.L574
	movq	%rdi, %rax
	jmp	.L579
.L671:
	movq	(%rdx), %r8
	movq	8(%r9), %r10
	addq	%r8, %rcx
	.p2align 4
	.p2align 3
.L541:
	movq	(%r10), %rdx
	movsd	(%r11,%rsi,8), %xmm1
	movq	%r8, %rax
	leaq	(%rdx,%rsi,4), %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L540:
	pxor	%xmm0, %xmm0
	pxor	%xmm2, %xmm2
	addq	$4, %rax
	addq	$64, %rdx
	cvtss2sd	-4(%rax), %xmm0
	cvtss2sd	-64(%rdx), %xmm2
	subsd	%xmm2, %xmm0
	mulsd	%xmm0, %xmm0
	addsd	%xmm0, %xmm1
	cmpq	%rcx, %rax
	jne	.L540
	movsd	%xmm1, (%r11,%rsi,8)
	addq	$1, %rsi
	cmpq	%rdi, %rsi
	jne	.L541
	jmp	.L539
.L550:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	je	.L585
	testq	%rdi, %rdi
	movl	$1, %eax
	cmovne	%rdi, %rax
	addq	%rax, %rdi
	jc	.L555
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	cmovbe	%rdi, %rax
	movq	%rax, %r15
	salq	$4, %r15
.L556:
	movq	%r15, %rdi
	movq	%r9, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movsd	%xmm0, 8(%rsp)
	call	_Znwm@PLT
.LEHE31:
	movq	16(%rsp), %rdx
	movsd	8(%rsp), %xmm0
	pxor	%xmm3, %xmm3
	movq	%rax, %rcx
	movq	24(%rsp), %r9
	leaq	(%rax,%rdx), %rax
	testq	%rdx, %rdx
	movq	%r14, (%rax)
	leaq	16(%rcx,%rdx), %r14
	movsd	%xmm0, 8(%rax)
	jg	.L675
	testq	%rbx, %rbx
	jne	.L676
.L559:
	movq	%rcx, 0(%rbp)
	addq	%r15, %rcx
	movsd	-8(%r14), %xmm0
	movq	%r14, 8(%rbp)
	movq	(%r12), %r15
	movq	%rcx, 16(%rbp)
	jmp	.L551
.L674:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r10, %rdx
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	8(%rsp), %r8
	movq	16(%rsp), %r9
	movq	%rax, %rcx
	subq	%rbx, %rsi
	jmp	.L590
.L669:
	testq	%rdi, %rdi
	je	.L537
	movl	$1, %edi
	jmp	.L660
.L666:
	testq	%rdi, %rdi
	je	.L533
	movl	$1, %edi
	jmp	.L530
.L675:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r9, 8(%rsp)
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	8(%rsp), %r9
	movq	%rax, %rcx
	subq	%rbx, %rsi
.L558:
	movq	%rbx, %rdi
	movq	%r9, 16(%rsp)
	movq	%rcx, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	16(%rsp), %r9
	movq	8(%rsp), %rcx
	pxor	%xmm3, %xmm3
	jmp	.L559
.L573:
	cmpq	$2, %rdx
	movq	%rbx, %rdx
	ja	.L574
	xorl	%esi, %esi
.L577:
	leaq	1(%rsi,%rsi), %rdi
	movq	%rdi, %rax
	salq	$4, %rax
	movdqu	(%rbx,%rax), %xmm1
	movq	%rsi, %rax
	movq	%rdi, %rsi
	movups	%xmm1, (%rdx)
	jmp	.L579
.L568:
	cmpq	$0, 16(%rsp)
	je	.L573
	movq	%rbx, %rdx
	jmp	.L574
.L601:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L535
.L537:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L531
.L676:
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
	jmp	.L558
.L670:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L532
.L648:
	movq	%r9, 8(%rsp)
	call	sqrt@PLT
	movq	32(%r12), %rbp
	movq	40(%r12), %rax
	pxor	%xmm3, %xmm3
	movq	8(%rsp), %r9
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rdx
	subq	%rbx, %rdx
	movq	%rdx, %rdi
	sarq	$4, %rdi
	cmpq	(%rax), %rdi
	jb	.L547
	movq	(%r12), %r15
	movq	(%r15), %rax
	jmp	.L549
.L587:
	movabsq	$9223372036854775792, %r15
	jmp	.L588
.L672:
	call	__stack_chk_fail@PLT
.L555:
	movabsq	$9223372036854775792, %r15
	jmp	.L556
	.section	.gcc_except_table
.LLSDA14387:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14387-.LLSDACSB14387
.LLSDACSB14387:
	.uleb128 .LEHB31-.LFB14387
	.uleb128 .LEHE31-.LEHB31
	.uleb128 0
	.uleb128 0
.LLSDACSE14387:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14387
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold:
.LFSB14387:
.L585:
	.cfi_def_cfa_offset 272
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	200(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L677
	leaq	.LC4(%rip), %rdi
.LEHB32:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE32:
.L677:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14387:
	.section	.gcc_except_table
.LLSDAC14387:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14387-.LLSDACSBC14387
.LLSDACSBC14387:
	.uleb128 .LEHB32-.LCOLDB16
	.uleb128 .LEHE32-.LEHB32
	.uleb128 0
	.uleb128 0
.LLSDACSEC14387:
	.section	.text.unlikely
	.text
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, .-_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
	.section	.text.unlikely
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, .-_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold
.LCOLDE16:
	.text
.LHOTE16:
	.section	.text.unlikely
.LCOLDB17:
	.text
.LHOTB17:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_:
.LFB15200:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA15200
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	(%rsi), %r12
	movq	(%rdx), %rbx
	movq	%fs:40, %rbp
	movq	%rbp, 8(%rsp)
	movq	(%rdi), %rbp
	movq	8(%rdx), %r13
	movq	0(%rbp), %rax
	cmpq	$0, 16(%rax)
	je	.L682
	movq	%r12, (%rsp)
	movq	%rsp, %rsi
	movq	%rax, %rdi
.LEHB33:
	call	*24(%rax)
	testb	%al, %al
	je	.L678
.L682:
	movq	8(%rbp), %rax
	cmpq	%r13, 8(%rax)
	jne	.L716
	movq	24(%rbp), %rdi
	movq	16(%rbp), %rdx
	movq	(%rdi), %rcx
	movq	%r12, (%rdx,%rcx,8)
	movq	8(%rax), %r9
	movq	(%rdi), %rsi
	testq	%r9, %r9
	je	.L692
	movq	32(%rbp), %rax
	leaq	0(,%rsi,4), %r10
	leaq	0(,%r9,4), %rcx
	movq	(%rax), %r8
	leaq	-1(%r9), %rax
	cmpq	$6, %rax
	jbe	.L688
	movq	%r9, %rax
	leaq	0(,%rsi,4), %r10
	salq	$4, %rax
	leaq	(%r8,%r10), %rdx
	addq	%rsi, %rax
	leaq	-60(%r8,%rax,4), %rax
	cmpq	%rax, %rbx
	jnb	.L701
	leaq	0(,%r9,4), %rcx
	leaq	(%rbx,%rcx), %rax
	cmpq	%rax, %rdx
	jb	.L688
.L701:
	movq	%r9, %rcx
	movq	%rbx, %rax
	shrq	$2, %rcx
	salq	$4, %rcx
	addq	%rbx, %rcx
	.p2align 6
	.p2align 4
	.p2align 3
.L690:
	movss	12(%rax), %xmm0
	movss	8(%rax), %xmm1
	addq	$16, %rax
	addq	$256, %rdx
	movss	-12(%rax), %xmm2
	movss	-16(%rax), %xmm3
	movss	%xmm1, -128(%rdx)
	movss	%xmm3, -256(%rdx)
	movss	%xmm2, -192(%rdx)
	movss	%xmm0, -64(%rdx)
	cmpq	%rcx, %rax
	jne	.L690
	movq	%r9, %rax
	andq	$-4, %rax
	testb	$3, %r9b
	je	.L692
	movq	%rax, %rdx
	movss	(%rbx,%rax,4), %xmm0
	leaq	1(%rax), %r10
	leaq	0(,%rax,4), %rcx
	salq	$4, %rdx
	addq	%rsi, %rdx
	movss	%xmm0, (%r8,%rdx,4)
	cmpq	%r9, %r10
	jnb	.L692
	movss	4(%rbx,%rcx), %xmm0
	addq	$2, %rax
	movss	%xmm0, 64(%r8,%rdx,4)
	cmpq	%r9, %rax
	jnb	.L692
	movss	8(%rbx,%rcx), %xmm0
	movss	%xmm0, 128(%r8,%rdx,4)
.L692:
	addq	$1, %rsi
	movq	%rsi, (%rdi)
	cmpq	$16, %rsi
	je	.L717
.L678:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L715
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L717:
	.cfi_restore_state
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L715
	movq	40(%rbp), %rdi
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	jmp	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE33:
	.p2align 4,,10
	.p2align 3
.L688:
	.cfi_restore_state
	movq	%rbx, %rax
	leaq	(%r8,%r10), %rdx
	addq	%rbx, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L694:
	movss	(%rax), %xmm0
	addq	$4, %rax
	addq	$64, %rdx
	movss	%xmm0, -64(%rdx)
	cmpq	%rcx, %rax
	jne	.L694
	addq	$1, %rsi
	movq	%rsi, (%rdi)
	cmpq	$16, %rsi
	jne	.L678
	jmp	.L717
.L715:
	call	__stack_chk_fail@PLT
.L716:
	jmp	.L680
	.section	.gcc_except_table
.LLSDA15200:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE15200-.LLSDACSB15200
.LLSDACSB15200:
	.uleb128 .LEHB33-.LFB15200
	.uleb128 .LEHE33-.LEHB33
	.uleb128 0
	.uleb128 0
.LLSDACSE15200:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC15200
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold:
.LFSB15200:
.L680:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 13, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC11(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB34:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE34:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L714
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB35:
	call	__cxa_throw@PLT
.L700:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L714
	movq	%rbp, %rdi
	call	_Unwind_Resume@PLT
.LEHE35:
.L714:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE15200:
	.section	.gcc_except_table
.LLSDAC15200:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC15200-.LLSDACSBC15200
.LLSDACSBC15200:
	.uleb128 .LEHB34-.LCOLDB17
	.uleb128 .LEHE34-.LEHB34
	.uleb128 .L700-.LCOLDB17
	.uleb128 0
	.uleb128 .LEHB35-.LCOLDB17
	.uleb128 .LEHE35-.LEHB35
	.uleb128 0
	.uleb128 0
.LLSDACSEC15200:
	.section	.text.unlikely
	.text
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold
.LCOLDE17:
	.text
.LHOTE17:
	.section	.text.unlikely
.LCOLDB19:
	.text
.LHOTB19:
	.p2align 4
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, @function
_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE:
.LFB14380:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14380
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %rax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%r8, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$360, %rsp
	.cfi_def_cfa_offset 416
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
	movq	24(%rsp), %rsi
	movq	%rcx, 8(%rsp)
	leaq	(%rax,%rsi,4), %rdx
	movq	%fs:40, %r12
	movq	%r12, 344(%rsp)
	movq	%r9, %r12
	cmpq	%rdx, %rax
	je	.L719
	movss	.LC1(%rip), %xmm1
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L723:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L797
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L723
.L719:
	movq	8(%rsp), %rcx
	testq	%rcx, %rcx
	jne	.L724
	movq	$0, 16(%rbx)
	pxor	%xmm0, %xmm0
	movups	%xmm0, (%rbx)
.L718:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L853
	addq	$360, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L724:
	.cfi_restore_state
	leaq	-16(%rsi), %rax
	cmpq	$1008, %rax
	jbe	.L726
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	%rbx, %rdi
.LEHB36:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE36:
	jmp	.L718
	.p2align 4,,10
	.p2align 3
.L726:
	pxor	%xmm0, %xmm0
	salq	$6, %rsi
	movl	$16, %ecx
	xorl	%eax, %eax
	leaq	208(%rsp), %rdi
	movaps	%xmm0, 80(%rsp)
	pxor	%xmm0, %xmm0
	movq	%rsi, %r13
	movq	%rdi, (%rsp)
	rep stosq
	movq	%rsi, %rdi
	movaps	%xmm0, 48(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 64(%rsp)
.LEHB37:
	call	_Znwm@PLT
.LEHE37:
	movl	$0x00000000, (%rax)
	movq	%rax, %r15
	leaq	-4(%r13), %rdx
	xorl	%esi, %esi
	leaq	4(%rax), %rdi
	leaq	(%rax,%r13), %r14
	leaq	48(%rsp), %r13
	call	memset@PLT
	movq	%r15, 48(%rsp)
	leaq	40(%rsp), %r15
	movq	%r13, %xmm3
	movq	%r15, %xmm0
	movq	%r14, 56(%rsp)
	leaq	80(%rsp), %rax
	movl	$48, %edi
	punpcklqdq	%xmm3, %xmm0
	movq	%r14, 64(%rsp)
	leaq	16(%rsp), %r14
	movaps	%xmm0, 112(%rsp)
	movq	%r14, %xmm0
	movq	$0, 40(%rsp)
	movhps	(%rsp), %xmm0
	movaps	%xmm0, 128(%rsp)
	movq	%rax, %xmm0
	leaq	8(%rsp), %rax
	movq	%rax, %xmm4
	leaq	39(%rsp), %rax
	movq	$0, 192(%rsp)
	punpcklqdq	%xmm4, %xmm0
	movq	%rax, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	pxor	%xmm0, %xmm0
	movq	$0, 200(%rsp)
	movaps	%xmm0, 176(%rsp)
.LEHB38:
	call	_Znwm@PLT
.LEHE38:
	movq	(%rsp), %rdi
	movq	%r13, 32(%rax)
	leaq	112(%rsp), %r13
	movq	%r12, (%rax)
	cmpq	$0, 16(%rbp)
	movq	%r14, 8(%rax)
	movq	.LC18(%rip), %xmm0
	movq	%rdi, 16(%rax)
	movq	%r15, 24(%rax)
	movq	%r13, 40(%rax)
	movq	%rax, 176(%rsp)
	leaq	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_(%rip), %rax
	movq	%rax, %xmm5
	punpcklqdq	%xmm5, %xmm0
	movaps	%xmm0, 192(%rsp)
	je	.L854
	leaq	176(%rsp), %r12
	movq	%rbp, %rdi
	movq	%r12, %rsi
.LEHB39:
	call	*24(%rbp)
.LEHE39:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L733
	movl	$3, %edx
	movq	%r12, %rsi
	movq	%r12, %rdi
	call	*%rax
.L733:
	cmpq	$0, 40(%rsp)
	je	.L734
	movq	%r13, %rdi
.LEHB40:
	call	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE40:
.L734:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movabsq	$9223372036854775792, %rdx
	movq	%rax, %rbp
	subq	%r13, %rbp
	cmpq	%rbp, %rdx
	jb	.L842
	testq	%rbp, %rbp
	jne	.L737
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	cmpq	%r13, %rax
	je	.L739
.L738:
	movq	%r14, %r12
	jmp	.L766
	.p2align 4,,10
	.p2align 3
.L750:
	movq	%r9, 88(%rsp)
	cmpq	%r9, %r13
	je	.L855
.L766:
	cmpq	%r14, %rbp
	je	.L740
	movdqu	0(%r13), %xmm0
	addq	$16, %r14
	movups	%xmm0, -16(%r14)
.L741:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movq	%rax, %rdx
	leaq	-16(%rax), %r9
	subq	%r13, %rdx
	cmpq	$16, %rdx
	jle	.L750
	movq	%r9, %rdx
	movdqu	0(%r13), %xmm0
	movq	-16(%rax), %r11
	subq	%r13, %rdx
	movsd	-8(%rax), %xmm1
	movq	%rdx, %r10
	movups	%xmm0, -16(%rax)
	sarq	$4, %r10
	leaq	-1(%r10), %rax
	movq	%r10, %r15
	movq	%rax, %r8
	andl	$1, %r15d
	shrq	$63, %r8
	addq	%rax, %r8
	sarq	%r8
	cmpq	$32, %rdx
	jle	.L751
	movq	%r9, (%rsp)
	xorl	%esi, %esi
	jmp	.L754
	.p2align 4,,10
	.p2align 3
.L788:
	movq	%rcx, %rsi
.L754:
	leaq	1(%rsi), %rax
	leaq	(%rax,%rax), %rdi
	salq	$5, %rax
	leaq	-1(%rdi), %rcx
	addq	%r13, %rax
	movq	%rcx, %rdx
	movsd	8(%rax), %xmm0
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L752
	ucomisd	%xmm0, %xmm2
	jp	.L787
	jne	.L787
	movq	(%rax), %r9
	cmpq	%r9, (%rdx)
	jg	.L752
.L787:
	movq	%rax, %rdx
	movq	%rdi, %rcx
.L752:
	movdqu	(%rdx), %xmm0
	salq	$4, %rsi
	movups	%xmm0, 0(%r13,%rsi)
	cmpq	%r8, %rcx
	jl	.L788
	movq	(%rsp), %r9
	testq	%r15, %r15
	jne	.L851
	subq	$2, %r10
	sarq	%r10
	cmpq	%rcx, %r10
	je	.L760
.L851:
	leaq	-1(%rcx), %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L757
.L762:
	movq	%rsi, %rdx
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L763
	ucomisd	%xmm0, %xmm1
	jp	.L852
	jne	.L852
	cmpq	(%rdx), %r11
	jg	.L763
.L852:
	salq	$4, %rcx
	leaq	0(%r13,%rcx), %rdx
.L757:
	movq	%r11, (%rdx)
	movsd	%xmm1, 8(%rdx)
	jmp	.L750
	.p2align 4,,10
	.p2align 3
.L763:
	movdqu	(%rdx), %xmm0
	salq	$4, %rcx
	movups	%xmm0, 0(%r13,%rcx)
	leaq	-1(%rsi), %rcx
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rcx, %rax
	movq	%rsi, %rcx
	sarq	%rax
	testq	%rsi, %rsi
	je	.L757
	movq	%rax, %rsi
	jmp	.L762
	.p2align 4,,10
	.p2align 3
.L740:
	movabsq	$576460752303423487, %rax
	movq	%rbp, %rsi
	subq	%r12, %rsi
	movq	%rsi, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L843
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L745
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L746:
	movq	%r15, %rdi
	movq	%rsi, (%rsp)
.LEHB41:
	call	_Znwm@PLT
.LEHE41:
	movq	(%rsp), %rsi
	movdqu	0(%r13), %xmm0
	movq	%rax, %rcx
	movups	%xmm0, (%rax,%rsi)
	leaq	16(%rax,%rsi), %r14
	testq	%rsi, %rsi
	jg	.L856
	testq	%r12, %r12
	jne	.L748
.L749:
	leaq	(%rcx,%r15), %rbp
	movq	%rcx, %r12
	jmp	.L741
	.p2align 4,,10
	.p2align 3
.L855:
	cmpq	%r14, %r12
	je	.L739
	leaq	-16(%r14), %rax
	cmpq	%rax, %r12
	jnb	.L739
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L768:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L768
.L739:
	movq	%r12, (%rbx)
	movq	%r14, 8(%rbx)
	movq	%rbp, 16(%rbx)
.L774:
	movq	48(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L769
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L769:
	movq	80(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L718
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	jmp	.L718
.L856:
	movq	%rsi, %rdx
	movq	%rax, %rdi
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %rcx
.L748:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%rcx, (%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L749
.L751:
	movq	%r13, %rdx
	testq	%r15, %r15
	jne	.L757
	cmpq	$2, %rax
	ja	.L757
	xorl	%ecx, %ecx
.L760:
	leaq	1(%rcx,%rcx), %rax
	movq	%rax, %rsi
	salq	$4, %rsi
	movdqu	0(%r13,%rsi), %xmm0
	movq	%rcx, %rsi
	movq	%rax, %rcx
	movups	%xmm0, (%rdx)
	jmp	.L762
.L737:
	movq	%rbp, %rdi
.LEHB42:
	call	_Znwm@PLT
.LEHE42:
	movq	80(%rsp), %r13
	movq	%rax, %r14
	addq	%rax, %rbp
	cmpq	88(%rsp), %r13
	jne	.L738
	movq	%rax, %r12
	jmp	.L739
.L745:
	movabsq	$9223372036854775792, %r15
	jmp	.L746
.L853:
	call	__stack_chk_fail@PLT
.L796:
	movq	%rax, %rbx
	jmp	.L729
.L791:
	movq	%rax, %rdi
	movq	%rdx, %rax
	jmp	.L772
.L840:
	jmp	.L841
.L838:
	jmp	.L839
.L854:
	jmp	.L727
.L836:
	jmp	.L837
	.section	.gcc_except_table
	.align 4
.LLSDA14380:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT14380-.LLSDATTD14380
.LLSDATTD14380:
	.byte	0x1
	.uleb128 .LLSDACSE14380-.LLSDACSB14380
.LLSDACSB14380:
	.uleb128 .LEHB36-.LFB14380
	.uleb128 .LEHE36-.LEHB36
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB37-.LFB14380
	.uleb128 .LEHE37-.LEHB37
	.uleb128 .L791-.LFB14380
	.uleb128 0x3
	.uleb128 .LEHB38-.LFB14380
	.uleb128 .LEHE38-.LEHB38
	.uleb128 .L796-.LFB14380
	.uleb128 0
	.uleb128 .LEHB39-.LFB14380
	.uleb128 .LEHE39-.LEHB39
	.uleb128 .L838-.LFB14380
	.uleb128 0
	.uleb128 .LEHB40-.LFB14380
	.uleb128 .LEHE40-.LEHB40
	.uleb128 .L836-.LFB14380
	.uleb128 0
	.uleb128 .LEHB41-.LFB14380
	.uleb128 .LEHE41-.LEHB41
	.uleb128 .L840-.LFB14380
	.uleb128 0
	.uleb128 .LEHB42-.LFB14380
	.uleb128 .LEHE42-.LEHB42
	.uleb128 .L836-.LFB14380
	.uleb128 0
.LLSDACSE14380:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATT14380:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14380
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, @function
_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold:
.LFSB14380:
.L797:
	.cfi_def_cfa_offset 416
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB43:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE43:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L857
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB44:
	call	__cxa_throw@PLT
.LEHE44:
.L843:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L858
	leaq	.LC4(%rip), %rdi
.LEHB45:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE45:
.L729:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L731
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
.L731:
	movq	48(%rsp), %rdi
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L780
	call	_ZdlPvm@PLT
.L780:
	movq	80(%rsp), %rdi
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L781
	call	_ZdlPvm@PLT
.L781:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L859
	movq	%rbx, %rdi
.LEHB46:
	call	_Unwind_Resume@PLT
.LEHE46:
.L772:
	subq	$1, %rax
	jne	.L860
	call	__cxa_begin_catch@PLT
	movq	8(%rsp), %rcx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%rbx, %rdi
.LEHB47:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE47:
	call	__cxa_end_catch@PLT
	jmp	.L774
.L859:
	call	__stack_chk_fail@PLT
.L858:
	call	__stack_chk_fail@PLT
.L860:
	movq	%rdi, %rbx
	jmp	.L731
.L795:
.L841:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L731
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L731
.L793:
	movq	%rax, %rbx
	call	__cxa_end_catch@PLT
	jmp	.L731
.L842:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L861
	leaq	.LC3(%rip), %rdi
.LEHB48:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE48:
.L857:
	call	__stack_chk_fail@PLT
.L794:
.L839:
	movq	%rax, %rbx
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L731
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L731
.L727:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L862
.LEHB49:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE49:
.L862:
	call	__stack_chk_fail@PLT
.L792:
.L837:
	movq	%rax, %rbx
	jmp	.L731
.L790:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L863
	movq	%rbp, %rdi
.LEHB50:
	call	_Unwind_Resume@PLT
.LEHE50:
.L861:
	call	__stack_chk_fail@PLT
.L863:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14380:
	.section	.gcc_except_table
	.align 4
.LLSDAC14380:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATTC14380-.LLSDATTDC14380
.LLSDATTDC14380:
	.byte	0x1
	.uleb128 .LLSDACSEC14380-.LLSDACSBC14380
.LLSDACSBC14380:
	.uleb128 .LEHB43-.LCOLDB19
	.uleb128 .LEHE43-.LEHB43
	.uleb128 .L790-.LCOLDB19
	.uleb128 0
	.uleb128 .LEHB44-.LCOLDB19
	.uleb128 .LEHE44-.LEHB44
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB45-.LCOLDB19
	.uleb128 .LEHE45-.LEHB45
	.uleb128 .L795-.LCOLDB19
	.uleb128 0
	.uleb128 .LEHB46-.LCOLDB19
	.uleb128 .LEHE46-.LEHB46
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB47-.LCOLDB19
	.uleb128 .LEHE47-.LEHB47
	.uleb128 .L793-.LCOLDB19
	.uleb128 0
	.uleb128 .LEHB48-.LCOLDB19
	.uleb128 .LEHE48-.LEHB48
	.uleb128 .L792-.LCOLDB19
	.uleb128 0
	.uleb128 .LEHB49-.LCOLDB19
	.uleb128 .LEHE49-.LEHB49
	.uleb128 .L794-.LCOLDB19
	.uleb128 0
	.uleb128 .LEHB50-.LCOLDB19
	.uleb128 .LEHE50-.LEHB50
	.uleb128 0
	.uleb128 0
.LLSDACSEC14380:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATTC14380:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, .-_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	.section	.text.unlikely
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, .-_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold
.LCOLDE19:
	.text
.LHOTE19:
	.section	.text._ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd,"axG",@progbits,_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd,comdat
	.p2align 4
	.weak	_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd
	.type	_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd, @function
_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd:
.LFB8869:
	.cfi_startproc
	testq	%rdx, %rdx
	je	.L867
	vxorpd	%xmm3, %xmm3, %xmm3
	salq	$6, %rdx
	vxorps	%xmm7, %xmm7, %xmm7
	leaq	(%rdi,%rdx), %rax
	vmovapd	%ymm3, %ymm4
	vmovapd	%ymm3, %ymm5
	vmovapd	%ymm3, %ymm6
	.p2align 4
	.p2align 3
.L866:
	vmovups	(%rdi), %ymm1
	vcvtss2sd	(%rsi), %xmm7, %xmm0
	addq	$64, %rdi
	addq	$4, %rsi
	vmovups	-32(%rdi), %ymm9
	vbroadcastsd	%xmm0, %ymm0
	vcvtps2pd	%xmm1, %ymm8
	vextractf128	$0x1, %ymm1, %xmm1
	vsubpd	%ymm8, %ymm0, %ymm8
	vcvtps2pd	%xmm9, %ymm2
	vextractf128	$0x1, %ymm9, %xmm9
	vsubpd	%ymm2, %ymm0, %ymm2
	vcvtps2pd	%xmm1, %ymm1
	vcvtps2pd	%xmm9, %ymm9
	vsubpd	%ymm1, %ymm0, %ymm1
	vsubpd	%ymm9, %ymm0, %ymm0
	vmulpd	%ymm8, %ymm8, %ymm8
	vmulpd	%ymm2, %ymm2, %ymm2
	vmulpd	%ymm1, %ymm1, %ymm1
	vmulpd	%ymm0, %ymm0, %ymm0
	vaddpd	%ymm8, %ymm6, %ymm6
	vaddpd	%ymm2, %ymm4, %ymm4
	vaddpd	%ymm1, %ymm5, %ymm5
	vaddpd	%ymm0, %ymm3, %ymm3
	cmpq	%rdi, %rax
	jne	.L866
.L865:
	vmovupd	%ymm6, (%rcx)
	vmovupd	%ymm5, 32(%rcx)
	vmovupd	%ymm4, 64(%rcx)
	vmovupd	%ymm3, 96(%rcx)
	vzeroupper
	ret
	.p2align 4,,10
	.p2align 3
.L867:
	vxorpd	%xmm3, %xmm3, %xmm3
	vmovapd	%ymm3, %ymm4
	vmovapd	%ymm3, %ymm5
	vmovapd	%ymm3, %ymm6
	jmp	.L865
	.cfi_endproc
.LFE8869:
	.size	_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd, .-_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC20:
	.string	"invalid transposed VECTOR block"
	.section	.text.unlikely
.LCOLDB21:
	.text
.LHOTB21:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot, @function
_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot:
.LFB14758:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14758
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r8
	movq	%rsi, %rdi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$232, %rsp
	.cfi_def_cfa_offset 288
	movq	8(%rdi), %r14
	movq	(%r8), %r15
	movq	%fs:40, %rax
	movq	%rax, 216(%rsp)
	movq	%rdx, %rax
	movzwl	(%rcx), %esi
	movq	8(%rax), %rdx
	cmpq	$16, %r14
	ja	.L871
	movq	(%r15), %rcx
	movq	%rdx, %r8
	shrq	$4, %r8
	cmpq	8(%rcx), %r8
	jne	.L871
	andl	$15, %edx
	movq	%rdx, %r9
	jne	.L871
	movzwl	%si, %r13d
	movl	%r14d, %ecx
	movl	%r13d, %edx
	shrl	%cl, %edx
	testl	%edx, %edx
	jne	.L871
	testw	%si, %si
	jne	.L1038
.L870:
	movq	216(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1039
	addq	$232, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1038:
	.cfi_restore_state
	movq	(%rdi), %rdi
	movq	(%rax), %rbx
	movl	$16, %ecx
	movq	%r9, %rax
	movq	%rdi, 16(%rsp)
	leaq	80(%rsp), %rdi
	movq	%rdi, 8(%rsp)
	rep stosq
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	jne	.L1040
	movl	%r13d, %edi
	movq	%r9, 24(%rsp)
	call	__popcountdi2@PLT
	movq	24(%rsp), %r9
	cmpl	$1, %eax
	je	.L1020
	cmpl	$2, %eax
	je	.L1020
	xorl	%ebp, %ebp
	xorl	%r12d, %r12d
	cmpl	$3, %eax
	je	.L1041
.L888:
	movq	__cpu_model@GOTPCREL(%rip), %rax
	testb	$4, 13(%rax)
	jne	.L889
	testq	%r14, %r14
	jne	.L882
	testq	%r12, %r12
	je	.L870
	.p2align 4
	.p2align 3
.L880:
	movq	%r9, 32(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %edx
	movq	%rax, %rbx
	movl	%edx, 24(%rsp)
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movl	24(%rsp), %edx
	movq	32(%rsp), %r9
	subq	%rbp, %rax
	addq	%rax, 16(%r12)
	movl	%edx, (%rbx)
.L898:
	testq	%r14, %r14
	je	.L870
.L899:
	pxor	%xmm3, %xmm3
	movq	%r15, %r8
	movq	%r9, %rbx
	jmp	.L952
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L900:
	addq	$1, %rbx
	cmpq	%r14, %rbx
	je	.L870
.L952:
	btl	%ebx, %r13d
	jnc	.L900
	movq	16(%rsp), %rax
	movq	(%rax,%rbx,8), %r9
	movq	8(%rsp), %rax
	movsd	(%rax,%rbx,8), %xmm0
	ucomisd	%xmm0, %xmm3
	ja	.L1017
	movq	16(%r8), %r12
	movq	24(%r8), %rax
	sqrtsd	%xmm0, %xmm0
	movq	8(%r12), %rcx
	movq	(%r12), %rbp
	movq	%rcx, %rdx
	subq	%rbp, %rdx
	movq	%rdx, %r10
	sarq	$4, %r10
	movq	%r10, %rsi
	cmpq	(%rax), %r10
	jb	.L903
	movsd	8(%rbp), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L920
	ucomisd	%xmm1, %xmm0
	jp	.L900
	jne	.L900
	cmpq	0(%rbp), %r9
	jge	.L900
.L920:
	leaq	-16(%rcx), %rax
	cmpq	$16, %rdx
	jg	.L1042
.L923:
	movq	%rax, 8(%r12)
	cmpq	%rax, 16(%r12)
	je	.L939
	movq	%r9, -16(%rcx)
	movsd	%xmm0, -8(%rcx)
	movq	%rcx, 8(%r12)
.L940:
	leaq	-1(%r10), %rdx
	subq	$2, %r10
	movq	%r10, %rsi
	movq	%rdx, %rax
	shrq	$63, %rsi
	salq	$4, %rax
	addq	%r10, %rsi
	addq	%rbp, %rax
	sarq	%rsi
	testq	%rdx, %rdx
	jle	.L948
.L947:
	movq	%rsi, %rax
	salq	$4, %rax
	addq	%rbp, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L949
	ucomisd	%xmm0, %xmm1
	jp	.L1037
	jne	.L1037
	cmpq	%r9, (%rax)
	jge	.L1037
.L949:
	movdqu	(%rax), %xmm1
	leaq	-1(%rsi), %rcx
	salq	$4, %rdx
	movups	%xmm1, 0(%rbp,%rdx)
	movq	%rcx, %rdx
	shrq	$63, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	sarq	%rcx
	testq	%rsi, %rsi
	je	.L948
	movq	%rcx, %rsi
	jmp	.L947
	.p2align 4,,10
	.p2align 3
.L1040:
	movq	%r9, 32(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %edx
	movq	%rax, %r12
	movl	%edx, 24(%rsp)
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movl	%r13d, %edi
	movq	%rax, 72(%rsp)
	movq	%rax, %rbp
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movl	24(%rsp), %edx
	movl	%edx, (%r12)
	call	__popcountdi2@PLT
	movq	32(%rsp), %r9
	cmpl	$1, %eax
	je	.L1030
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	movq	%fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff, %rcx
	je	.L1043
	leal	-2(%rax), %edx
	leaq	1(%rcx,%rdx), %rdx
	movq	%rdx, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	cmpl	$3, %eax
	jle	.L1030
	movq	__cpu_model@GOTPCREL(%rip), %rax
	testb	$4, 13(%rax)
	je	.L1030
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
.L889:
	movq	(%r15), %rax
	movq	8(%rsp), %rcx
	movq	%r9, 24(%rsp)
	movq	%rbx, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rdx
	movq	8(%r15), %rax
	cmpb	$0, (%rax)
	je	.L892
	call	_ZN12minivectordb6detail25batch16_transposed_avx512EPKfS2_mPd
	movq	24(%rsp), %r9
.L893:
	testq	%r12, %r12
	jne	.L880
	jmp	.L898
.L1043:
	cmpl	$2, %eax
	je	.L1030
	movq	%fs:0, %rdi
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rdi), %r12
	cmpl	$3, %eax
	jne	.L888
	.p2align 4
	.p2align 3
.L1030:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r12
	testq	%r14, %r14
	je	.L880
.L882:
	movq	8(%rsp), %rdi
	xorl	%esi, %esi
	jmp	.L896
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L894:
	addq	$1, %rsi
	addq	$4, %rbx
	cmpq	%r14, %rsi
	je	.L1044
.L896:
	btl	%esi, %r13d
	jnc	.L894
	movq	(%r15), %rax
	movq	8(%rax), %rdx
	testq	%rdx, %rdx
	je	.L894
	movq	(%rax), %rax
	movsd	(%rdi,%rsi,8), %xmm1
	leaq	(%rax,%rdx,4), %rcx
	movq	%rbx, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L895:
	pxor	%xmm0, %xmm0
	pxor	%xmm2, %xmm2
	addq	$4, %rax
	addq	$64, %rdx
	cvtss2sd	-4(%rax), %xmm0
	cvtss2sd	-64(%rdx), %xmm2
	subsd	%xmm2, %xmm0
	mulsd	%xmm0, %xmm0
	addsd	%xmm0, %xmm1
	cmpq	%rcx, %rax
	jne	.L895
	movsd	%xmm1, (%rdi,%rsi,8)
	addq	$1, %rsi
	addq	$4, %rbx
	cmpq	%r14, %rsi
	jne	.L896
.L1044:
	testq	%r12, %r12
	jne	.L880
	jmp	.L899
	.p2align 4,,10
	.p2align 3
.L1037:
	salq	$4, %rdx
	leaq	0(%rbp,%rdx), %rax
.L948:
	movq	%r9, (%rax)
	movsd	%xmm0, 8(%rax)
	jmp	.L900
.L1017:
	movq	%r8, 32(%rsp)
	movq	%r9, 24(%rsp)
	call	sqrt@PLT
	movq	32(%rsp), %r8
	movq	24(%rsp), %r9
	pxor	%xmm3, %xmm3
	movq	16(%r8), %r12
	movq	24(%r8), %rax
	movq	8(%r12), %rcx
	movq	(%r12), %rbp
	movq	%rcx, %rdx
	subq	%rbp, %rdx
	movq	%rdx, %rsi
	sarq	$4, %rsi
	cmpq	(%rax), %rsi
	jnb	.L900
	.p2align 4
	.p2align 3
.L903:
	cmpq	%rcx, 16(%r12)
	je	.L905
	movq	%r9, (%rcx)
	addq	$16, %rcx
	movsd	%xmm0, -8(%rcx)
	movq	%rcx, 8(%r12)
.L906:
	movq	(%r12), %rsi
	movq	-16(%rcx), %rdi
	subq	%rsi, %rcx
	movq	%rcx, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %r9
	subq	$2, %rax
	movq	%rax, %r10
	shrq	$63, %r10
	addq	%rax, %r10
	leaq	-16(%rsi,%rcx), %rax
	sarq	%r10
	testq	%r9, %r9
	jle	.L916
.L915:
	movq	%r10, %rax
	salq	$4, %rax
	addq	%rsi, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L917
	ucomisd	%xmm0, %xmm1
	jp	.L1034
	jne	.L1034
	cmpq	(%rax), %rdi
	jle	.L1034
.L917:
	leaq	-1(%r10), %rcx
	movdqu	(%rax), %xmm1
	salq	$4, %r9
	movq	%rcx, %rdx
	shrq	$63, %rdx
	movups	%xmm1, (%rsi,%r9)
	movq	%r10, %r9
	addq	%rcx, %rdx
	sarq	%rdx
	testq	%r10, %r10
	je	.L916
	movq	%rdx, %r10
	jmp	.L915
	.p2align 4,,10
	.p2align 3
.L1034:
	movq	%r9, %rax
	salq	$4, %rax
	addq	%rsi, %rax
.L916:
	movq	%rdi, (%rax)
	movsd	%xmm0, 8(%rax)
	jmp	.L900
	.p2align 4,,10
	.p2align 3
.L1042:
	movq	%rax, %rsi
	movq	-16(%rcx), %rdi
	movdqu	0(%rbp), %xmm1
	subq	%rbp, %rsi
	movsd	-8(%rcx), %xmm2
	movq	%rsi, %r11
	movq	%rdi, 24(%rsp)
	sarq	$4, %r11
	movups	%xmm1, -16(%rcx)
	leaq	-1(%r11), %rdx
	movq	%r11, %rdi
	movq	%rdx, %r15
	andl	$1, %edi
	shrq	$63, %r15
	movq	%rdi, 32(%rsp)
	addq	%rdx, %r15
	sarq	%r15
	cmpq	$32, %rsi
	jle	.L924
	movq	%r8, 40(%rsp)
	xorl	%edi, %edi
	movl	%r13d, 48(%rsp)
	movq	%rax, 56(%rsp)
	jmp	.L927
	.p2align 4,,10
	.p2align 3
.L967:
	movq	%rsi, %rdi
.L927:
	leaq	1(%rdi), %r8
	leaq	(%r8,%r8), %r13
	salq	$5, %r8
	leaq	-1(%r13), %rsi
	addq	%rbp, %r8
	movq	%rsi, %rdx
	movsd	8(%r8), %xmm1
	salq	$4, %rdx
	addq	%rbp, %rdx
	movsd	8(%rdx), %xmm4
	comisd	%xmm1, %xmm4
	ja	.L925
	ucomisd	%xmm1, %xmm4
	jp	.L966
	jne	.L966
	movq	(%r8), %rax
	cmpq	%rax, (%rdx)
	jg	.L925
.L966:
	movq	%r8, %rdx
	movq	%r13, %rsi
.L925:
	movdqu	(%rdx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, 0(%rbp,%rdi)
	cmpq	%rsi, %r15
	jg	.L967
	cmpq	$0, 32(%rsp)
	movq	40(%rsp), %r8
	movl	48(%rsp), %r13d
	movq	56(%rsp), %rax
	jne	.L1035
	subq	$2, %r11
	sarq	%r11
	cmpq	%rsi, %r11
	je	.L933
.L1035:
	leaq	-1(%rsi), %r11
	movq	%r11, %rdi
	shrq	$63, %rdi
	addq	%r11, %rdi
	sarq	%rdi
	testq	%rsi, %rsi
	je	.L930
.L935:
	movq	%rdi, %rdx
	salq	$4, %rdx
	addq	%rbp, %rdx
	movsd	8(%rdx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L936
	ucomisd	%xmm2, %xmm1
	jp	.L1036
	jne	.L1036
	movq	24(%rsp), %r11
	cmpq	(%rdx), %r11
	jg	.L936
.L1036:
	salq	$4, %rsi
	leaq	0(%rbp,%rsi), %rdx
.L930:
	movq	24(%rsp), %rdi
	movsd	%xmm2, 8(%rdx)
	movq	%rdi, (%rdx)
	jmp	.L923
	.p2align 4,,10
	.p2align 3
.L936:
	movdqu	(%rdx), %xmm1
	leaq	-1(%rdi), %r11
	salq	$4, %rsi
	movups	%xmm1, 0(%rbp,%rsi)
	movq	%r11, %rsi
	shrq	$63, %rsi
	addq	%r11, %rsi
	sarq	%rsi
	movq	%rsi, %r11
	movq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L930
	movq	%r11, %rdi
	jmp	.L935
	.p2align 4,,10
	.p2align 3
.L939:
	movabsq	$576460752303423487, %rcx
	subq	%rbp, %rax
	movq	%rax, %rdx
	sarq	$4, %rax
	cmpq	%rcx, %rax
	je	.L941
	testq	%rax, %rax
	movl	$1, %ecx
	cmovne	%rax, %rcx
	addq	%rcx, %rax
	jc	.L943
	movabsq	$576460752303423487, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %r15
	salq	$4, %r15
.L944:
	movq	%r15, %rdi
	movq	%r8, 48(%rsp)
	movq	%rdx, 40(%rsp)
	movq	%r9, 24(%rsp)
	movsd	%xmm0, 32(%rsp)
.LEHB51:
	call	_Znwm@PLT
	movq	40(%rsp), %rdx
	movq	24(%rsp), %r9
	movsd	32(%rsp), %xmm0
	movq	%rax, %rcx
	movq	48(%rsp), %r8
	leaq	(%rax,%rdx), %rax
	leaq	16(%rdx), %r10
	testq	%rdx, %rdx
	movq	%r9, (%rax)
	leaq	(%rcx,%r10), %r9
	movsd	%xmm0, 8(%rax)
	jg	.L1045
	movq	16(%r12), %rsi
	subq	%rbp, %rsi
.L946:
	movq	%rbp, %rdi
	movq	%r8, 48(%rsp)
	movq	%r9, 40(%rsp)
	movq	%r10, 32(%rsp)
	movq	%rcx, 24(%rsp)
	call	_ZdlPvm@PLT
	movq	24(%rsp), %rcx
	movq	40(%rsp), %r9
	pxor	%xmm3, %xmm3
	movq	32(%rsp), %r10
	movq	48(%rsp), %r8
	addq	%rcx, %r15
	movsd	-8(%r9), %xmm0
	movq	%rcx, (%r12)
	movq	%rcx, %rbp
	movq	%r9, 8(%r12)
	sarq	$4, %r10
	movq	-16(%r9), %r9
	movq	%r15, 16(%r12)
	jmp	.L940
	.p2align 4,,10
	.p2align 3
.L905:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rsi
	je	.L941
	testq	%rsi, %rsi
	movl	$1, %eax
	cmovne	%rsi, %rax
	addq	%rsi, %rax
	jc	.L910
	movabsq	$576460752303423487, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %r15
	salq	$4, %r15
.L911:
	movq	%r15, %rdi
	movq	%r8, 48(%rsp)
	movq	%r9, 32(%rsp)
	movq	%rdx, 24(%rsp)
	movsd	%xmm0, 40(%rsp)
	call	_Znwm@PLT
.LEHE51:
	movq	24(%rsp), %rdx
	movq	32(%rsp), %r9
	pxor	%xmm3, %xmm3
	movsd	40(%rsp), %xmm0
	movq	%rax, %r10
	movq	48(%rsp), %r8
	leaq	(%rax,%rdx), %rax
	testq	%rdx, %rdx
	leaq	16(%r10,%rdx), %rcx
	movq	%r9, (%rax)
	movsd	%xmm0, 8(%rax)
	jg	.L1046
	testq	%rbp, %rbp
	jne	.L1047
.L914:
	movq	%r10, (%r12)
	addq	%r15, %r10
	movsd	-8(%rcx), %xmm0
	movq	%rcx, 8(%r12)
	movq	%r10, 16(%r12)
	jmp	.L906
.L892:
	call	_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd
	movq	24(%rsp), %r9
	jmp	.L893
.L1046:
	movq	%rbp, %rsi
	movq	%r10, %rdi
	movq	%r8, 32(%rsp)
	movq	%rcx, 24(%rsp)
	call	memcpy@PLT
	movq	16(%r12), %rsi
	movq	24(%rsp), %rcx
	movq	32(%rsp), %r8
	movq	%rax, %r10
	subq	%rbp, %rsi
.L913:
	movq	%rbp, %rdi
	movq	%r8, 40(%rsp)
	movq	%r10, 32(%rsp)
	movq	%rcx, 24(%rsp)
	call	_ZdlPvm@PLT
	movq	40(%rsp), %r8
	movq	32(%rsp), %r10
	pxor	%xmm3, %xmm3
	movq	24(%rsp), %rcx
	jmp	.L914
.L1020:
	xorl	%ebp, %ebp
	xorl	%r12d, %r12d
	testq	%r14, %r14
	jne	.L882
	jmp	.L870
	.p2align 4,,10
	.p2align 3
.L1045:
	movq	%rbp, %rsi
	movq	%rcx, %rdi
	movq	%r8, 40(%rsp)
	movq	%r9, 32(%rsp)
	movq	%r10, 24(%rsp)
	call	memcpy@PLT
	movq	16(%r12), %rsi
	movq	24(%rsp), %r10
	movq	32(%rsp), %r9
	movq	40(%rsp), %r8
	movq	%rax, %rcx
	subq	%rbp, %rsi
	jmp	.L946
.L929:
	cmpq	$2, %rdx
	movq	%rbp, %rdx
	ja	.L930
	xorl	%esi, %esi
.L933:
	leaq	1(%rsi,%rsi), %r11
	movq	%r11, %rdi
	salq	$4, %rdi
	movdqu	0(%rbp,%rdi), %xmm1
	movq	%rsi, %rdi
	movq	%r11, %rsi
	movups	%xmm1, (%rdx)
	jmp	.L935
.L924:
	cmpq	$0, 32(%rsp)
	je	.L929
	movq	%rbp, %rdx
	jmp	.L930
.L1041:
	testq	%r14, %r14
	jne	.L882
	jmp	.L870
.L1047:
	movq	16(%r12), %rsi
	subq	%rbp, %rsi
	jmp	.L913
.L1039:
	call	__stack_chk_fail@PLT
.L910:
	movabsq	$9223372036854775792, %r15
	jmp	.L911
.L943:
	movabsq	$9223372036854775792, %r15
	jmp	.L944
	.section	.gcc_except_table
.LLSDA14758:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14758-.LLSDACSB14758
.LLSDACSB14758:
	.uleb128 .LEHB51-.LFB14758
	.uleb128 .LEHE51-.LEHB51
	.uleb128 0
	.uleb128 0
.LLSDACSE14758:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14758
	.type	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot.cold, @function
_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot.cold:
.LFSB14758:
.L871:
	.cfi_def_cfa_offset 288
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC20(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB52:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE52:
	movq	216(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1048
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB53:
	call	__cxa_throw@PLT
.L941:
	movq	216(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1049
	leaq	.LC4(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
.L1048:
	call	__stack_chk_fail@PLT
.L1049:
	call	__stack_chk_fail@PLT
.L970:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	216(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1050
	movq	%rbp, %rdi
	call	_Unwind_Resume@PLT
.LEHE53:
.L1050:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14758:
	.section	.gcc_except_table
.LLSDAC14758:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14758-.LLSDACSBC14758
.LLSDACSBC14758:
	.uleb128 .LEHB52-.LCOLDB21
	.uleb128 .LEHE52-.LEHB52
	.uleb128 .L970-.LCOLDB21
	.uleb128 0
	.uleb128 .LEHB53-.LCOLDB21
	.uleb128 .LEHE53-.LEHB53
	.uleb128 0
	.uleb128 0
.LLSDACSEC14758:
	.section	.text.unlikely
	.text
	.size	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot, .-_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot.cold, .-_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot.cold
.LCOLDE21:
	.text
.LHOTE21:
	.section	.text.unlikely
	.align 2
.LCOLDB22:
	.text
.LHOTB22:
	.align 2
	.p2align 4
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv:
.LFB14375:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14375
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r9
	movl	$16, %ecx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$216, %rsp
	.cfi_def_cfa_offset 272
	movq	%fs:40, %rax
	movq	%rax, 200(%rsp)
	xorl	%eax, %eax
	leaq	64(%rsp), %r11
	movq	%r11, %rdi
	rep stosq
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	jne	.L1189
	movq	(%r9), %r15
	xorl	%ebx, %ebx
	xorl	%ebp, %ebp
	movq	(%r15), %rdi
	cmpq	$1, %rdi
	jbe	.L1190
.L1056:
	cmpq	$16, %rdi
	jne	.L1054
.L1059:
	movq	16(%r9), %rax
	movq	%r11, %rcx
	movq	%r9, 16(%rsp)
	movq	%r11, 8(%rsp)
	movq	8(%rax), %rdx
	movq	(%rax), %rsi
	movq	8(%r9), %rax
	movq	(%rax), %rdi
	call	_ZN12minivectordb6detail23batch16_transposed_avx2EPKfS2_mPd
	movq	8(%rsp), %r11
	movq	16(%rsp), %r9
.L1063:
	testq	%rbp, %rbp
	je	.L1057
.L1055:
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r13d
	movq	%rax, %r12
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	8(%rsp), %r9
	movq	16(%rsp), %r11
	subq	%rbx, %rax
	addq	%rax, 16(%rbp)
	movl	%r13d, (%r12)
	movq	(%r9), %r15
.L1057:
	movq	(%r15), %rax
	testq	%rax, %rax
	je	.L1068
	movq	%r9, %r12
	xorl	%r13d, %r13d
	pxor	%xmm3, %xmm3
	movq	%r11, %r9
	jmp	.L1120
	.p2align 4,,10
	.p2align 3
.L1192:
	ucomisd	%xmm0, %xmm1
	jp	.L1188
	jne	.L1188
	cmpq	%r14, (%rax)
	jl	.L1117
.L1188:
	salq	$4, %rdx
	leaq	(%rbx,%rdx), %rax
.L1116:
	movq	%r14, (%rax)
	movsd	%xmm0, 8(%rax)
	movq	(%r15), %rax
.L1073:
	addq	$1, %r13
	cmpq	%rax, %r13
	jnb	.L1068
.L1120:
	movsd	(%r9,%r13,8), %xmm0
	movq	24(%r12), %rdx
	ucomisd	%xmm0, %xmm3
	movq	(%rdx,%r13,8), %r14
	ja	.L1172
	movq	32(%r12), %rbp
	movq	40(%r12), %rsi
	sqrtsd	%xmm0, %xmm0
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rdx
	subq	%rbx, %rdx
	movq	%rdx, %r8
	sarq	$4, %r8
	movq	%r8, %rdi
	cmpq	(%rsi), %r8
	jb	.L1071
	movsd	8(%rbx), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L1089
	ucomisd	%xmm1, %xmm0
	jp	.L1073
	jne	.L1073
	cmpq	(%rbx), %r14
	jge	.L1073
.L1089:
	leaq	-16(%rcx), %r10
	cmpq	$16, %rdx
	jg	.L1191
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	je	.L1107
.L1197:
	movq	%r14, -16(%rcx)
	movsd	%xmm0, -8(%rcx)
	movq	%rcx, 8(%rbp)
.L1108:
	leaq	-1(%r8), %rdx
	subq	$2, %r8
	movq	%r8, %rcx
	movq	%rdx, %rax
	shrq	$63, %rcx
	salq	$4, %rax
	addq	%r8, %rcx
	addq	%rbx, %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L1116
.L1115:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbx, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	jbe	.L1192
.L1117:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rbx,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1116
	movq	%rsi, %rcx
	jmp	.L1115
.L1189:
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r12d
	movq	%rax, %rbp
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	%rax, 56(%rsp)
	movq	%rax, %rbx
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movq	8(%rsp), %r9
	movl	%r12d, 0(%rbp)
	movq	16(%rsp), %r11
	movq	(%r9), %r15
	movq	(%r15), %rdi
	cmpq	$1, %rdi
	jbe	.L1193
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	je	.L1194
	movq	%fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff, %rdx
	movl	$1, %eax
	leaq	_ZN12minivectordb7profile6detail8countersE@tpoff, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L1060:
	addq	$1, %rdx
	addq	$1, %rax
	movq	%rdx, %fs:168(%rcx)
	movq	(%r15), %rdi
	cmpq	%rdi, %rax
	jb	.L1060
	cmpq	$16, %rdi
	je	.L1125
	testq	%rdi, %rdi
	je	.L1061
.L1184:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
.L1054:
	movq	16(%r9), %rdx
	xorl	%esi, %esi
	movq	8(%rdx), %rax
	leaq	0(,%rax,4), %rcx
	testq	%rax, %rax
	jne	.L1195
.L1171:
	addq	$1, %rsi
	cmpq	%rdi, %rsi
	jne	.L1171
	jmp	.L1063
	.p2align 4,,10
	.p2align 3
.L1071:
	cmpq	%rcx, 16(%rbp)
	je	.L1074
	movq	%r14, (%rcx)
	leaq	16(%rcx), %r14
	movsd	%xmm0, 8(%rcx)
	movq	%r14, 8(%rbp)
.L1075:
	movq	0(%rbp), %rdi
	movq	%r14, %rcx
	movq	-16(%r14), %r8
	subq	%rdi, %rcx
	movq	%rcx, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	subq	$2, %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	leaq	-16(%rdi,%rcx), %rax
	sarq	%rsi
	testq	%rdx, %rdx
	jle	.L1085
.L1084:
	movq	%rsi, %rax
	salq	$4, %rax
	addq	%rdi, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L1086
	ucomisd	%xmm0, %xmm1
	jp	.L1185
	jne	.L1185
	cmpq	(%rax), %r8
	jg	.L1086
.L1185:
	salq	$4, %rdx
	leaq	(%rdi,%rdx), %rax
.L1085:
	movq	%r8, (%rax)
	addq	$1, %r13
	movsd	%xmm0, 8(%rax)
	movq	(%r15), %rax
	cmpq	%rax, %r13
	jb	.L1120
.L1068:
	movq	$0, (%r15)
	movq	200(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1196
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1086:
	.cfi_restore_state
	movdqu	(%rax), %xmm1
	leaq	-1(%rsi), %rcx
	salq	$4, %rdx
	movups	%xmm1, (%rdi,%rdx)
	movq	%rcx, %rdx
	shrq	$63, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	sarq	%rcx
	testq	%rsi, %rsi
	je	.L1085
	movq	%rcx, %rsi
	jmp	.L1084
	.p2align 4,,10
	.p2align 3
.L1191:
	movq	-16(%rcx), %rax
	movq	%r10, %rsi
	movdqu	(%rbx), %xmm1
	subq	%rbx, %rsi
	movsd	-8(%rcx), %xmm2
	movq	%rax, 8(%rsp)
	movq	%rsi, %rax
	sarq	$4, %rax
	movups	%xmm1, -16(%rcx)
	leaq	-1(%rax), %rdx
	movq	%rax, %rdi
	movq	%rdx, %r11
	andl	$1, %edi
	shrq	$63, %r11
	movq	%rdi, 16(%rsp)
	addq	%rdx, %r11
	sarq	%r11
	cmpq	$32, %rsi
	jle	.L1092
	movq	%r14, 24(%rsp)
	xorl	%edi, %edi
	movq	%rbp, 32(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.L1095
	.p2align 4,,10
	.p2align 3
.L1128:
	movq	%rsi, %rdi
.L1095:
	leaq	1(%rdi), %rbp
	leaq	(%rbp,%rbp), %r14
	salq	$5, %rbp
	leaq	-1(%r14), %rsi
	addq	%rbx, %rbp
	movq	%rsi, %rdx
	movsd	8(%rbp), %xmm1
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm4
	comisd	%xmm1, %xmm4
	ja	.L1093
	ucomisd	%xmm1, %xmm4
	jp	.L1127
	jne	.L1127
	movq	0(%rbp), %rax
	cmpq	%rax, (%rdx)
	jg	.L1093
.L1127:
	movq	%rbp, %rdx
	movq	%r14, %rsi
.L1093:
	movdqu	(%rdx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, (%rbx,%rdi)
	cmpq	%rsi, %r11
	jg	.L1128
	cmpq	$0, 16(%rsp)
	movq	24(%rsp), %r14
	movq	32(%rsp), %rbp
	movq	40(%rsp), %rax
	jne	.L1186
	subq	$2, %rax
	sarq	%rax
	cmpq	%rsi, %rax
	je	.L1101
.L1186:
	leaq	-1(%rsi), %rdi
	movq	%rdi, %rax
	shrq	$63, %rax
	addq	%rdi, %rax
	sarq	%rax
	testq	%rsi, %rsi
	je	.L1098
.L1103:
	movq	%rax, %rdx
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L1104
	ucomisd	%xmm1, %xmm2
	jp	.L1187
	jne	.L1187
	movq	8(%rsp), %rdi
	cmpq	%rdi, (%rdx)
	jl	.L1104
.L1187:
	salq	$4, %rsi
	leaq	(%rbx,%rsi), %rdx
.L1098:
	movq	8(%rsp), %rax
	movsd	%xmm2, 8(%rdx)
	movq	%rax, (%rdx)
	movq	%r10, 8(%rbp)
	cmpq	%r10, 16(%rbp)
	jne	.L1197
.L1107:
	movabsq	$576460752303423487, %rdx
	subq	%rbx, %r10
	movq	%r10, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1109
	testq	%rax, %rax
	movl	$1, %edx
	cmovne	%rax, %rdx
	addq	%rdx, %rax
	jc	.L1111
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r15
	salq	$4, %r15
.L1112:
	movq	%r15, %rdi
	movq	%r9, 24(%rsp)
	movq	%r10, 16(%rsp)
	movsd	%xmm0, 8(%rsp)
.LEHB54:
	call	_Znwm@PLT
	movq	16(%rsp), %r10
	movsd	8(%rsp), %xmm0
	movq	%rax, %rcx
	movq	24(%rsp), %r9
	leaq	(%rax,%r10), %rax
	leaq	16(%r10), %r8
	testq	%r10, %r10
	movq	%r14, (%rax)
	leaq	(%rcx,%r8), %r14
	movsd	%xmm0, 8(%rax)
	jg	.L1198
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
.L1114:
	movq	%rbx, %rdi
	movq	%r9, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rcx, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %rcx
	movq	16(%rsp), %r8
	movq	%r14, 8(%rbp)
	movsd	-8(%r14), %xmm0
	movq	24(%rsp), %r9
	pxor	%xmm3, %xmm3
	addq	%rcx, %r15
	movq	%rcx, 0(%rbp)
	movq	-16(%r14), %r14
	sarq	$4, %r8
	movq	%r15, 16(%rbp)
	movq	%rcx, %rbx
	movq	(%r12), %r15
	jmp	.L1108
	.p2align 4,,10
	.p2align 3
.L1104:
	movdqu	(%rdx), %xmm1
	leaq	-1(%rax), %rdi
	salq	$4, %rsi
	movups	%xmm1, (%rbx,%rsi)
	movq	%rdi, %rsi
	shrq	$63, %rsi
	addq	%rdi, %rsi
	movq	%rsi, %rdi
	movq	%rax, %rsi
	sarq	%rdi
	testq	%rax, %rax
	je	.L1098
	movq	%rdi, %rax
	jmp	.L1103
.L1195:
	movq	(%rdx), %r8
	movq	8(%r9), %r10
	addq	%r8, %rcx
	.p2align 4
	.p2align 3
.L1065:
	movq	(%r10), %rdx
	movsd	(%r11,%rsi,8), %xmm1
	movq	%r8, %rax
	leaq	(%rdx,%rsi,4), %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L1064:
	pxor	%xmm0, %xmm0
	pxor	%xmm2, %xmm2
	addq	$4, %rax
	addq	$64, %rdx
	cvtss2sd	-4(%rax), %xmm0
	cvtss2sd	-64(%rdx), %xmm2
	subsd	%xmm2, %xmm0
	mulsd	%xmm0, %xmm0
	addsd	%xmm0, %xmm1
	cmpq	%rcx, %rax
	jne	.L1064
	movsd	%xmm1, (%r11,%rsi,8)
	addq	$1, %rsi
	cmpq	%rdi, %rsi
	jne	.L1065
	jmp	.L1063
.L1074:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	je	.L1109
	testq	%rdi, %rdi
	movl	$1, %eax
	cmovne	%rdi, %rax
	addq	%rax, %rdi
	jc	.L1079
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdi
	cmovbe	%rdi, %rax
	movq	%rax, %r15
	salq	$4, %r15
.L1080:
	movq	%r15, %rdi
	movq	%r9, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movsd	%xmm0, 8(%rsp)
	call	_Znwm@PLT
.LEHE54:
	movq	16(%rsp), %rdx
	movsd	8(%rsp), %xmm0
	pxor	%xmm3, %xmm3
	movq	%rax, %rcx
	movq	24(%rsp), %r9
	leaq	(%rax,%rdx), %rax
	testq	%rdx, %rdx
	movq	%r14, (%rax)
	leaq	16(%rcx,%rdx), %r14
	movsd	%xmm0, 8(%rax)
	jg	.L1199
	testq	%rbx, %rbx
	jne	.L1200
.L1083:
	movq	%rcx, 0(%rbp)
	addq	%r15, %rcx
	movsd	-8(%r14), %xmm0
	movq	%r14, 8(%rbp)
	movq	(%r12), %r15
	movq	%rcx, 16(%rbp)
	jmp	.L1075
.L1198:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r10, %rdx
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	8(%rsp), %r8
	movq	16(%rsp), %r9
	movq	%rax, %rcx
	subq	%rbx, %rsi
	jmp	.L1114
.L1193:
	testq	%rdi, %rdi
	je	.L1061
	movl	$1, %edi
	jmp	.L1184
.L1190:
	testq	%rdi, %rdi
	je	.L1057
	movl	$1, %edi
	jmp	.L1054
.L1199:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r9, 8(%rsp)
	call	memcpy@PLT
	movq	16(%rbp), %rsi
	movq	8(%rsp), %r9
	movq	%rax, %rcx
	subq	%rbx, %rsi
.L1082:
	movq	%rbx, %rdi
	movq	%r9, 16(%rsp)
	movq	%rcx, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	16(%rsp), %r9
	movq	8(%rsp), %rcx
	pxor	%xmm3, %xmm3
	jmp	.L1083
.L1097:
	cmpq	$2, %rdx
	movq	%rbx, %rdx
	ja	.L1098
	xorl	%esi, %esi
.L1101:
	leaq	1(%rsi,%rsi), %rdi
	movq	%rdi, %rax
	salq	$4, %rax
	movdqu	(%rbx,%rax), %xmm1
	movq	%rsi, %rax
	movq	%rdi, %rsi
	movups	%xmm1, (%rdx)
	jmp	.L1103
.L1092:
	cmpq	$0, 16(%rsp)
	je	.L1097
	movq	%rbx, %rdx
	jmp	.L1098
.L1125:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L1059
.L1061:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L1055
.L1200:
	movq	16(%rbp), %rsi
	subq	%rbx, %rsi
	jmp	.L1082
.L1194:
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rbp
	jmp	.L1056
.L1172:
	movq	%r9, 8(%rsp)
	call	sqrt@PLT
	movq	32(%r12), %rbp
	movq	40(%r12), %rax
	pxor	%xmm3, %xmm3
	movq	8(%rsp), %r9
	movq	8(%rbp), %rcx
	movq	0(%rbp), %rbx
	movq	%rcx, %rdx
	subq	%rbx, %rdx
	movq	%rdx, %rdi
	sarq	$4, %rdi
	cmpq	(%rax), %rdi
	jb	.L1071
	movq	(%r12), %r15
	movq	(%r15), %rax
	jmp	.L1073
.L1111:
	movabsq	$9223372036854775792, %r15
	jmp	.L1112
.L1196:
	call	__stack_chk_fail@PLT
.L1079:
	movabsq	$9223372036854775792, %r15
	jmp	.L1080
	.section	.gcc_except_table
.LLSDA14375:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14375-.LLSDACSB14375
.LLSDACSB14375:
	.uleb128 .LEHB54-.LFB14375
	.uleb128 .LEHE54-.LEHB54
	.uleb128 0
	.uleb128 0
.LLSDACSE14375:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14375
	.type	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, @function
_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold:
.LFSB14375:
.L1109:
	.cfi_def_cfa_offset 272
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	200(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1201
	leaq	.LC4(%rip), %rdi
.LEHB55:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE55:
.L1201:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14375:
	.section	.gcc_except_table
.LLSDAC14375:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14375-.LLSDACSBC14375
.LLSDACSBC14375:
	.uleb128 .LEHB55-.LCOLDB22
	.uleb128 .LEHE55-.LEHB55
	.uleb128 0
	.uleb128 0
.LLSDACSEC14375:
	.section	.text.unlikely
	.text
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv, .-_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
	.section	.text.unlikely
	.size	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold, .-_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv.cold
.LCOLDE22:
	.text
.LHOTE22:
	.section	.text.unlikely
.LCOLDB23:
	.text
.LHOTB23:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_:
.LFB15183:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA15183
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	(%rsi), %r12
	movq	(%rdx), %rbx
	movq	%fs:40, %rbp
	movq	%rbp, 8(%rsp)
	movq	(%rdi), %rbp
	movq	8(%rdx), %r13
	movq	0(%rbp), %rax
	cmpq	$0, 16(%rax)
	je	.L1206
	movq	%r12, (%rsp)
	movq	%rsp, %rsi
	movq	%rax, %rdi
.LEHB56:
	call	*24(%rax)
	testb	%al, %al
	je	.L1202
.L1206:
	movq	8(%rbp), %rax
	cmpq	%r13, 8(%rax)
	jne	.L1240
	movq	24(%rbp), %rdi
	movq	16(%rbp), %rdx
	movq	(%rdi), %rcx
	movq	%r12, (%rdx,%rcx,8)
	movq	8(%rax), %r9
	movq	(%rdi), %rsi
	testq	%r9, %r9
	je	.L1216
	movq	32(%rbp), %rax
	leaq	0(,%rsi,4), %r10
	leaq	0(,%r9,4), %rcx
	movq	(%rax), %r8
	leaq	-1(%r9), %rax
	cmpq	$6, %rax
	jbe	.L1212
	movq	%r9, %rax
	leaq	0(,%rsi,4), %r10
	salq	$4, %rax
	leaq	(%r8,%r10), %rdx
	addq	%rsi, %rax
	leaq	-60(%r8,%rax,4), %rax
	cmpq	%rax, %rbx
	jnb	.L1225
	leaq	0(,%r9,4), %rcx
	leaq	(%rbx,%rcx), %rax
	cmpq	%rax, %rdx
	jb	.L1212
.L1225:
	movq	%r9, %rcx
	movq	%rbx, %rax
	shrq	$2, %rcx
	salq	$4, %rcx
	addq	%rbx, %rcx
	.p2align 6
	.p2align 4
	.p2align 3
.L1214:
	movss	12(%rax), %xmm0
	movss	8(%rax), %xmm1
	addq	$16, %rax
	addq	$256, %rdx
	movss	-12(%rax), %xmm2
	movss	-16(%rax), %xmm3
	movss	%xmm1, -128(%rdx)
	movss	%xmm3, -256(%rdx)
	movss	%xmm2, -192(%rdx)
	movss	%xmm0, -64(%rdx)
	cmpq	%rcx, %rax
	jne	.L1214
	movq	%r9, %rax
	andq	$-4, %rax
	testb	$3, %r9b
	je	.L1216
	movq	%rax, %rdx
	movss	(%rbx,%rax,4), %xmm0
	leaq	1(%rax), %r10
	leaq	0(,%rax,4), %rcx
	salq	$4, %rdx
	addq	%rsi, %rdx
	movss	%xmm0, (%r8,%rdx,4)
	cmpq	%r9, %r10
	jnb	.L1216
	movss	4(%rbx,%rcx), %xmm0
	addq	$2, %rax
	movss	%xmm0, 64(%r8,%rdx,4)
	cmpq	%r9, %rax
	jnb	.L1216
	movss	8(%rbx,%rcx), %xmm0
	movss	%xmm0, 128(%r8,%rdx,4)
.L1216:
	addq	$1, %rsi
	movq	%rsi, (%rdi)
	cmpq	$16, %rsi
	je	.L1241
.L1202:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1239
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1241:
	.cfi_restore_state
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1239
	movq	40(%rbp), %rdi
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	jmp	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE56:
	.p2align 4,,10
	.p2align 3
.L1212:
	.cfi_restore_state
	movq	%rbx, %rax
	leaq	(%r8,%r10), %rdx
	addq	%rbx, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L1218:
	movss	(%rax), %xmm0
	addq	$4, %rax
	addq	$64, %rdx
	movss	%xmm0, -64(%rdx)
	cmpq	%rcx, %rax
	jne	.L1218
	addq	$1, %rsi
	movq	%rsi, (%rdi)
	cmpq	$16, %rsi
	jne	.L1202
	jmp	.L1241
.L1239:
	call	__stack_chk_fail@PLT
.L1240:
	jmp	.L1204
	.section	.gcc_except_table
.LLSDA15183:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE15183-.LLSDACSB15183
.LLSDACSB15183:
	.uleb128 .LEHB56-.LFB15183
	.uleb128 .LEHE56-.LEHB56
	.uleb128 0
	.uleb128 0
.LLSDACSE15183:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC15183
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold:
.LFSB15183:
.L1204:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 13, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC11(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB57:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE57:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1238
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB58:
	call	__cxa_throw@PLT
.L1224:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1238
	movq	%rbp, %rdi
	call	_Unwind_Resume@PLT
.LEHE58:
.L1238:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE15183:
	.section	.gcc_except_table
.LLSDAC15183:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC15183-.LLSDACSBC15183
.LLSDACSBC15183:
	.uleb128 .LEHB57-.LCOLDB23
	.uleb128 .LEHE57-.LEHB57
	.uleb128 .L1224-.LCOLDB23
	.uleb128 0
	.uleb128 .LEHB58-.LCOLDB23
	.uleb128 .LEHE58-.LEHB58
	.uleb128 0
	.uleb128 0
.LLSDACSEC15183:
	.section	.text.unlikely
	.text
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold
.LCOLDE23:
	.text
.LHOTE23:
	.section	.text.unlikely
.LCOLDB25:
	.text
.LHOTB25:
	.p2align 4
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, @function
_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE:
.LFB14368:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14368
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %rax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%r8, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$360, %rsp
	.cfi_def_cfa_offset 416
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
	movq	24(%rsp), %rsi
	movq	%rcx, 8(%rsp)
	leaq	(%rax,%rsi,4), %rdx
	movq	%fs:40, %r12
	movq	%r12, 344(%rsp)
	movq	%r9, %r12
	cmpq	%rdx, %rax
	je	.L1243
	movss	.LC1(%rip), %xmm1
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L1247:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L1321
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L1247
.L1243:
	movq	8(%rsp), %rcx
	testq	%rcx, %rcx
	jne	.L1248
	movq	$0, 16(%rbx)
	pxor	%xmm0, %xmm0
	movups	%xmm0, (%rbx)
.L1242:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1377
	addq	$360, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1248:
	.cfi_restore_state
	leaq	-16(%rsi), %rax
	cmpq	$1008, %rax
	jbe	.L1250
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	%rbx, %rdi
.LEHB59:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE59:
	jmp	.L1242
	.p2align 4,,10
	.p2align 3
.L1250:
	pxor	%xmm0, %xmm0
	salq	$6, %rsi
	movl	$16, %ecx
	xorl	%eax, %eax
	leaq	208(%rsp), %rdi
	movaps	%xmm0, 80(%rsp)
	pxor	%xmm0, %xmm0
	movq	%rsi, %r13
	movq	%rdi, (%rsp)
	rep stosq
	movq	%rsi, %rdi
	movaps	%xmm0, 48(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 64(%rsp)
.LEHB60:
	call	_Znwm@PLT
.LEHE60:
	movl	$0x00000000, (%rax)
	movq	%rax, %r15
	leaq	-4(%r13), %rdx
	xorl	%esi, %esi
	leaq	4(%rax), %rdi
	leaq	(%rax,%r13), %r14
	leaq	48(%rsp), %r13
	call	memset@PLT
	movq	%r15, 48(%rsp)
	leaq	40(%rsp), %r15
	movq	%r13, %xmm3
	movq	%r15, %xmm0
	movq	%r14, 56(%rsp)
	leaq	80(%rsp), %rax
	movl	$48, %edi
	punpcklqdq	%xmm3, %xmm0
	movq	%r14, 64(%rsp)
	leaq	16(%rsp), %r14
	movaps	%xmm0, 112(%rsp)
	movq	%r14, %xmm0
	movq	$0, 40(%rsp)
	movhps	(%rsp), %xmm0
	movaps	%xmm0, 128(%rsp)
	movq	%rax, %xmm0
	leaq	8(%rsp), %rax
	movq	%rax, %xmm4
	leaq	39(%rsp), %rax
	movq	$0, 192(%rsp)
	punpcklqdq	%xmm4, %xmm0
	movq	%rax, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	pxor	%xmm0, %xmm0
	movq	$0, 200(%rsp)
	movaps	%xmm0, 176(%rsp)
.LEHB61:
	call	_Znwm@PLT
.LEHE61:
	movq	(%rsp), %rdi
	movq	%r13, 32(%rax)
	leaq	112(%rsp), %r13
	movq	%r12, (%rax)
	cmpq	$0, 16(%rbp)
	movq	%r14, 8(%rax)
	movq	.LC24(%rip), %xmm0
	movq	%rdi, 16(%rax)
	movq	%r15, 24(%rax)
	movq	%r13, 40(%rax)
	movq	%rax, 176(%rsp)
	leaq	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_(%rip), %rax
	movq	%rax, %xmm5
	punpcklqdq	%xmm5, %xmm0
	movaps	%xmm0, 192(%rsp)
	je	.L1378
	leaq	176(%rsp), %r12
	movq	%rbp, %rdi
	movq	%r12, %rsi
.LEHB62:
	call	*24(%rbp)
.LEHE62:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L1257
	movl	$3, %edx
	movq	%r12, %rsi
	movq	%r12, %rdi
	call	*%rax
.L1257:
	cmpq	$0, 40(%rsp)
	je	.L1258
	movq	%r13, %rdi
.LEHB63:
	call	_ZZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEENKUlvE_clEv
.LEHE63:
.L1258:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movabsq	$9223372036854775792, %rdx
	movq	%rax, %rbp
	subq	%r13, %rbp
	cmpq	%rbp, %rdx
	jb	.L1366
	testq	%rbp, %rbp
	jne	.L1261
	xorl	%r14d, %r14d
	xorl	%r12d, %r12d
	cmpq	%r13, %rax
	je	.L1263
.L1262:
	movq	%r14, %r12
	jmp	.L1290
	.p2align 4,,10
	.p2align 3
.L1274:
	movq	%r9, 88(%rsp)
	cmpq	%r9, %r13
	je	.L1379
.L1290:
	cmpq	%r14, %rbp
	je	.L1264
	movdqu	0(%r13), %xmm0
	addq	$16, %r14
	movups	%xmm0, -16(%r14)
.L1265:
	movq	88(%rsp), %rax
	movq	80(%rsp), %r13
	movq	%rax, %rdx
	leaq	-16(%rax), %r9
	subq	%r13, %rdx
	cmpq	$16, %rdx
	jle	.L1274
	movq	%r9, %rdx
	movdqu	0(%r13), %xmm0
	movq	-16(%rax), %r11
	subq	%r13, %rdx
	movsd	-8(%rax), %xmm1
	movq	%rdx, %r10
	movups	%xmm0, -16(%rax)
	sarq	$4, %r10
	leaq	-1(%r10), %rax
	movq	%r10, %r15
	movq	%rax, %r8
	andl	$1, %r15d
	shrq	$63, %r8
	addq	%rax, %r8
	sarq	%r8
	cmpq	$32, %rdx
	jle	.L1275
	movq	%r9, (%rsp)
	xorl	%esi, %esi
	jmp	.L1278
	.p2align 4,,10
	.p2align 3
.L1312:
	movq	%rcx, %rsi
.L1278:
	leaq	1(%rsi), %rax
	leaq	(%rax,%rax), %rdi
	salq	$5, %rax
	leaq	-1(%rdi), %rcx
	addq	%r13, %rax
	movq	%rcx, %rdx
	movsd	8(%rax), %xmm0
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L1276
	ucomisd	%xmm0, %xmm2
	jp	.L1311
	jne	.L1311
	movq	(%rax), %r9
	cmpq	%r9, (%rdx)
	jg	.L1276
.L1311:
	movq	%rax, %rdx
	movq	%rdi, %rcx
.L1276:
	movdqu	(%rdx), %xmm0
	salq	$4, %rsi
	movups	%xmm0, 0(%r13,%rsi)
	cmpq	%r8, %rcx
	jl	.L1312
	movq	(%rsp), %r9
	testq	%r15, %r15
	jne	.L1375
	subq	$2, %r10
	sarq	%r10
	cmpq	%rcx, %r10
	je	.L1284
.L1375:
	leaq	-1(%rcx), %rax
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1281
.L1286:
	movq	%rsi, %rdx
	salq	$4, %rdx
	addq	%r13, %rdx
	movsd	8(%rdx), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L1287
	ucomisd	%xmm0, %xmm1
	jp	.L1376
	jne	.L1376
	cmpq	(%rdx), %r11
	jg	.L1287
.L1376:
	salq	$4, %rcx
	leaq	0(%r13,%rcx), %rdx
.L1281:
	movq	%r11, (%rdx)
	movsd	%xmm1, 8(%rdx)
	jmp	.L1274
	.p2align 4,,10
	.p2align 3
.L1287:
	movdqu	(%rdx), %xmm0
	salq	$4, %rcx
	movups	%xmm0, 0(%r13,%rcx)
	leaq	-1(%rsi), %rcx
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rcx, %rax
	movq	%rsi, %rcx
	sarq	%rax
	testq	%rsi, %rsi
	je	.L1281
	movq	%rax, %rsi
	jmp	.L1286
	.p2align 4,,10
	.p2align 3
.L1264:
	movabsq	$576460752303423487, %rax
	movq	%rbp, %rsi
	subq	%r12, %rsi
	movq	%rsi, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L1367
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L1269
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L1270:
	movq	%r15, %rdi
	movq	%rsi, (%rsp)
.LEHB64:
	call	_Znwm@PLT
.LEHE64:
	movq	(%rsp), %rsi
	movdqu	0(%r13), %xmm0
	movq	%rax, %rcx
	movups	%xmm0, (%rax,%rsi)
	leaq	16(%rax,%rsi), %r14
	testq	%rsi, %rsi
	jg	.L1380
	testq	%r12, %r12
	jne	.L1272
.L1273:
	leaq	(%rcx,%r15), %rbp
	movq	%rcx, %r12
	jmp	.L1265
	.p2align 4,,10
	.p2align 3
.L1379:
	cmpq	%r14, %r12
	je	.L1263
	leaq	-16(%r14), %rax
	cmpq	%rax, %r12
	jnb	.L1263
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L1292:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L1292
.L1263:
	movq	%r12, (%rbx)
	movq	%r14, 8(%rbx)
	movq	%rbp, 16(%rbx)
.L1298:
	movq	48(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L1293
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L1293:
	movq	80(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L1242
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	jmp	.L1242
.L1380:
	movq	%rsi, %rdx
	movq	%rax, %rdi
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %rcx
.L1272:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%rcx, (%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L1273
.L1275:
	movq	%r13, %rdx
	testq	%r15, %r15
	jne	.L1281
	cmpq	$2, %rax
	ja	.L1281
	xorl	%ecx, %ecx
.L1284:
	leaq	1(%rcx,%rcx), %rax
	movq	%rax, %rsi
	salq	$4, %rsi
	movdqu	0(%r13,%rsi), %xmm0
	movq	%rcx, %rsi
	movq	%rax, %rcx
	movups	%xmm0, (%rdx)
	jmp	.L1286
.L1261:
	movq	%rbp, %rdi
.LEHB65:
	call	_Znwm@PLT
.LEHE65:
	movq	80(%rsp), %r13
	movq	%rax, %r14
	addq	%rax, %rbp
	cmpq	88(%rsp), %r13
	jne	.L1262
	movq	%rax, %r12
	jmp	.L1263
.L1269:
	movabsq	$9223372036854775792, %r15
	jmp	.L1270
.L1377:
	call	__stack_chk_fail@PLT
.L1320:
	movq	%rax, %rbx
	jmp	.L1253
.L1315:
	movq	%rax, %rdi
	movq	%rdx, %rax
	jmp	.L1296
.L1364:
	jmp	.L1365
.L1362:
	jmp	.L1363
.L1378:
	jmp	.L1251
.L1360:
	jmp	.L1361
	.section	.gcc_except_table
	.align 4
.LLSDA14368:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT14368-.LLSDATTD14368
.LLSDATTD14368:
	.byte	0x1
	.uleb128 .LLSDACSE14368-.LLSDACSB14368
.LLSDACSB14368:
	.uleb128 .LEHB59-.LFB14368
	.uleb128 .LEHE59-.LEHB59
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB60-.LFB14368
	.uleb128 .LEHE60-.LEHB60
	.uleb128 .L1315-.LFB14368
	.uleb128 0x3
	.uleb128 .LEHB61-.LFB14368
	.uleb128 .LEHE61-.LEHB61
	.uleb128 .L1320-.LFB14368
	.uleb128 0
	.uleb128 .LEHB62-.LFB14368
	.uleb128 .LEHE62-.LEHB62
	.uleb128 .L1362-.LFB14368
	.uleb128 0
	.uleb128 .LEHB63-.LFB14368
	.uleb128 .LEHE63-.LEHB63
	.uleb128 .L1360-.LFB14368
	.uleb128 0
	.uleb128 .LEHB64-.LFB14368
	.uleb128 .LEHE64-.LEHB64
	.uleb128 .L1364-.LFB14368
	.uleb128 0
	.uleb128 .LEHB65-.LFB14368
	.uleb128 .LEHE65-.LEHB65
	.uleb128 .L1360-.LFB14368
	.uleb128 0
.LLSDACSE14368:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATT14368:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14368
	.type	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, @function
_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold:
.LFSB14368:
.L1321:
	.cfi_def_cfa_offset 416
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB66:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE66:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1381
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB67:
	call	__cxa_throw@PLT
.LEHE67:
.L1367:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1382
	leaq	.LC4(%rip), %rdi
.LEHB68:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE68:
.L1253:
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L1255
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
.L1255:
	movq	48(%rsp), %rdi
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1304
	call	_ZdlPvm@PLT
.L1304:
	movq	80(%rsp), %rdi
	movq	96(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1305
	call	_ZdlPvm@PLT
.L1305:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1383
	movq	%rbx, %rdi
.LEHB69:
	call	_Unwind_Resume@PLT
.LEHE69:
.L1296:
	subq	$1, %rax
	jne	.L1384
	call	__cxa_begin_catch@PLT
	movq	8(%rsp), %rcx
	movq	%r12, %r9
	movq	%rbp, %r8
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdx
	movq	%rbx, %rdi
.LEHB70:
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.LEHE70:
	call	__cxa_end_catch@PLT
	jmp	.L1298
.L1383:
	call	__stack_chk_fail@PLT
.L1382:
	call	__stack_chk_fail@PLT
.L1384:
	movq	%rdi, %rbx
	jmp	.L1255
.L1319:
.L1365:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L1255
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1255
.L1317:
	movq	%rax, %rbx
	call	__cxa_end_catch@PLT
	jmp	.L1255
.L1366:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1385
	leaq	.LC3(%rip), %rdi
.LEHB71:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE71:
.L1381:
	call	__stack_chk_fail@PLT
.L1318:
.L1363:
	movq	%rax, %rbx
	movq	192(%rsp), %rax
	testq	%rax, %rax
	je	.L1255
	leaq	176(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L1255
.L1251:
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1386
.LEHB72:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE72:
.L1386:
	call	__stack_chk_fail@PLT
.L1316:
.L1361:
	movq	%rax, %rbx
	jmp	.L1255
.L1314:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	344(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1387
	movq	%rbp, %rdi
.LEHB73:
	call	_Unwind_Resume@PLT
.LEHE73:
.L1385:
	call	__stack_chk_fail@PLT
.L1387:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14368:
	.section	.gcc_except_table
	.align 4
.LLSDAC14368:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATTC14368-.LLSDATTDC14368
.LLSDATTDC14368:
	.byte	0x1
	.uleb128 .LLSDACSEC14368-.LLSDACSBC14368
.LLSDACSBC14368:
	.uleb128 .LEHB66-.LCOLDB25
	.uleb128 .LEHE66-.LEHB66
	.uleb128 .L1314-.LCOLDB25
	.uleb128 0
	.uleb128 .LEHB67-.LCOLDB25
	.uleb128 .LEHE67-.LEHB67
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB68-.LCOLDB25
	.uleb128 .LEHE68-.LEHB68
	.uleb128 .L1319-.LCOLDB25
	.uleb128 0
	.uleb128 .LEHB69-.LCOLDB25
	.uleb128 .LEHE69-.LEHB69
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB70-.LCOLDB25
	.uleb128 .LEHE70-.LEHB70
	.uleb128 .L1317-.LCOLDB25
	.uleb128 0
	.uleb128 .LEHB71-.LCOLDB25
	.uleb128 .LEHE71-.LEHB71
	.uleb128 .L1316-.LCOLDB25
	.uleb128 0
	.uleb128 .LEHB72-.LCOLDB25
	.uleb128 .LEHE72-.LEHB72
	.uleb128 .L1318-.LCOLDB25
	.uleb128 0
	.uleb128 .LEHB73-.LCOLDB25
	.uleb128 .LEHE73-.LEHB73
	.uleb128 0
	.uleb128 0
.LLSDACSEC14368:
	.byte	0
	.byte	0
	.byte	0x1
	.byte	0x7d
	.align 4
	.long	DW.ref._ZTISt9bad_alloc-.
.LLSDATTC14368:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE, .-_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	.section	.text.unlikely
	.size	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold, .-_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE.cold
.LCOLDE25:
	.text
.LHOTE25:
	.section	.text._ZN12minivectordb7profile6detail5ScopeD2Ev,"axG",@progbits,_ZN12minivectordb7profile6detail5ScopeD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZN12minivectordb7profile6detail5ScopeD2Ev
	.type	_ZN12minivectordb7profile6detail5ScopeD2Ev, @function
_ZN12minivectordb7profile6detail5ScopeD2Ev:
.LFB12899:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA12899
	cmpq	$0, (%rdi)
	je	.L1391
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbx
	call	__errno_location@PLT
	movl	(%rax), %r12d
	movq	%rax, %rbp
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	(%rbx), %rdx
	subq	8(%rbx), %rax
	addq	%rax, 16(%rdx)
	movl	%r12d, 0(%rbp)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1391:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	ret
	.cfi_endproc
.LFE12899:
	.section	.gcc_except_table
.LLSDA12899:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE12899-.LLSDACSB12899
.LLSDACSB12899:
.LLSDACSE12899:
	.section	.text._ZN12minivectordb7profile6detail5ScopeD2Ev,"axG",@progbits,_ZN12minivectordb7profile6detail5ScopeD5Ev,comdat
	.size	_ZN12minivectordb7profile6detail5ScopeD2Ev, .-_ZN12minivectordb7profile6detail5ScopeD2Ev
	.weak	_ZN12minivectordb7profile6detail5ScopeD1Ev
	.set	_ZN12minivectordb7profile6detail5ScopeD1Ev,_ZN12minivectordb7profile6detail5ScopeD2Ev
	.section	.rodata.str1.1
.LC26:
	.string	"non-finite VECTOR component"
	.section	.text.unlikely
.LCOLDB27:
	.text
.LHOTB27:
	.p2align 4
	.type	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_, @function
_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_:
.LFB14237:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14237
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%fs:40, %r15
	movq	%r15, 40(%rsp)
	movq	%rcx, %r15
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	jne	.L1395
	movq	$0, 16(%rsp)
	cmpq	%r15, %rsi
	jne	.L1413
	xorl	%r14d, %r14d
	xorl	%ebp, %ebp
	pxor	%xmm2, %xmm2
	testq	%rsi, %rsi
	je	.L1394
.L1397:
	movss	.LC1(%rip), %xmm3
	xorl	%edx, %edx
	pxor	%xmm2, %xmm2
	movss	.LC0(%rip), %xmm4
	.p2align 4
	.p2align 3
.L1405:
	movss	(%r12,%rdx,4), %xmm0
	movaps	%xmm0, %xmm1
	andps	%xmm4, %xmm1
	ucomiss	%xmm1, %xmm3
	jb	.L1401
	movss	0(%r13,%rdx,4), %xmm1
	movaps	%xmm1, %xmm5
	andps	%xmm4, %xmm5
	ucomiss	%xmm5, %xmm3
	jb	.L1401
	cvtss2sd	%xmm0, %xmm0
	cvtss2sd	%xmm1, %xmm1
	subsd	%xmm1, %xmm0
	addq	$1, %rdx
	mulsd	%xmm0, %xmm0
	addsd	%xmm0, %xmm2
	cmpq	%rbx, %rdx
	jb	.L1405
	testq	%r14, %r14
	je	.L1394
.L1399:
	movsd	%xmm2, (%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r12d
	movq	%rax, %rbx
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movsd	(%rsp), %xmm2
	subq	%rbp, %rax
	addq	%rax, 16(%r14)
	movl	%r12d, (%rbx)
.L1394:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1428
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movapd	%xmm2, %xmm0
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1395:
	.cfi_restore_state
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %r14
	movq	%r14, 16(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %ecx
	movq	%rax, 8(%rsp)
	movl	%ecx, (%rsp)
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	%rax, 24(%rsp)
	movq	%rax, %rbp
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movl	(%rsp), %ecx
	movq	8(%rsp), %rdx
	movl	%ecx, (%rdx)
	cmpq	%r15, %rbx
	jne	.L1396
	pxor	%xmm2, %xmm2
	testq	%rbx, %rbx
	jne	.L1397
	jmp	.L1399
.L1428:
	call	__stack_chk_fail@PLT
	.section	.gcc_except_table
.LLSDA14237:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14237-.LLSDACSB14237
.LLSDACSB14237:
.LLSDACSE14237:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC14237
	.type	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_.cold, @function
_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_.cold:
.LFSB14237:
.L1401:
	.cfi_def_cfa_offset 112
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC26(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %r12
.LEHB74:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE74:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1429
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%r12, %rdi
.LEHB75:
	call	__cxa_throw@PLT
.LEHE75:
.L1413:
	xorl	%ebp, %ebp
.L1396:
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC11(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %r12
.LEHB76:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE76:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1430
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%r12, %rdi
.LEHB77:
	call	__cxa_throw@PLT
.LEHE77:
.L1429:
	call	__stack_chk_fail@PLT
.L1430:
	call	__stack_chk_fail@PLT
.L1416:
.L1427:
	movq	%r12, %rdi
	movq	%rax, %rbx
	call	__cxa_free_exception@PLT
.L1409:
	leaq	16(%rsp), %rdi
	movq	%rbp, 24(%rsp)
	call	_ZN12minivectordb7profile6detail5ScopeD1Ev
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1431
	movq	%rbx, %rdi
.LEHB78:
	call	_Unwind_Resume@PLT
.LEHE78:
.L1418:
	movq	%rax, %rbx
	jmp	.L1409
.L1417:
	jmp	.L1427
.L1431:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14237:
	.section	.gcc_except_table
.LLSDAC14237:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC14237-.LLSDACSBC14237
.LLSDACSBC14237:
	.uleb128 .LEHB74-.LCOLDB27
	.uleb128 .LEHE74-.LEHB74
	.uleb128 .L1417-.LCOLDB27
	.uleb128 0
	.uleb128 .LEHB75-.LCOLDB27
	.uleb128 .LEHE75-.LEHB75
	.uleb128 .L1418-.LCOLDB27
	.uleb128 0
	.uleb128 .LEHB76-.LCOLDB27
	.uleb128 .LEHE76-.LEHB76
	.uleb128 .L1416-.LCOLDB27
	.uleb128 0
	.uleb128 .LEHB77-.LCOLDB27
	.uleb128 .LEHE77-.LEHB77
	.uleb128 .L1418-.LCOLDB27
	.uleb128 0
	.uleb128 .LEHB78-.LCOLDB27
	.uleb128 .LEHE78-.LEHB78
	.uleb128 0
	.uleb128 0
.LLSDACSEC14237:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_, .-_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_
	.section	.text.unlikely
	.size	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_.cold, .-_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_.cold
.LCOLDE27:
	.text
.LHOTE27:
	.section	.text.unlikely
.LCOLDB28:
	.text
.LHOTB28:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_:
.LFB15073:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	(%rsi), %rbx
	movq	(%rdx), %r14
	movq	%fs:40, %r13
	movq	%r13, 24(%rsp)
	movq	(%rdi), %r13
	movq	8(%rdx), %r15
	movq	0(%r13), %rax
	cmpq	$0, 16(%rax)
	je	.L1436
	movq	%rbx, 16(%rsp)
	leaq	16(%rsp), %rsi
	movq	%rax, %rdi
	call	*24(%rax)
	testb	%al, %al
	je	.L1437
.L1436:
	movq	8(%r13), %rax
	movq	%r14, %rdx
	movq	%r15, %rcx
	movq	(%rax), %rdi
	movq	8(%rax), %rsi
	call	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_
	pxor	%xmm1, %xmm1
	ucomisd	%xmm0, %xmm1
	ja	.L1530
	movq	16(%r13), %r12
	movq	24(%r13), %rax
	sqrtsd	%xmm0, %xmm0
	movq	8(%r12), %rsi
	movq	(%r12), %rbp
	movq	%rsi, %r14
	subq	%rbp, %r14
	movq	%r14, %r8
	sarq	$4, %r8
	movq	%r8, %rdx
	cmpq	(%rax), %r8
	jb	.L1438
	movsd	8(%rbp), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L1455
	ucomisd	%xmm1, %xmm0
	jp	.L1437
	jne	.L1437
	cmpq	0(%rbp), %rbx
	jge	.L1437
.L1455:
	leaq	-16(%rsi), %r10
	cmpq	$16, %r14
	jg	.L1531
.L1458:
	movq	%r10, 8(%r12)
	cmpq	%r10, 16(%r12)
	je	.L1474
	movq	%rbx, -16(%rsi)
	movsd	%xmm0, -8(%rsi)
	movq	%rsi, 8(%r12)
.L1475:
	leaq	-1(%r8), %rdx
	subq	$2, %r8
	movq	%r8, %rcx
	shrq	$63, %rcx
	addq	%r8, %rcx
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L1529
.L1482:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbp, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L1484
	ucomisd	%xmm0, %xmm1
	jp	.L1529
	jne	.L1529
	cmpq	%rbx, (%rax)
	jge	.L1529
.L1484:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, 0(%rbp,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1483
	movq	%rsi, %rcx
	jmp	.L1482
	.p2align 4,,10
	.p2align 3
.L1529:
	salq	$4, %rdx
	leaq	0(%rbp,%rdx), %rax
.L1483:
	movq	%rbx, (%rax)
	movsd	%xmm0, 8(%rax)
.L1437:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1532
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1530:
	.cfi_restore_state
	call	sqrt@PLT
	movq	16(%r13), %r12
	movq	24(%r13), %rax
	movq	8(%r12), %rsi
	movq	(%r12), %rbp
	movq	%rsi, %r14
	subq	%rbp, %r14
	movq	%r14, %rdx
	sarq	$4, %rdx
	cmpq	(%rax), %rdx
	jnb	.L1437
	.p2align 4
	.p2align 3
.L1438:
	cmpq	%rsi, 16(%r12)
	je	.L1440
	movq	%rbx, (%rsi)
	leaq	16(%rsi), %rbx
	movsd	%xmm0, 8(%rsi)
	movq	%rbx, 8(%r12)
.L1441:
	movq	(%r12), %rdi
	movq	-16(%rbx), %r8
	subq	%rdi, %rbx
	movq	%rbx, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	subq	$2, %rax
	movq	%rax, %rcx
	shrq	$63, %rcx
	addq	%rax, %rcx
	leaq	-16(%rdi,%rbx), %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L1451
.L1450:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rdi, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L1452
	ucomisd	%xmm0, %xmm1
	jp	.L1526
	jne	.L1526
	cmpq	%r8, (%rax)
	jl	.L1452
.L1526:
	salq	$4, %rdx
	leaq	(%rdi,%rdx), %rax
.L1451:
	movq	%r8, (%rax)
	movsd	%xmm0, 8(%rax)
	jmp	.L1437
	.p2align 4,,10
	.p2align 3
.L1452:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rdi,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1451
	movq	%rsi, %rcx
	jmp	.L1450
	.p2align 4,,10
	.p2align 3
.L1531:
	movq	%r10, %rdx
	movdqu	0(%rbp), %xmm1
	movq	-16(%rsi), %r14
	subq	%rbp, %rdx
	movsd	-8(%rsi), %xmm2
	movq	%rdx, %r13
	movups	%xmm1, -16(%rsi)
	sarq	$4, %r13
	leaq	-1(%r13), %rax
	movq	%r13, %r15
	movq	%rax, %r11
	andl	$1, %r15d
	shrq	$63, %r11
	addq	%rax, %r11
	sarq	%r11
	cmpq	$32, %rdx
	jle	.L1459
	movq	%rsi, 8(%rsp)
	xorl	%edi, %edi
	jmp	.L1462
	.p2align 4,,10
	.p2align 3
.L1490:
	movq	%rax, %rdi
.L1462:
	leaq	1(%rdi), %rdx
	leaq	(%rdx,%rdx), %r9
	salq	$5, %rdx
	leaq	-1(%r9), %rax
	addq	%rbp, %rdx
	movq	%rax, %rcx
	movsd	8(%rdx), %xmm1
	salq	$4, %rcx
	addq	%rbp, %rcx
	movsd	8(%rcx), %xmm3
	comisd	%xmm1, %xmm3
	ja	.L1460
	ucomisd	%xmm1, %xmm3
	jp	.L1489
	jne	.L1489
	movq	(%rdx), %rsi
	cmpq	%rsi, (%rcx)
	jg	.L1460
.L1489:
	movq	%rdx, %rcx
	movq	%r9, %rax
.L1460:
	movdqu	(%rcx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, 0(%rbp,%rdi)
	cmpq	%rax, %r11
	jg	.L1490
	movq	8(%rsp), %rsi
	testq	%r15, %r15
	je	.L1466
.L1527:
	leaq	-1(%rax), %rdi
	movq	%rdi, %rdx
	shrq	$63, %rdx
	addq	%rdi, %rdx
	sarq	%rdx
	testq	%rax, %rax
	je	.L1465
.L1470:
	movq	%rdx, %rcx
	salq	$4, %rcx
	addq	%rbp, %rcx
	movsd	8(%rcx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L1471
	ucomisd	%xmm1, %xmm2
	jp	.L1528
	jne	.L1528
	cmpq	%r14, (%rcx)
	jge	.L1528
.L1471:
	movdqu	(%rcx), %xmm1
	leaq	-1(%rdx), %rdi
	salq	$4, %rax
	movups	%xmm1, 0(%rbp,%rax)
	movq	%rdi, %rax
	shrq	$63, %rax
	addq	%rdi, %rax
	sarq	%rax
	movq	%rax, %rdi
	movq	%rdx, %rax
	testq	%rdx, %rdx
	je	.L1465
	movq	%rdi, %rdx
	jmp	.L1470
	.p2align 4,,10
	.p2align 3
.L1528:
	salq	$4, %rax
	leaq	0(%rbp,%rax), %rcx
.L1465:
	movq	%r14, (%rcx)
	movsd	%xmm2, 8(%rcx)
	jmp	.L1458
	.p2align 4,,10
	.p2align 3
.L1474:
	movabsq	$576460752303423487, %rdx
	movq	%r10, %r15
	subq	%rbp, %r15
	movq	%r15, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1476
	testq	%rax, %rax
	movl	$1, %edx
	cmovne	%rax, %rdx
	addq	%rdx, %rax
	jc	.L1478
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r13
	salq	$4, %r13
.L1479:
	movq	%r13, %rdi
	movsd	%xmm0, 8(%rsp)
	call	_Znwm@PLT
	movsd	8(%rsp), %xmm0
	leaq	16(%r15), %r8
	movq	%rax, %r14
	leaq	(%rax,%r15), %rax
	movq	%rbx, (%rax)
	leaq	(%r14,%r8), %rbx
	movsd	%xmm0, 8(%rax)
	testq	%r15, %r15
	jg	.L1533
	movq	16(%r12), %rsi
	subq	%rbp, %rsi
.L1481:
	movq	%rbp, %rdi
	movq	%r8, 8(%rsp)
	addq	%r14, %r13
	movq	%r14, %rbp
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
	movq	%rbx, 8(%r12)
	movsd	-8(%rbx), %xmm0
	movq	-16(%rbx), %rbx
	movq	%r14, (%r12)
	movq	%r13, 16(%r12)
	sarq	$4, %r8
	jmp	.L1475
	.p2align 4,,10
	.p2align 3
.L1466:
	subq	$2, %r13
	sarq	%r13
	cmpq	%rax, %r13
	jne	.L1527
.L1468:
	leaq	1(%rax,%rax), %rdi
	movq	%rdi, %rdx
	salq	$4, %rdx
	movdqu	0(%rbp,%rdx), %xmm1
	movq	%rax, %rdx
	movq	%rdi, %rax
	movups	%xmm1, (%rcx)
	jmp	.L1470
	.p2align 4,,10
	.p2align 3
.L1440:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdx
	je	.L1476
	testq	%rdx, %rdx
	movl	$1, %eax
	cmovne	%rdx, %rax
	addq	%rax, %rdx
	jc	.L1445
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdx
	cmovbe	%rdx, %rax
	movq	%rax, %r13
	salq	$4, %r13
.L1446:
	movq	%r13, %rdi
	movsd	%xmm0, 8(%rsp)
	call	_Znwm@PLT
	movsd	8(%rsp), %xmm0
	movq	%rax, %r15
	leaq	(%rax,%r14), %rax
	movq	%rbx, (%rax)
	leaq	16(%r15,%r14), %rbx
	movsd	%xmm0, 8(%rax)
	testq	%r14, %r14
	jg	.L1534
	testq	%rbp, %rbp
	jne	.L1535
.L1449:
	movq	%r15, (%r12)
	addq	%r13, %r15
	movsd	-8(%rbx), %xmm0
	movq	%rbx, 8(%r12)
	movq	%r15, 16(%r12)
	jmp	.L1441
	.p2align 4,,10
	.p2align 3
.L1533:
	movq	%rbp, %rsi
	movq	%r15, %rdx
	movq	%r14, %rdi
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	movq	16(%r12), %rsi
	movq	8(%rsp), %r8
	subq	%rbp, %rsi
	jmp	.L1481
	.p2align 4,,10
	.p2align 3
.L1534:
	movq	%rbp, %rsi
	movq	%r14, %rdx
	movq	%r15, %rdi
	call	memcpy@PLT
	movq	16(%r12), %rsi
	subq	%rbp, %rsi
.L1448:
	movq	%rbp, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1449
	.p2align 4,,10
	.p2align 3
.L1459:
	movq	%rbp, %rcx
	testq	%r15, %r15
	jne	.L1465
	cmpq	$2, %rax
	ja	.L1465
	xorl	%eax, %eax
	jmp	.L1468
.L1535:
	movq	16(%r12), %rsi
	subq	%rbp, %rsi
	jmp	.L1448
.L1532:
	call	__stack_chk_fail@PLT
.L1445:
	movabsq	$9223372036854775792, %r13
	jmp	.L1446
.L1478:
	movabsq	$9223372036854775792, %r13
	jmp	.L1479
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold:
.LFSB15073:
.L1476:
	.cfi_def_cfa_offset 96
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1536
	leaq	.LC4(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
.L1536:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE15073:
	.text
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold
.LCOLDE28:
	.text
.LHOTE28:
	.section	.text.unlikely
.LCOLDB29:
	.text
.LHOTB29:
	.p2align 4
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_:
.LFB15127:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA15127
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	8(%rdx), %rax
	movq	(%rsi), %rbp
	movq	%fs:40, %r15
	movq	%r15, 56(%rsp)
	movq	(%rdi), %r15
	movq	(%rdx), %r12
	movq	%rax, (%rsp)
	movq	(%r15), %rax
	cmpq	$0, 16(%rax)
	je	.L1541
	movq	%rbp, 32(%rsp)
	leaq	32(%rsp), %rsi
	movq	%rax, %rdi
.LEHB79:
	call	*24(%rax)
.LEHE79:
	testb	%al, %al
	je	.L1537
.L1541:
	cmpb	$0, %fs:_ZN12minivectordb7profile6detail6activeE@tpoff
	movq	8(%r15), %rax
	movq	(%rax), %r14
	movq	8(%rax), %rbx
	je	.L1658
	movq	%fs:0, %rax
	leaq	168+_ZN12minivectordb7profile6detail8countersE@tpoff(%rax), %rsi
	movq	%rsi, 32(%rsp)
	movq	%rsi, 24(%rsp)
	call	__errno_location@PLT
	movl	(%rax), %edi
	movq	%rax, 16(%rsp)
	movl	%edi, 8(%rsp)
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	%rax, 40(%rsp)
	movq	%rax, %r13
	addq	$1, %fs:168+_ZN12minivectordb7profile6detail8countersE@tpoff
	movl	8(%rsp), %edi
	movq	16(%rsp), %rdx
	movq	(%rsp), %rax
	movl	%edi, (%rdx)
	cmpq	%rbx, %rax
	jne	.L1543
	movq	24(%rsp), %rsi
	pxor	%xmm0, %xmm0
	testq	%rax, %rax
	je	.L1546
.L1544:
	pxor	%xmm0, %xmm0
	xorl	%edx, %edx
	.p2align 6
	.p2align 4
	.p2align 3
.L1548:
	pxor	%xmm1, %xmm1
	pxor	%xmm2, %xmm2
	cvtss2sd	(%r14,%rdx,4), %xmm1
	cvtss2sd	(%r12,%rdx,4), %xmm2
	subsd	%xmm2, %xmm1
	addq	$1, %rdx
	mulsd	%xmm1, %xmm1
	addsd	%xmm1, %xmm0
	cmpq	%rbx, %rdx
	jb	.L1548
	testq	%rsi, %rsi
	je	.L1549
.L1546:
	movq	%rsi, 8(%rsp)
	movsd	%xmm0, (%rsp)
	call	__errno_location@PLT
	movl	(%rax), %r12d
	movq	%rax, %rbx
	call	_ZNSt6chrono3_V212steady_clock3nowEv@PLT
	movq	8(%rsp), %rsi
	movsd	(%rsp), %xmm0
	subq	%r13, %rax
	addq	%rax, 16(%rsi)
	movl	%r12d, (%rbx)
.L1549:
	pxor	%xmm1, %xmm1
	ucomisd	%xmm0, %xmm1
	ja	.L1643
	sqrtsd	%xmm0, %xmm0
.L1545:
	movq	16(%r15), %r12
	movq	24(%r15), %rax
	movq	8(%r12), %rsi
	movq	(%r12), %rbx
	movq	%rsi, %r13
	subq	%rbx, %r13
	movq	%r13, %r8
	sarq	$4, %r8
	movq	%r8, %rdx
	cmpq	(%rax), %r8
	jb	.L1552
	movsd	8(%rbx), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L1572
	ucomisd	%xmm0, %xmm1
	jp	.L1537
	jne	.L1537
	cmpq	(%rbx), %rbp
	jge	.L1537
.L1572:
	leaq	-16(%rsi), %r10
	cmpq	$16, %r13
	jg	.L1659
.L1575:
	movq	%r10, 8(%r12)
	cmpq	%r10, 16(%r12)
	je	.L1591
	movq	%rbp, -16(%rsi)
	movsd	%xmm0, -8(%rsi)
	movq	%rsi, 8(%r12)
.L1592:
	leaq	-1(%r8), %rdx
	subq	$2, %r8
	movq	%r8, %rcx
	movq	%rdx, %rax
	shrq	$63, %rcx
	salq	$4, %rax
	addq	%r8, %rcx
	addq	%rbx, %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L1600
.L1599:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbx, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L1601
	ucomisd	%xmm0, %xmm1
	jp	.L1657
	jne	.L1657
	cmpq	%rbp, (%rax)
	jge	.L1657
.L1601:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rbx,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1600
	movq	%rsi, %rcx
	jmp	.L1599
	.p2align 4,,10
	.p2align 3
.L1657:
	salq	$4, %rdx
	leaq	(%rbx,%rdx), %rax
.L1600:
	movq	%rbp, (%rax)
	movsd	%xmm0, 8(%rax)
.L1537:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1660
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1658:
	.cfi_restore_state
	movq	$0, 32(%rsp)
	movq	(%rsp), %rax
	xorl	%r13d, %r13d
	cmpq	%rbx, %rax
	jne	.L1543
	xorl	%esi, %esi
	pxor	%xmm0, %xmm0
	testq	%rax, %rax
	jne	.L1544
	jmp	.L1545
.L1643:
	call	sqrt@PLT
	movq	16(%r15), %r12
	movq	24(%r15), %rax
	movq	8(%r12), %rsi
	movq	(%r12), %rbx
	movq	%rsi, %r13
	subq	%rbx, %r13
	movq	%r13, %rdx
	sarq	$4, %rdx
	cmpq	(%rax), %rdx
	jnb	.L1537
	.p2align 4
	.p2align 3
.L1552:
	cmpq	%rsi, 16(%r12)
	je	.L1557
	leaq	16(%rsi), %r14
	movq	%rbp, (%rsi)
	movsd	%xmm0, 8(%rsi)
	movq	%r14, 8(%r12)
.L1558:
	movq	%r14, %rsi
	subq	%rbx, %rsi
	movq	%rsi, %rax
	sarq	$4, %rax
	leaq	-1(%rax), %rdx
	subq	$2, %rax
	movq	%rax, %rcx
	shrq	$63, %rcx
	addq	%rax, %rcx
	leaq	-16(%rbx,%rsi), %rax
	sarq	%rcx
	testq	%rdx, %rdx
	jle	.L1600
.L1567:
	movq	%rcx, %rax
	salq	$4, %rax
	addq	%rbx, %rax
	movsd	8(%rax), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L1569
	ucomisd	%xmm0, %xmm1
	jp	.L1657
	jne	.L1657
	cmpq	%rbp, (%rax)
	jge	.L1657
.L1569:
	movdqu	(%rax), %xmm1
	leaq	-1(%rcx), %rsi
	salq	$4, %rdx
	movups	%xmm1, (%rbx,%rdx)
	movq	%rsi, %rdx
	shrq	$63, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	sarq	%rsi
	testq	%rcx, %rcx
	je	.L1600
	movq	%rsi, %rcx
	jmp	.L1567
	.p2align 4,,10
	.p2align 3
.L1659:
	movq	%r10, %rdx
	movdqu	(%rbx), %xmm1
	movq	-16(%rsi), %r14
	subq	%rbx, %rdx
	movsd	-8(%rsi), %xmm2
	movq	%rdx, %r13
	movups	%xmm1, -16(%rsi)
	sarq	$4, %r13
	leaq	-1(%r13), %rax
	movq	%r13, %r15
	movq	%rax, %r11
	andl	$1, %r15d
	shrq	$63, %r11
	addq	%rax, %r11
	sarq	%r11
	cmpq	$32, %rdx
	jle	.L1576
	movq	%rsi, (%rsp)
	xorl	%edi, %edi
	jmp	.L1579
	.p2align 4,,10
	.p2align 3
.L1610:
	movq	%rax, %rdi
.L1579:
	leaq	1(%rdi), %rdx
	leaq	(%rdx,%rdx), %r9
	salq	$5, %rdx
	leaq	-1(%r9), %rax
	addq	%rbx, %rdx
	movq	%rax, %rcx
	movsd	8(%rdx), %xmm1
	salq	$4, %rcx
	addq	%rbx, %rcx
	movsd	8(%rcx), %xmm3
	comisd	%xmm1, %xmm3
	ja	.L1577
	ucomisd	%xmm1, %xmm3
	jp	.L1609
	jne	.L1609
	movq	(%rdx), %rsi
	cmpq	%rsi, (%rcx)
	jg	.L1577
.L1609:
	movq	%rdx, %rcx
	movq	%r9, %rax
.L1577:
	movdqu	(%rcx), %xmm1
	salq	$4, %rdi
	movups	%xmm1, (%rbx,%rdi)
	cmpq	%rax, %r11
	jg	.L1610
	movq	(%rsp), %rsi
	testq	%r15, %r15
	je	.L1583
.L1655:
	leaq	-1(%rax), %rdi
	movq	%rdi, %rdx
	shrq	$63, %rdx
	addq	%rdi, %rdx
	sarq	%rdx
	testq	%rax, %rax
	je	.L1582
.L1587:
	movq	%rdx, %rcx
	salq	$4, %rcx
	addq	%rbx, %rcx
	movsd	8(%rcx), %xmm1
	comisd	%xmm1, %xmm2
	ja	.L1588
	ucomisd	%xmm2, %xmm1
	jp	.L1656
	jne	.L1656
	cmpq	(%rcx), %r14
	jle	.L1656
.L1588:
	movdqu	(%rcx), %xmm1
	leaq	-1(%rdx), %rdi
	salq	$4, %rax
	movups	%xmm1, (%rbx,%rax)
	movq	%rdi, %rax
	shrq	$63, %rax
	addq	%rdi, %rax
	sarq	%rax
	movq	%rax, %rdi
	movq	%rdx, %rax
	testq	%rdx, %rdx
	je	.L1582
	movq	%rdi, %rdx
	jmp	.L1587
	.p2align 4,,10
	.p2align 3
.L1656:
	salq	$4, %rax
	leaq	(%rbx,%rax), %rcx
.L1582:
	movq	%r14, (%rcx)
	movsd	%xmm2, 8(%rcx)
	jmp	.L1575
.L1591:
	movabsq	$576460752303423487, %rdx
	subq	%rbx, %r10
	movq	%r10, %rax
	movq	%r10, %r15
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1593
	testq	%rax, %rax
	movl	$1, %edx
	cmovne	%rax, %rdx
	addq	%rdx, %rax
	jc	.L1595
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r13
	salq	$4, %r13
.L1596:
	movq	%r13, %rdi
	movsd	%xmm0, (%rsp)
.LEHB80:
	call	_Znwm@PLT
	movsd	(%rsp), %xmm0
	leaq	16(%r15), %r8
	movq	%rax, %r14
	leaq	(%rax,%r15), %rax
	movq	%rbp, (%rax)
	leaq	(%r14,%r8), %rcx
	movsd	%xmm0, 8(%rax)
	testq	%r15, %r15
	jg	.L1661
	movq	16(%r12), %rsi
	subq	%rbx, %rsi
.L1598:
	movq	%rbx, %rdi
	movq	%rcx, 8(%rsp)
	addq	%r14, %r13
	movq	%r14, %rbx
	movq	%r8, (%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %rcx
	movq	(%rsp), %r8
	movq	%r14, (%r12)
	movq	%r13, 16(%r12)
	movq	%rcx, 8(%r12)
	movq	-16(%rcx), %rbp
	sarq	$4, %r8
	movsd	-8(%rcx), %xmm0
	jmp	.L1592
.L1583:
	subq	$2, %r13
	sarq	%r13
	cmpq	%rax, %r13
	jne	.L1655
.L1585:
	leaq	1(%rax,%rax), %rdi
	movq	%rdi, %rdx
	salq	$4, %rdx
	movdqu	(%rbx,%rdx), %xmm1
	movq	%rax, %rdx
	movq	%rdi, %rax
	movups	%xmm1, (%rcx)
	jmp	.L1587
.L1557:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rdx
	je	.L1593
	testq	%rdx, %rdx
	movl	$1, %eax
	cmovne	%rdx, %rax
	addq	%rdx, %rax
	jc	.L1562
	movabsq	$576460752303423487, %rdx
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdx
	movq	%rdx, %r15
	salq	$4, %r15
.L1563:
	movq	%r15, %rdi
	movsd	%xmm0, (%rsp)
	call	_Znwm@PLT
.LEHE80:
	movsd	(%rsp), %xmm0
	movq	%rax, %rcx
	leaq	(%rax,%r13), %rax
	movq	%rbp, (%rax)
	leaq	16(%rcx,%r13), %r14
	movsd	%xmm0, 8(%rax)
	testq	%r13, %r13
	jg	.L1662
	testq	%rbx, %rbx
	jne	.L1663
.L1566:
	addq	%rcx, %r15
	movq	%rcx, (%r12)
	movq	-16(%r14), %rbp
	movq	%rcx, %rbx
	movq	%r14, 8(%r12)
	movsd	-8(%r14), %xmm0
	movq	%r15, 16(%r12)
	jmp	.L1558
.L1661:
	movq	%rbx, %rsi
	movq	%r15, %rdx
	movq	%r14, %rdi
	movq	%rcx, 8(%rsp)
	movq	%r8, (%rsp)
	call	memcpy@PLT
	movq	16(%r12), %rsi
	movq	(%rsp), %r8
	movq	8(%rsp), %rcx
	subq	%rbx, %rsi
	jmp	.L1598
.L1662:
	movq	%rbx, %rsi
	movq	%rcx, %rdi
	movq	%r13, %rdx
	call	memcpy@PLT
	movq	16(%r12), %rsi
	movq	%rax, %rcx
	subq	%rbx, %rsi
.L1565:
	movq	%rbx, %rdi
	movq	%rcx, (%rsp)
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L1566
.L1576:
	movq	%rbx, %rcx
	testq	%r15, %r15
	jne	.L1582
	cmpq	$2, %rax
	ja	.L1582
	xorl	%eax, %eax
	jmp	.L1585
.L1663:
	movq	16(%r12), %rsi
	subq	%rbx, %rsi
	jmp	.L1565
.L1660:
	call	__stack_chk_fail@PLT
.L1562:
	movabsq	$9223372036854775792, %r15
	jmp	.L1563
.L1595:
	movabsq	$9223372036854775792, %r13
	jmp	.L1596
	.section	.gcc_except_table
.LLSDA15127:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE15127-.LLSDACSB15127
.LLSDACSB15127:
	.uleb128 .LEHB79-.LFB15127
	.uleb128 .LEHE79-.LEHB79
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB80-.LFB15127
	.uleb128 .LEHE80-.LEHB80
	.uleb128 0
	.uleb128 0
.LLSDACSE15127:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC15127
	.type	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, @function
_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold:
.LFSB15127:
.L1543:
	.cfi_def_cfa_offset 128
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC11(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbp
.LEHB81:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE81:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1664
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbp, %rdi
.LEHB82:
	call	__cxa_throw@PLT
.LEHE82:
.L1593:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1665
	leaq	.LC4(%rip), %rdi
.LEHB83:
	call	_ZSt20__throw_length_errorPKc@PLT
.L1664:
	call	__stack_chk_fail@PLT
.L1665:
	call	__stack_chk_fail@PLT
.L1614:
	movq	%rbp, %rdi
	movq	%rax, %rbx
	call	__cxa_free_exception@PLT
.L1555:
	leaq	32(%rsp), %rdi
	movq	%r13, 40(%rsp)
	call	_ZN12minivectordb7profile6detail5ScopeD1Ev
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1666
	movq	%rbx, %rdi
	call	_Unwind_Resume@PLT
.LEHE83:
.L1613:
	movq	%rax, %rbx
	jmp	.L1555
.L1666:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE15127:
	.section	.gcc_except_table
.LLSDAC15127:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC15127-.LLSDACSBC15127
.LLSDACSBC15127:
	.uleb128 .LEHB81-.LCOLDB29
	.uleb128 .LEHE81-.LEHB81
	.uleb128 .L1614-.LCOLDB29
	.uleb128 0
	.uleb128 .LEHB82-.LCOLDB29
	.uleb128 .LEHE82-.LEHB82
	.uleb128 .L1613-.LCOLDB29
	.uleb128 0
	.uleb128 .LEHB83-.LCOLDB29
	.uleb128 .LEHE83-.LEHB83
	.uleb128 0
	.uleb128 0
.LLSDACSEC15127:
	.section	.text.unlikely
	.text
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_
	.section	.text.unlikely
	.size	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold, .-_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_.cold
.LCOLDE29:
	.text
.LHOTE29:
	.p2align 4
	.globl	_ZN12minivectordb11l2_distanceESt4spanIKfLm18446744073709551615EES2_
	.type	_ZN12minivectordb11l2_distanceESt4spanIKfLm18446744073709551615EES2_, @function
_ZN12minivectordb11l2_distanceESt4spanIKfLm18446744073709551615EES2_:
.LFB13538:
	.cfi_startproc
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	_ZN12minivectordb12_GLOBAL__N_110squared_l2ILb1EEEdSt4spanIKfLm18446744073709551615EES4_
	pxor	%xmm1, %xmm1
	ucomisd	%xmm0, %xmm1
	ja	.L1676
	sqrtsd	%xmm0, %xmm0
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L1676:
	.cfi_restore_state
	popq	%rax
	.cfi_def_cfa_offset 8
	jmp	sqrt@PLT
	.cfi_endproc
.LFE13538:
	.size	_ZN12minivectordb11l2_distanceESt4spanIKfLm18446744073709551615EES2_, .-_ZN12minivectordb11l2_distanceESt4spanIKfLm18446744073709551615EES2_
	.section	.text.unlikely
.LCOLDB31:
	.text
.LHOTB31:
	.p2align 4
	.globl	_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE
	.type	_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE, @function
_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE:
.LFB13539:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA13539
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%r8, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%fs:40, %r12
	movq	%r12, 120(%rsp)
	movq	%r9, %r12
	movq	%rdx, 40(%rsp)
	movq	40(%rsp), %rdx
	movq	%rsi, 32(%rsp)
	leaq	(%rsi,%rdx,4), %rdx
	movq	%rcx, 24(%rsp)
	cmpq	%rdx, %rsi
	je	.L1678
	movss	.LC1(%rip), %xmm1
	movq	%rsi, %rax
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L1682:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L1751
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L1682
.L1678:
	movq	$0, 64(%rsp)
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	pxor	%xmm0, %xmm0
	testq	%rcx, %rcx
	jne	.L1683
	movq	$0, 16(%rbx)
	movups	%xmm0, (%rbx)
.L1677:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1794
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1683:
	.cfi_restore_state
	movl	$40, %edi
	movaps	%xmm0, 80(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
.LEHB84:
	call	_Znwm@PLT
.LEHE84:
	leaq	32(%rsp), %rdx
	movq	%r12, (%rax)
	movq	.LC30(%rip), %xmm0
	movq	%rdx, 8(%rax)
	leaq	48(%rsp), %rdx
	cmpq	$0, 16(%rbp)
	movq	%rdx, 16(%rax)
	leaq	24(%rsp), %rdx
	movq	%rdx, 24(%rax)
	leaq	23(%rsp), %rdx
	movq	%rdx, 32(%rax)
	movq	%rax, 80(%rsp)
	leaq	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E9_M_invokeERKSt9_Any_dataOlOS2_(%rip), %rax
	movq	%rax, %xmm3
	punpcklqdq	%xmm3, %xmm0
	movaps	%xmm0, 96(%rsp)
	je	.L1795
	leaq	80(%rsp), %r12
	movq	%rbp, %rdi
	movq	%r12, %rsi
.LEHB85:
	call	*24(%rbp)
.LEHE85:
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1691
	movl	$3, %edx
	movq	%r12, %rsi
	movq	%r12, %rdi
	call	*%rax
.L1691:
	movq	56(%rsp), %rdi
	movq	48(%rsp), %rdx
	movabsq	$9223372036854775792, %rax
	movq	%rdi, %rbp
	subq	%rdx, %rbp
	cmpq	%rbp, %rax
	jb	.L1784
	testq	%rbp, %rbp
	jne	.L1694
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
	cmpq	%rdx, %rdi
	je	.L1696
.L1695:
	movq	%r13, %r12
	jmp	.L1726
	.p2align 4,,10
	.p2align 3
.L1700:
	movq	%r10, 56(%rsp)
	movq	%r8, %xmm0
	cmpq	%r13, %rbp
	je	.L1716
.L1798:
	movq	48(%rsp), %rdx
	movq	%r10, %rdi
	movq	%r14, 0(%r13)
	addq	$16, %r13
	movq	%r8, -8(%r13)
	cmpq	%rdi, %rdx
	je	.L1796
.L1726:
	movq	%rdi, %rax
	movq	(%rdx), %r14
	movq	8(%rdx), %r8
	leaq	-16(%rdi), %r10
	subq	%rdx, %rax
	cmpq	$16, %rax
	jle	.L1700
	movq	%r10, %rsi
	movdqu	(%rdx), %xmm0
	movq	-16(%rdi), %r15
	subq	%rdx, %rsi
	movsd	-8(%rdi), %xmm1
	movq	%rsi, %r11
	movups	%xmm0, -16(%rdi)
	sarq	$4, %r11
	leaq	-1(%r11), %rcx
	movq	%r11, %rax
	movq	%rcx, %r9
	andl	$1, %eax
	shrq	$63, %r9
	addq	%rcx, %r9
	sarq	%r9
	cmpq	$32, %rsi
	jle	.L1701
	movq	%r14, 8(%rsp)
	xorl	%edi, %edi
	movq	%r11, %r14
	movq	%r8, %xmm4
	movq	%r10, %r11
	movq	%r12, (%rsp)
	movq	%rax, %r10
	movq	%r9, %rax
	jmp	.L1704
	.p2align 4,,10
	.p2align 3
.L1741:
	movq	%rcx, %rdi
.L1704:
	leaq	1(%rdi), %r12
	leaq	(%r12,%r12), %r9
	salq	$5, %r12
	leaq	-1(%r9), %rcx
	addq	%rdx, %r12
	movq	%rcx, %rsi
	movsd	8(%r12), %xmm0
	salq	$4, %rsi
	addq	%rdx, %rsi
	movsd	8(%rsi), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L1702
	ucomisd	%xmm0, %xmm2
	jp	.L1740
	jne	.L1740
	movq	(%r12), %r8
	cmpq	%r8, (%rsi)
	jg	.L1702
.L1740:
	movq	%r12, %rsi
	movq	%r9, %rcx
.L1702:
	movdqu	(%rsi), %xmm0
	salq	$4, %rdi
	movups	%xmm0, (%rdx,%rdi)
	cmpq	%rax, %rcx
	jl	.L1741
	movq	%r10, %rax
	movq	(%rsp), %r12
	movq	%r11, %r10
	movq	%xmm4, %r8
	movq	%r14, %r11
	movq	8(%rsp), %r14
	testq	%rax, %rax
	jne	.L1792
	subq	$2, %r11
	sarq	%r11
	cmpq	%rcx, %r11
	je	.L1710
.L1792:
	leaq	-1(%rcx), %rax
	movq	%rax, %rdi
	shrq	$63, %rdi
	addq	%rax, %rdi
	sarq	%rdi
	testq	%rcx, %rcx
	je	.L1797
.L1712:
	movq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movsd	8(%rax), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L1713
	ucomisd	%xmm0, %xmm1
	jp	.L1793
	jne	.L1793
	cmpq	(%rax), %r15
	jg	.L1713
.L1793:
	salq	$4, %rcx
	addq	%rcx, %rdx
.L1707:
	movq	%r15, (%rdx)
	movq	%r8, %xmm0
	movsd	%xmm1, 8(%rdx)
	movq	%r10, 56(%rsp)
	cmpq	%r13, %rbp
	jne	.L1798
.L1716:
	movabsq	$576460752303423487, %rax
	movq	%rbp, %rcx
	subq	%r12, %rcx
	movq	%rcx, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L1785
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L1721
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L1722:
	movq	%r15, %rdi
	movq	%rcx, 8(%rsp)
	movsd	%xmm0, (%rsp)
.LEHB86:
	call	_Znwm@PLT
.LEHE86:
	movq	8(%rsp), %rcx
	movsd	(%rsp), %xmm0
	movq	%rax, %r8
	leaq	(%rax,%rcx), %rax
	leaq	16(%r8,%rcx), %r13
	movq	%r14, (%rax)
	movsd	%xmm0, 8(%rax)
	testq	%rcx, %rcx
	jg	.L1799
	testq	%r12, %r12
	jne	.L1724
.L1725:
	movq	56(%rsp), %rdi
	movq	48(%rsp), %rdx
	leaq	(%r8,%r15), %rbp
	movq	%r8, %r12
	cmpq	%rdi, %rdx
	jne	.L1726
	.p2align 4
	.p2align 3
.L1796:
	cmpq	%r13, %r12
	je	.L1696
	leaq	-16(%r13), %rax
	cmpq	%rax, %r12
	jnb	.L1696
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L1729:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L1729
.L1696:
	movq	64(%rsp), %rsi
	movq	%r12, (%rbx)
	movq	%r13, 8(%rbx)
	movq	%rbp, 16(%rbx)
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1677
	call	_ZdlPvm@PLT
	jmp	.L1677
	.p2align 4,,10
	.p2align 3
.L1713:
	movdqu	(%rax), %xmm0
	leaq	-1(%rdi), %rsi
	salq	$4, %rcx
	movups	%xmm0, (%rdx,%rcx)
	movq	%rsi, %rcx
	shrq	$63, %rcx
	addq	%rsi, %rcx
	sarq	%rcx
	movq	%rcx, %rsi
	movq	%rdi, %rcx
	testq	%rdi, %rdi
	je	.L1744
	movq	%rsi, %rdi
	jmp	.L1712
	.p2align 4,,10
	.p2align 3
.L1799:
	movq	%r8, %rdi
	movq	%rcx, %rdx
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %r8
.L1724:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%r8, (%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %r8
	jmp	.L1725
	.p2align 4,,10
	.p2align 3
.L1701:
	testq	%rax, %rax
	jne	.L1707
	cmpq	$2, %rcx
	ja	.L1707
	xorl	%ecx, %ecx
	movq	%rdx, %rsi
	.p2align 4
	.p2align 3
.L1710:
	leaq	1(%rcx,%rcx), %rax
	movq	%rax, %rdi
	salq	$4, %rdi
	movdqu	(%rdx,%rdi), %xmm0
	movq	%rcx, %rdi
	movq	%rax, %rcx
	movups	%xmm0, (%rsi)
	jmp	.L1712
	.p2align 4,,10
	.p2align 3
.L1694:
	movq	%rbp, %rdi
.LEHB87:
	call	_Znwm@PLT
.LEHE87:
	movq	56(%rsp), %rdi
	movq	48(%rsp), %rdx
	movq	%rax, %r13
	addq	%rax, %rbp
	cmpq	%rdi, %rdx
	jne	.L1695
	movq	%rax, %r12
	jmp	.L1696
.L1744:
	movq	%rax, %rdx
	jmp	.L1707
.L1797:
	movq	%rsi, %rdx
	jmp	.L1707
.L1794:
	call	__stack_chk_fail@PLT
.L1721:
	movabsq	$9223372036854775792, %r15
	jmp	.L1722
.L1782:
	jmp	.L1783
.L1780:
	jmp	.L1781
.L1778:
	jmp	.L1779
.L1749:
	movq	%rax, %rbx
	jmp	.L1687
.L1795:
	jmp	.L1685
	.section	.gcc_except_table
.LLSDA13539:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE13539-.LLSDACSB13539
.LLSDACSB13539:
	.uleb128 .LEHB84-.LFB13539
	.uleb128 .LEHE84-.LEHB84
	.uleb128 .L1749-.LFB13539
	.uleb128 0
	.uleb128 .LEHB85-.LFB13539
	.uleb128 .LEHE85-.LEHB85
	.uleb128 .L1780-.LFB13539
	.uleb128 0
	.uleb128 .LEHB86-.LFB13539
	.uleb128 .LEHE86-.LEHB86
	.uleb128 .L1778-.LFB13539
	.uleb128 0
	.uleb128 .LEHB87-.LFB13539
	.uleb128 .LEHE87-.LEHB87
	.uleb128 .L1782-.LFB13539
	.uleb128 0
.LLSDACSE13539:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC13539
	.type	_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE.cold, @function
_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE.cold:
.LFSB13539:
	nop
.L1750:
	.cfi_def_cfa_offset 192
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
.L1783:
	movq	%rax, %rbx
.L1689:
	movq	48(%rsp), %rdi
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1735
	call	_ZdlPvm@PLT
.L1735:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1800
	movq	%rbx, %rdi
.LEHB88:
	call	_Unwind_Resume@PLT
.LEHE88:
.L1747:
.L1781:
	movq	%rax, %rbx
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1689
	leaq	80(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L1689
.L1800:
	call	__stack_chk_fail@PLT
.L1784:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1801
	leaq	.LC3(%rip), %rdi
.LEHB89:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE89:
.L1801:
	call	__stack_chk_fail@PLT
.L1746:
.L1779:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L1689
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1689
.L1785:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1802
	leaq	.LC4(%rip), %rdi
.LEHB90:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE90:
.L1802:
	call	__stack_chk_fail@PLT
.L1751:
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB91:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE91:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1803
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB92:
	call	__cxa_throw@PLT
.LEHE92:
.L1685:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1804
.LEHB93:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE93:
.L1803:
	call	__stack_chk_fail@PLT
.L1804:
	call	__stack_chk_fail@PLT
.L1687:
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1689
	leaq	80(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L1689
.L1748:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1805
	movq	%rbp, %rdi
.LEHB94:
	call	_Unwind_Resume@PLT
.LEHE94:
.L1805:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13539:
	.section	.gcc_except_table
.LLSDAC13539:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC13539-.LLSDACSBC13539
.LLSDACSBC13539:
	.uleb128 .LEHB88-.LCOLDB31
	.uleb128 .LEHE88-.LEHB88
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB89-.LCOLDB31
	.uleb128 .LEHE89-.LEHB89
	.uleb128 .L1750-.LCOLDB31
	.uleb128 0
	.uleb128 .LEHB90-.LCOLDB31
	.uleb128 .LEHE90-.LEHB90
	.uleb128 .L1746-.LCOLDB31
	.uleb128 0
	.uleb128 .LEHB91-.LCOLDB31
	.uleb128 .LEHE91-.LEHB91
	.uleb128 .L1748-.LCOLDB31
	.uleb128 0
	.uleb128 .LEHB92-.LCOLDB31
	.uleb128 .LEHE92-.LEHB92
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB93-.LCOLDB31
	.uleb128 .LEHE93-.LEHB93
	.uleb128 .L1747-.LCOLDB31
	.uleb128 0
	.uleb128 .LEHB94-.LCOLDB31
	.uleb128 .LEHE94-.LEHB94
	.uleb128 0
	.uleb128 0
.LLSDACSEC13539:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE, .-_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE
	.section	.text.unlikely
	.size	_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE.cold, .-_ZN12minivectordb11exact_top_kESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS3_IFvlS2_EEEERKS3_IFblEE.cold
.LCOLDE31:
	.text
.LHOTE31:
	.p2align 4
	.globl	_ZN12minivectordb6detail8has_avx2Ev
	.type	_ZN12minivectordb6detail8has_avx2Ev, @function
_ZN12minivectordb6detail8has_avx2Ev:
.LFB13540:
	.cfi_startproc
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movzbl	13(%rax), %eax
	shrb	$2, %al
	andl	$1, %eax
	ret
	.cfi_endproc
.LFE13540:
	.size	_ZN12minivectordb6detail8has_avx2Ev, .-_ZN12minivectordb6detail8has_avx2Ev
	.p2align 4
	.globl	_ZN12minivectordb6detail10has_avx512Ev
	.type	_ZN12minivectordb6detail10has_avx512Ev, @function
_ZN12minivectordb6detail10has_avx512Ev:
.LFB13541:
	.cfi_startproc
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movl	12(%rax), %eax
	notl	%eax
	testb	$-124, %ah
	sete	%al
	ret
	.cfi_endproc
.LFE13541:
	.size	_ZN12minivectordb6detail10has_avx512Ev, .-_ZN12minivectordb6detail10has_avx512Ev
	.section	.text.unlikely
.LCOLDB33:
	.text
.LHOTB33:
	.p2align 4
	.globl	_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb
	.type	_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb, @function
_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb:
.LFB13542:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA13542
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%r8, %rbx
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%rcx, 8(%rsp)
	movl	%r9d, %ecx
	movq	%rsi, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%fs:40, %rdx
	movq	%rdx, 120(%rsp)
	movq	24(%rsp), %rdx
	leaq	(%rsi,%rdx,4), %rdx
	cmpq	%rdx, %rsi
	je	.L1809
	movss	.LC1(%rip), %xmm1
	movq	%rsi, %rax
	movss	.LC0(%rip), %xmm2
	.p2align 5
	.p2align 4
	.p2align 3
.L1813:
	movss	(%rax), %xmm0
	andps	%xmm2, %xmm0
	ucomiss	%xmm0, %xmm1
	jb	.L1880
	addq	$4, %rax
	cmpq	%rax, %rdx
	jne	.L1813
.L1809:
	cmpq	$0, 8(%rsp)
	jne	.L1814
	movq	$0, 16(%r13)
	pxor	%xmm0, %xmm0
	movups	%xmm0, 0(%r13)
.L1808:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1930
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r13, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1814:
	.cfi_restore_state
	movq	$0, 64(%rsp)
	pxor	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	testb	%r9b, %r9b
	jne	.L1931
.L1816:
	pxor	%xmm0, %xmm0
	movl	$40, %edi
	movb	%cl, 47(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movaps	%xmm0, 80(%rsp)
.LEHB95:
	call	_Znwm@PLT
.LEHE95:
	leaq	16(%rsp), %rdi
	leaq	47(%rsp), %rdx
	movq	%rax, 80(%rsp)
	cmpq	$0, 16(%rbx)
	movq	%rdi, %xmm0
	movq	%rdx, %xmm3
	leaq	48(%rsp), %rdi
	punpcklqdq	%xmm3, %xmm0
	leaq	8(%rsp), %rdx
	movups	%xmm0, (%rax)
	movq	%rdx, %xmm4
	movq	%rdi, %xmm0
	leaq	46(%rsp), %rdx
	punpcklqdq	%xmm4, %xmm0
	movq	%rdx, 32(%rax)
	movups	%xmm0, 16(%rax)
	leaq	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E9_M_invokeERKSt9_Any_dataOS2_OS4_Ot(%rip), %rax
	movq	.LC32(%rip), %xmm0
	movq	%rax, %xmm5
	punpcklqdq	%xmm5, %xmm0
	movaps	%xmm0, 96(%rsp)
	je	.L1932
	leaq	80(%rsp), %rbp
	movq	%rbx, %rdi
	movq	%rbp, %rsi
.LEHB96:
	call	*24(%rbx)
.LEHE96:
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1823
	movl	$3, %edx
	movq	%rbp, %rsi
	movq	%rbp, %rdi
	call	*%rax
.L1823:
	movq	56(%rsp), %rax
	movq	48(%rsp), %rbx
	movabsq	$9223372036854775792, %rdx
	movq	%rax, %rbp
	subq	%rbx, %rbp
	cmpq	%rbp, %rdx
	jb	.L1919
	testq	%rbp, %rbp
	jne	.L1826
	xorl	%r14d, %r14d
	cmpq	%rbx, %rax
	je	.L1933
.L1827:
	movq	%r14, %r12
	jmp	.L1855
	.p2align 4,,10
	.p2align 3
.L1839:
	movq	%r9, 56(%rsp)
	cmpq	%r9, %rbx
	je	.L1934
.L1855:
	cmpq	%rbp, %r14
	je	.L1829
	movdqu	(%rbx), %xmm0
	addq	$16, %r14
	movups	%xmm0, -16(%r14)
.L1830:
	movq	56(%rsp), %rax
	movq	48(%rsp), %rbx
	movq	%rax, %rdx
	leaq	-16(%rax), %r9
	subq	%rbx, %rdx
	cmpq	$16, %rdx
	jle	.L1839
	movq	%r9, %rdx
	movdqu	(%rbx), %xmm0
	movq	-16(%rax), %r11
	subq	%rbx, %rdx
	movsd	-8(%rax), %xmm1
	movq	%rdx, %r10
	movups	%xmm0, -16(%rax)
	sarq	$4, %r10
	leaq	-1(%r10), %rax
	movq	%r10, %r15
	movq	%rax, %r8
	andl	$1, %r15d
	shrq	$63, %r8
	addq	%rax, %r8
	sarq	%r8
	cmpq	$32, %rdx
	jle	.L1840
	movq	%r9, (%rsp)
	xorl	%esi, %esi
	jmp	.L1843
	.p2align 4,,10
	.p2align 3
.L1873:
	movq	%rcx, %rsi
.L1843:
	leaq	1(%rsi), %rax
	leaq	(%rax,%rax), %rdi
	salq	$5, %rax
	leaq	-1(%rdi), %rcx
	addq	%rbx, %rax
	movq	%rcx, %rdx
	movsd	8(%rax), %xmm0
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L1841
	ucomisd	%xmm0, %xmm2
	jp	.L1872
	jne	.L1872
	movq	(%rax), %r9
	cmpq	%r9, (%rdx)
	jg	.L1841
.L1872:
	movq	%rax, %rdx
	movq	%rdi, %rcx
.L1841:
	movdqu	(%rdx), %xmm0
	salq	$4, %rsi
	movups	%xmm0, (%rbx,%rsi)
	cmpq	%rcx, %r8
	jg	.L1873
	movq	(%rsp), %r9
	testq	%r15, %r15
	jne	.L1928
	subq	$2, %r10
	sarq	%r10
	cmpq	%r10, %rcx
	je	.L1849
.L1928:
	leaq	-1(%rcx), %rsi
	movq	%rsi, %rax
	shrq	$63, %rax
	addq	%rsi, %rax
	sarq	%rax
	testq	%rcx, %rcx
	je	.L1846
.L1851:
	movq	%rax, %rdx
	salq	$4, %rdx
	addq	%rbx, %rdx
	movsd	8(%rdx), %xmm0
	comisd	%xmm0, %xmm1
	ja	.L1852
	ucomisd	%xmm1, %xmm0
	jp	.L1929
	jne	.L1929
	cmpq	(%rdx), %r11
	jg	.L1852
.L1929:
	salq	$4, %rcx
	leaq	(%rbx,%rcx), %rdx
.L1846:
	movq	%r11, (%rdx)
	movsd	%xmm1, 8(%rdx)
	movq	%r9, 56(%rsp)
	cmpq	%r9, %rbx
	jne	.L1855
.L1934:
	cmpq	%r14, %r12
	je	.L1858
	leaq	-16(%r14), %rax
	cmpq	%rax, %r12
	jnb	.L1858
	movq	%r12, %rdx
	.p2align 6
	.p2align 4
	.p2align 3
.L1859:
	movq	(%rdx), %rcx
	movsd	8(%rdx), %xmm0
	subq	$16, %rax
	addq	$16, %rdx
	movdqu	16(%rax), %xmm1
	movups	%xmm1, -16(%rdx)
	movq	%rcx, 16(%rax)
	movsd	%xmm0, 24(%rax)
	cmpq	%rax, %rdx
	jb	.L1859
.L1858:
	movq	%r12, 0(%r13)
	movq	%r14, 8(%r13)
	movq	%rbp, 16(%r13)
.L1857:
	movq	64(%rsp), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	call	_ZdlPvm@PLT
	jmp	.L1808
	.p2align 4,,10
	.p2align 3
.L1852:
	movdqu	(%rdx), %xmm0
	leaq	-1(%rax), %rsi
	salq	$4, %rcx
	movups	%xmm0, (%rbx,%rcx)
	movq	%rsi, %rcx
	shrq	$63, %rcx
	addq	%rsi, %rcx
	movq	%rcx, %rsi
	movq	%rax, %rcx
	sarq	%rsi
	testq	%rax, %rax
	je	.L1846
	movq	%rsi, %rax
	jmp	.L1851
	.p2align 4,,10
	.p2align 3
.L1829:
	movabsq	$576460752303423487, %rax
	movq	%r14, %rsi
	subq	%r12, %rsi
	movq	%rsi, %r15
	sarq	$4, %r15
	cmpq	%rax, %r15
	je	.L1920
	testq	%r15, %r15
	movl	$1, %eax
	cmovne	%r15, %rax
	addq	%rax, %r15
	jc	.L1834
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r15
	cmova	%rax, %r15
	salq	$4, %r15
.L1835:
	movq	%r15, %rdi
	movq	%rsi, (%rsp)
.LEHB97:
	call	_Znwm@PLT
.LEHE97:
	movq	(%rsp), %rsi
	movdqu	(%rbx), %xmm0
	movq	%rax, %rcx
	movups	%xmm0, (%rax,%rsi)
	leaq	16(%rax,%rsi), %r14
	testq	%rsi, %rsi
	jg	.L1935
	testq	%r12, %r12
	jne	.L1837
.L1838:
	leaq	(%rcx,%r15), %rbp
	movq	%rcx, %r12
	jmp	.L1830
	.p2align 4,,10
	.p2align 3
.L1935:
	movq	%rsi, %rdx
	movq	%rax, %rdi
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	%rax, %rcx
.L1837:
	movq	%rbp, %rsi
	movq	%r12, %rdi
	movq	%rcx, (%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L1838
	.p2align 4,,10
	.p2align 3
.L1931:
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movl	12(%rax), %eax
	notl	%eax
	testb	$-124, %ah
	sete	%cl
	jmp	.L1816
	.p2align 4,,10
	.p2align 3
.L1840:
	movq	%rbx, %rdx
	testq	%r15, %r15
	jne	.L1846
	cmpq	$2, %rax
	ja	.L1846
	xorl	%ecx, %ecx
	.p2align 4
	.p2align 3
.L1849:
	leaq	1(%rcx,%rcx), %rsi
	movq	%rsi, %rax
	salq	$4, %rax
	movdqu	(%rbx,%rax), %xmm0
	movq	%rcx, %rax
	movq	%rsi, %rcx
	movups	%xmm0, (%rdx)
	jmp	.L1851
	.p2align 4,,10
	.p2align 3
.L1826:
	movq	%rbp, %rdi
.LEHB98:
	call	_Znwm@PLT
.LEHE98:
	movq	48(%rsp), %rbx
	movq	%rax, %r14
	addq	%rax, %rbp
	cmpq	%rbx, 56(%rsp)
	jne	.L1827
.L1828:
	movq	%r14, 0(%r13)
	movq	%rax, 8(%r13)
	movq	%rbp, 16(%r13)
	testq	%rbx, %rbx
	je	.L1808
	jmp	.L1857
	.p2align 4,,10
	.p2align 3
.L1933:
	xorl	%eax, %eax
	jmp	.L1828
.L1834:
	movabsq	$9223372036854775792, %r15
	jmp	.L1835
.L1930:
	call	__stack_chk_fail@PLT
.L1915:
	jmp	.L1916
.L1879:
	movq	%rax, %rbx
	jmp	.L1819
.L1917:
	jmp	.L1918
.L1932:
	jmp	.L1817
.L1913:
	jmp	.L1914
	.section	.gcc_except_table
.LLSDA13542:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE13542-.LLSDACSB13542
.LLSDACSB13542:
	.uleb128 .LEHB95-.LFB13542
	.uleb128 .LEHE95-.LEHB95
	.uleb128 .L1879-.LFB13542
	.uleb128 0
	.uleb128 .LEHB96-.LFB13542
	.uleb128 .LEHE96-.LEHB96
	.uleb128 .L1913-.LFB13542
	.uleb128 0
	.uleb128 .LEHB97-.LFB13542
	.uleb128 .LEHE97-.LEHB97
	.uleb128 .L1917-.LFB13542
	.uleb128 0
	.uleb128 .LEHB98-.LFB13542
	.uleb128 .LEHE98-.LEHB98
	.uleb128 .L1915-.LFB13542
	.uleb128 0
.LLSDACSE13542:
	.text
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC13542
	.type	_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb.cold, @function
_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb.cold:
.LFSB13542:
	nop
.L1877:
	.cfi_def_cfa_offset 192
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
.L1916:
	movq	%rax, %rbx
.L1821:
	movq	48(%rsp), %rdi
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1866
	call	_ZdlPvm@PLT
.L1866:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1936
	movq	%rbx, %rdi
.LEHB99:
	call	_Unwind_Resume@PLT
.LEHE99:
.L1819:
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1821
	leaq	80(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L1821
.L1936:
	call	__stack_chk_fail@PLT
.L1920:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1937
	leaq	.LC4(%rip), %rdi
.LEHB100:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE100:
.L1878:
.L1918:
	movq	%rbp, %rsi
	movq	%rax, %rbx
	subq	%r12, %rsi
	testq	%r12, %r12
	je	.L1821
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1821
.L1937:
	call	__stack_chk_fail@PLT
.L1817:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1938
.LEHB101:
	call	_ZSt25__throw_bad_function_callv@PLT
.LEHE101:
.L1876:
.L1914:
	movq	%rax, %rbx
	movq	96(%rsp), %rax
	testq	%rax, %rax
	je	.L1821
	leaq	80(%rsp), %rdi
	movl	$3, %edx
	movq	%rdi, %rsi
	call	*%rax
	jmp	.L1821
.L1938:
	call	__stack_chk_fail@PLT
.L1919:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1939
	leaq	.LC3(%rip), %rdi
.LEHB102:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE102:
.L1880:
	movl	$16, %edi
	call	__cxa_allocate_exception@PLT
	leaq	.LC2(%rip), %rsi
	movq	%rax, %rdi
	movq	%rax, %rbx
.LEHB103:
	call	_ZNSt16invalid_argumentC1EPKc@PLT
.LEHE103:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1940
	movq	_ZNSt16invalid_argumentD1Ev@GOTPCREL(%rip), %rdx
	leaq	_ZTISt16invalid_argument(%rip), %rsi
	movq	%rbx, %rdi
.LEHB104:
	call	__cxa_throw@PLT
.L1939:
	call	__stack_chk_fail@PLT
.L1940:
	call	__stack_chk_fail@PLT
.L1875:
	movq	%rbx, %rdi
	movq	%rax, %rbp
	call	__cxa_free_exception@PLT
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1941
	movq	%rbp, %rdi
	call	_Unwind_Resume@PLT
.LEHE104:
.L1941:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13542:
	.section	.gcc_except_table
.LLSDAC13542:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC13542-.LLSDACSBC13542
.LLSDACSBC13542:
	.uleb128 .LEHB99-.LCOLDB33
	.uleb128 .LEHE99-.LEHB99
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB100-.LCOLDB33
	.uleb128 .LEHE100-.LEHB100
	.uleb128 .L1878-.LCOLDB33
	.uleb128 0
	.uleb128 .LEHB101-.LCOLDB33
	.uleb128 .LEHE101-.LEHB101
	.uleb128 .L1876-.LCOLDB33
	.uleb128 0
	.uleb128 .LEHB102-.LCOLDB33
	.uleb128 .LEHE102-.LEHB102
	.uleb128 .L1877-.LCOLDB33
	.uleb128 0
	.uleb128 .LEHB103-.LCOLDB33
	.uleb128 .LEHE103-.LEHB103
	.uleb128 .L1875-.LCOLDB33
	.uleb128 0
	.uleb128 .LEHB104-.LCOLDB33
	.uleb128 .LEHE104-.LEHB104
	.uleb128 0
	.uleb128 0
.LLSDACSEC13542:
	.section	.text.unlikely
	.text
	.size	_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb, .-_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb
	.section	.text.unlikely
	.size	_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb.cold, .-_ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEb.cold
.LCOLDE33:
	.text
.LHOTE33:
	.p2align 4
	.globl	_ZN12minivectordb6detail32exact_top_k_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.type	_ZN12minivectordb6detail32exact_top_k_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, @function
_ZN12minivectordb6detail32exact_top_k_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE:
.LFB13610:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	%fs:40, %rbx
	movq	%rbx, 8(%rsp)
	movq	%rdi, %rbx
	call	_ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1945
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L1945:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13610:
	.size	_ZN12minivectordb6detail32exact_top_k_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, .-_ZN12minivectordb6detail32exact_top_k_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.p2align 4
	.globl	_ZN12minivectordb6detail40exact_top_k_batched_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.type	_ZN12minivectordb6detail40exact_top_k_batched_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, @function
_ZN12minivectordb6detail40exact_top_k_batched_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE:
.LFB13615:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	%fs:40, %rbx
	movq	%rbx, 8(%rsp)
	movq	%rdi, %rbx
	call	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1949
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L1949:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13615:
	.size	_ZN12minivectordb6detail40exact_top_k_batched_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, .-_ZN12minivectordb6detail40exact_top_k_batched_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.p2align 4
	.globl	_ZN12minivectordb6detail37exact_top_k_simd_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.type	_ZN12minivectordb6detail37exact_top_k_simd_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, @function
_ZN12minivectordb6detail37exact_top_k_simd_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE:
.LFB13616:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movq	%fs:40, %rbx
	movq	%rbx, 8(%rsp)
	movq	%rdi, %rbx
	movq	%rbx, %rdi
	testb	$4, 13(%rax)
	je	.L1951
	call	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.L1950:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1955
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1951:
	.cfi_restore_state
	call	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	jmp	.L1950
.L1955:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13616:
	.size	_ZN12minivectordb6detail37exact_top_k_simd_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, .-_ZN12minivectordb6detail37exact_top_k_simd_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.p2align 4
	.globl	_ZN12minivectordb6detail37exact_top_k_wide_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.type	_ZN12minivectordb6detail37exact_top_k_wide_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, @function
_ZN12minivectordb6detail37exact_top_k_wide_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE:
.LFB13617:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	__cpu_model@GOTPCREL(%rip), %rax
	movq	%fs:40, %rbx
	movq	%rbx, 8(%rsp)
	movq	%rdi, %rbx
	movl	12(%rax), %eax
	movl	%eax, %edi
	andl	$1024, %edi
	testb	$-128, %ah
	je	.L1957
	testl	%edi, %edi
	je	.L1960
	movq	%rbx, %rdi
	call	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	jmp	.L1956
	.p2align 4,,10
	.p2align 3
.L1957:
	testl	%edi, %edi
	je	.L1960
	movq	%rbx, %rdi
	call	_ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
.L1956:
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1968
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1960:
	.cfi_restore_state
	movq	%rbx, %rdi
	call	_ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEE
	jmp	.L1956
.L1968:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13617:
	.size	_ZN12minivectordb6detail37exact_top_k_wide_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE, .-_ZN12minivectordb6detail37exact_top_k_wide_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvlS3_EEEERKS4_IFblEE
	.section	.data.rel.ro,"aw"
	.align 8
	.type	_ZTIZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_, @object
	.size	_ZTIZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_, 16
_ZTIZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_, @object
	.size	_ZTSZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_, 181
_ZTSZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_:
	.string	"*ZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS4_IFvS1_IKlLm18446744073709551615EES3_tEEEEbEUlS6_S3_tE_"
	.section	.data.rel.ro
	.align 8
	.type	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 16
_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 163
_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.string	"*ZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_"
	.section	.data.rel.ro
	.align 8
	.type	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 16
_ZTIZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 163
_ZTSZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.string	"*ZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_"
	.section	.data.rel.ro
	.align 8
	.type	_ZTIZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTIZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 16
_ZTIZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTSZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 175
_ZTSZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.string	"*ZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_"
	.section	.data.rel.ro
	.align 8
	.type	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 16
_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 175
_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.string	"*ZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_"
	.section	.data.rel.ro
	.align 8
	.type	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 16
_ZTIZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_
	.section	.rodata
	.align 32
	.type	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, @object
	.size	_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_, 175
_ZTSZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_:
	.string	"*ZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS_8NeighborESaIS3_EESt4spanIKfLm18446744073709551615EEmRKSt8functionIFvRKS9_IFvlS8_EEEERKS9_IFblEEEUllS8_E_"
	.weak	_ZN12minivectordb7profile6detail8countersE
	.section	.tbss._ZN12minivectordb7profile6detail8countersE,"awTG",@nobits,_ZN12minivectordb7profile6detail8countersE,comdat
	.align 8
	.type	_ZN12minivectordb7profile6detail8countersE, @object
	.size	_ZN12minivectordb7profile6detail8countersE, 384
_ZN12minivectordb7profile6detail8countersE:
	.zero	384
	.weak	_ZN12minivectordb7profile6detail6activeE
	.section	.tbss._ZN12minivectordb7profile6detail6activeE,"awTG",@nobits,_ZN12minivectordb7profile6detail6activeE,comdat
	.type	_ZN12minivectordb7profile6detail6activeE, @object
	.size	_ZN12minivectordb7profile6detail6activeE, 1
_ZN12minivectordb7profile6detail6activeE:
	.zero	1
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC0:
	.long	2147483647
	.long	0
	.long	0
	.long	0
	.section	.rodata.cst4,"aM",@progbits,4
	.align 4
.LC1:
	.long	2139095039
	.section	.data.rel.ro.local,"aw"
	.align 8
.LC7:
	.quad	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.align 8
.LC14:
	.quad	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb0ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.align 8
.LC18:
	.quad	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.align 8
.LC24:
	.quad	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb6detailL18batched_top_k_implILb1ELb0EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.align 8
.LC30:
	.quad	_ZNSt17_Function_handlerIFvlSt4spanIKfLm18446744073709551615EEEZN12minivectordb12_GLOBAL__N_15top_kILb1EEESt6vectorINS4_8NeighborESaIS8_EES2_mRKSt8functionIFvRKSB_IS3_EEERKSB_IFblEEEUllS2_E_E10_M_managerERSt9_Any_dataRKSP_St18_Manager_operation
	.align 8
.LC32:
	.quad	_ZNSt17_Function_handlerIFvSt4spanIKlLm18446744073709551615EES0_IKfLm18446744073709551615EEtEZN12minivectordb6detail43exact_top_k_transposed_validated_candidatesES4_mRKSt8functionIFvRKS8_IS5_EEEbEUlS2_S4_tE_E10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation
	.hidden	DW.ref._ZTISt9bad_alloc
	.weak	DW.ref._ZTISt9bad_alloc
	.section	.data.rel.local.DW.ref._ZTISt9bad_alloc,"awG",@progbits,DW.ref._ZTISt9bad_alloc,comdat
	.align 8
	.type	DW.ref._ZTISt9bad_alloc, @object
	.size	DW.ref._ZTISt9bad_alloc, 8
DW.ref._ZTISt9bad_alloc:
	.quad	_ZTISt9bad_alloc
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.rel.local.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align 8
	.type	DW.ref.__gxx_personality_v0, @object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.globl	__popcountdi2
	.globl	__gxx_personality_v0
	.ident	"GCC: (Alpine 14.2.0) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
